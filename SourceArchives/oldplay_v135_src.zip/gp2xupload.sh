/sbin/ifconfig usb0 up 10.1.0.2 
 curl -T player/oldplay -u root: ftp://10.1.0.1//mnt/sd/oldplay/
