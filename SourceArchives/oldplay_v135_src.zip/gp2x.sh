/sbin/ifconfig usb0 up 10.1.0.2
