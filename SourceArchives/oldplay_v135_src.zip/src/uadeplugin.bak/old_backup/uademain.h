 /*
  * Prototypes for uademain.c
  */

extern struct uae_prefs currprefs;

extern void uade_go(void);
extern int uade_init(void);
extern void default_prefs(struct uae_prefs *p);
extern void discard_prefs(struct uae_prefs *p);
static void fix_options(void);
extern void uae_quit(void);
extern void wrapper(void);
extern void write_log_standard(const char *fmt, ...);
extern int uade_main(int argc, char **argv);

