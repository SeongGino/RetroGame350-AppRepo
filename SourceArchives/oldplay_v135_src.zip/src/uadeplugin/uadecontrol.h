#ifndef _UADE_CONTROL_
#define _UADE_CONTROL_

#include <sys/types.h>

/* EaglePlayer options */
#define EP_A500              (1 << 0)
#define EP_A1200             (1 << 1)
#define EP_ALWAYS_ENDS       (1 << 2)
#define EP_CONTENT_DETECTION (1 << 3)
#define EP_SPEED_HACK        (1 << 4)

#define ES_A500              (1 <<  5)
#define ES_A1200             (1 <<  6)
#define ES_BROKEN_SUBSONGS   (1 <<  7)
#define ES_LED_OFF           (1 <<  8)
#define ES_LED_ON            (1 <<  9)
#define ES_NO_HEADPHONES     (1 <<  10)
#define ES_NO_PANNING        (1 <<  11)
#define ES_NO_POSTPROCESSING (1 <<  12)
#define ES_NTSC              (1 <<  13)
#define ES_SPEED_HACK        (1 <<  14)
#define ES_VBLANK            (1 <<  15)
#define ES_IGNORE_PLAYER_CHECK (1 <<  16)
#define ES_BROKEN_SONG_END   (1 <<  17)
#define ES_NAME_DETECTION    (1 <<  18)

struct uade_ep_options {
	char o[256];
	size_t s;
};

void uade_add_ep_option(struct uade_ep_options *opts, const char *s);
int uade_send_ep_options(struct uade_ep_options *eo);

#endif
