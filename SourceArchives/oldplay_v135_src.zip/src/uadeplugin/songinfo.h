#ifndef _UADE_SONG_INFO_
#define _UADE_SONG_INFO_

int uade_song_info(char *info, size_t maxlen, char *filename);

#endif
