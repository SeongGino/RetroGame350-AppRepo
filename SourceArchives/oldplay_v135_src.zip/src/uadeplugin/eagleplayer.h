#ifndef _EAGLEPLAYER_
#define _EAGLEPLAYER_

#define MAX_EXTENSIONS	512
#define MAX_PLAYERS		192

#include "uadecontrol.h"

struct eagleplayer {
	char *playername;
	int attributes;
	struct uade_ep_options ep_options;
};

struct eagleplayermap {
	char *extension;
	struct eagleplayer *player;
};

struct eagleplayerstore {
	char *data;
	
	size_t nplayers;
	struct eagleplayer players[MAX_PLAYERS];
	
	size_t nextensions;
	struct eagleplayermap map[MAX_EXTENSIONS];
};

int uade_load_playerstore(struct eagleplayerstore *ps, const char *conf);
struct eagleplayer *uade_get_eagleplayer(const char *extension, struct eagleplayerstore *ps);
struct eagleplayer *uade_analyze_format(const char *name, struct eagleplayerstore *ps);

#endif
