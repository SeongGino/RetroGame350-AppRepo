/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <assert.h>
#include <stdarg.h>
#ifdef HAVE_PTHREAD_H
#include <pthread.h>
#else
#include <SDL/SDL_thread.h>
#endif

#include "../FormatsDatabase.h"
#include "../plugin.h"
#include "../util.h"

extern "C"
{
#include "uade/sysconfig.h"
#include "uade/include/sysdeps.h"

#include "uade/sd-sound.h"
#include "uade/include/uadeipc.h"
#include "uade/include/uade.h"
#include "eagleplayer.h"

extern int mono_output; /* enabled by default */
}

#define UADE_RC             "uaerc"
#define UADE_SCORE          "score"
#define EAGLEPLAYER_CONF    "eagleplayer.conf"
#define MAX_PREFIX_SIZE     12

/* the eagle player store */
struct eagleplayerstore *store;

static char current_format[80] = "";
static int first_run = 1;

static FormatsDatabase formatsdb;

static string fieldname[3];
static string fielddata[3];

#ifndef WIN32
#define stricmp strcasecmp
#define strnicmp strncasecmp
#endif

static struct sound_plugin plugin;

#ifdef HAVE_PTHREAD_H
static pthread_t uade_thread_id = 0;
static pthread_attr_t pattr;
static sched_param param;
#else
static SDL_Thread *thread;
#endif

extern "C" {
    extern int quit_program;
	int fill_audio_buffer (unsigned char *stream, int len);
    void flush_audio_buffer();
    void close_sound (void);
    void close_audio (void);

    int uade_init(const char *optionsfile);
    void uade_change_subsong(int subsong);
    void m68k_run_1 (void);
    void uae_quit (void);

    void free_cpufunctbl (void);
    void free_memory (void);

    unsigned int ntohl(unsigned int l)
    {
        return ((l>>24) & 0xff) | ((l>>8) & 0xFF00) | ((l<<8) & 0xFF0000) | (l<<24);
    }

    unsigned int htonl(unsigned int l)
    {
        return ((l>>24) & 0xff) | ((l>>8) & 0xFF00) | ((l<<8) & 0xFF0000) | (l<<24);
    }

    void uade_set_subtunes(int mins, int maxs, int curs)
    {
        plugin.tune = curs ? curs-1 : 0;
        plugin.subtunes = maxs ? maxs : 1;
    }

    /* To allow uade automatically change subsong */
    int uade_request_change_subtune()
    {
        fprintf(stderr, "uadeplugin - changing subtune %d\n", plugin.tune+1);
        if( plugin.tune < (plugin.subtunes-1) ){
            plugin.tune++;
            uade_change_subsong(plugin.tune);
            return 1;
        }

        return 0;
    }
}

/* m68k emulation thread */
#ifdef HAVE_PTHREAD_H
static void *m68k_thread(void *data)
{
    while (uade_reboot == 0 && quit_program == 0) {
        /* usleep() is called inside finish_sound_buffer()
           in uade/sd-sound.c */
        m68k_run_1 ();
    }
    pthread_exit ( 0 );
}
#else
int m68k_thread(void *unused)
{
    while (uade_reboot == 0 && quit_program == 0) {
        /* usleep() is called inside finish_sound_buffer()
           in uade/sd-sound.c */
        m68k_run_1 ();
    }
    return 0;
}
#endif

static int fill_buffer(signed short *dest, int len)
{
    if( quit_program ) return 0;
    fill_audio_buffer((unsigned char *)dest, len);
	return len;
}

static int init_file(char *fname)
{
    /* Save memory for other plugins */
    if( first_run ) {
        /* load eagleplayer config */
        store = (eagleplayerstore *) malloc(sizeof(struct eagleplayerstore));
        if (uade_load_playerstore(store, EAGLEPLAYER_CONF) <= 0) {
            fprintf(stderr, "init_file: couldn't load %s\n", EAGLEPLAYER_CONF);
            return -1;
        }

       	uade_init(UADE_RC);
        first_run = 0;
    }

#ifdef A320
	plugin.clockfreq = 336;
    if( strstr(fname, "mdat") ) plugin.clockfreq = 384;
#else
	plugin.clockfreq = 250;
#endif

    int rc;
    struct eagleplayer *player = uade_analyze_format(fname, store);
    if( player == NULL ) {
        fprintf(stderr, "init_file: could not find player for: %s\n", fname);
        return -1;
    }

    fprintf(stderr, "init_file: player: %s\n", player->playername);

    char tmp[128];
    snprintf(tmp, 128, "players/%s", player->playername);
    strcpy(current_format, player->playername);

    /* load file */
    if(strcmp("custom", player->playername) == 0)
    {
        rc = uade_load_song(NULL, UADE_SCORE, fname);
        strcpy(current_format, "Amiga Custom");
    }
    else
        rc = uade_load_song(fname, UADE_SCORE, tmp);

    if(rc == 0) {
        fprintf(stderr, "init_file: uade_load_song failed (%d).", rc);
        return -1;
    }

    /* Set eagleplayer attributes */
    if (player->attributes & ES_IGNORE_PLAYER_CHECK) {
        uade_set_command(UADE_COMMAND_IGNORE_CHECK);
    }

    if (player->attributes & ES_BROKEN_SONG_END) {
        uade_set_command(UADE_COMMAND_SONG_END_NOT_POSSIBLE);
    }

    /* uncommend this to use ntsc timming */
    /* uade_set_command(UADE_COMMAND_SET_NTSC); */

    if (player->attributes & ES_SPEED_HACK) {
        uade_set_command(UADE_COMMAND_SPEED_HACK);
    }

    uade_send_ep_options(&player->ep_options);
    flush_audio_buffer();

	plugin.length = -1;
	plugin.subtunes = 1;
	plugin.tune = 0;

	int x = 0;
    fieldname[x] = "File";
    char *file = strrchr(fname, SEPARATOR);
    fielddata[x++] = file ? file+1 : fname;
    fieldname[x] = "Format";
    fielddata[x++] = strlen(current_format) > 0 ? current_format : "amiga";
    fieldname[x] = "Player";
    fielddata[x++] = player->playername;

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields   = x;

    /* create emulation thread */
#ifdef HAVE_PTHREAD_H
	pthread_attr_init(&pattr);
	pthread_attr_getschedparam (&pattr, &param);

	/* set the priority; others are unchanged */
	param.sched_priority = 0;/* -20 high to 19 low. 0 == default */

   	/* setting the new scheduling param */
	pthread_attr_setschedparam (&pattr, &param);
    pthread_create( &uade_thread_id, &pattr, m68k_thread, NULL);
#else
    thread = SDL_CreateThread(m68k_thread, NULL);
    if ( thread == NULL ) {
        fprintf(stderr, "init_file: unable to create thread: %s\n", SDL_GetError());
        return -1;
    }
#endif

	return 0;
}

static int close()
{
#ifdef HAVE_PTHREAD_H
    if( uade_thread_id ) {
    	uae_quit();
        pthread_join(uade_thread_id, NULL);
        uade_thread_id = 0;
    }
#else
    if( thread ) {
        uae_quit();
        SDL_WaitThread(thread, NULL);
        thread = NULL;
    }
#endif

    for(int i = 0; i < plugin.nfields; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }

    plugin.tune = plugin.subtunes = plugin.length = plugin.nfields = 0;
	return 0;
}

static void shutdown()
{
    free_memory();
    free_cpufunctbl();
    close_sound();
    close_audio();

    free(store);
    first_run = 1;
}

static int set_position(int msec, int subtune)
{
    fprintf(stderr, "set_position - %d, %d\n", msec, subtune);
    if (!msec) {
    	uade_change_subsong(subtune);
        return 1;
    }
    else
        return 0; // No seeking
}

static int can_handle(const char *name)
{
    char tmp[256], *tmp2;
    tmp2 = strrchr(name, SEPARATOR);
    strncpy(tmp, tmp2 ? tmp2+1 : name, 256);

    char *prefix = strtok(tmp, ".");
	const char *sext = strrchr(name, '.');

    // Try with prefix first
    int ret = 0;
    ret = formatsdb.Find(prefix ? prefix: "");

    return ret ? ret : formatsdb.Find(sext ? sext+1 : "");
}

extern "C"
{

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN uade_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
        // Load formats database
        if( !formatsdb.Load("[UADE]", "formats.db") )
            exit(-1);

        memset(&plugin, 0, sizeof(plugin));

        plugin.plugname     = "uade";
        plugin.freq         = DEFAULT_SOUND_FREQ;
        plugin.channels     = mono_output ? 1 : 2;
        plugin.init_file    = init_file;
        plugin.fill_buffer  = fill_buffer;
        plugin.can_handle   = can_handle;
        plugin.close        = close;
        plugin.shutdown     = shutdown;
        plugin.set_position = set_position;

        plugin.replaygain = 1;

        return &plugin;
    }

}  // extern "C"
