/* uadecontrol.c is a helper module to control uade core through IPC:

   Copyright (C) 2005 Heikki Orsila <heikki.orsila@iki.fi>

   This source code module is dual licensed under GPL and Public Domain.
   Hence you may use _this_ module (not another code module) in any way you
   want in your projects.
*/


#include <stdio.h>
#include <string.h>

#include "uade/sysconfig.h"
#include "uade/include/sysdeps.h"

#include "uadecontrol.h"
#include "uade/include/uadeipc.h"
#include "uade/include/uade.h"

int uade_send_ep_options(struct uade_ep_options *eo)
{
	if (eo->s > 0) {
		size_t i = 0;
		while (i < eo->s) {
			char *s = &eo->o[i];
			size_t l = strlen(s) + 1;
			uade_set_player_option(s);
			i += l;
		}
	}
	return 0;
}

void uade_add_ep_option(struct uade_ep_options *opts, const char *s)
{
	size_t freespace = sizeof(opts->o) - opts->s;

	if (strlcpy(&opts->o[opts->s], s, freespace) >= freespace) {
		return;
	}

	opts->s += strlen(s) + 1;
}
