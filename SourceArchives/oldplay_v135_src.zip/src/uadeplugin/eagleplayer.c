
#include <stdio.h>
#include <string.h>

#include "uade/sysconfig.h"
#include "uade/include/sysdeps.h"
#include "eagleplayer.h"

#define LINESIZE (1024)

static char *memfgets( char *p_memfile, int size, int* p_filepos )
{
	char *p_buffer = p_memfile + *p_filepos;
    if ( !p_memfile )
        return NULL;

	int filepos = *p_filepos;
    if ( filepos >= size )
        return NULL;

    int i = filepos;
    int last = size;

    int stop = 0;

    /* Stop at the next newline (inclusive) */
    while ( i < last && !stop )
    {
        if ( p_memfile[i] == '\n' )
            stop = 1;
        i++;
    }

    if ( i != filepos )
    {
        *p_filepos = i;
    }

    return p_buffer;
}

char *find_token(char *p_memfile, char token)
{
	char *p = p_memfile;

	while (*p != '\n' && *p != '\0') {
		if (*p == token) break;
		p++;
	}

	return p;
}

char *skip_spaces(char *p_memfile)
{
	char *p = p_memfile;
	while (*p != '\n') {
		if (*p != '\t' && *p != ' ') break;
		p++;
	}

	return p;
}

/* Compare function for bsearch() and qsort() to sort eagleplayers with
   respect to name extension. */
static int ufcompare(const void *a, const void *b)
{
	const struct eagleplayermap *ua = a;
	const struct eagleplayermap *ub = b;

	return strcasecmp(ua->extension, ub->extension);
}

char *parse_prefixes(struct eagleplayerstore *ps, struct eagleplayer *pl, char *p_memfile)
{
	/* Look for the prefixes end */
	char *p = find_token(p_memfile, '\t');
	if (*p == '\t') *p = '\0';

	p = p_memfile;
	while (*p != '\n' && *p != '\0') {
		if (ps->nextensions > (MAX_EXTENSIONS-1)) break;
		ps->map[ps->nextensions].extension = p;
		ps->map[ps->nextensions].player = pl; ps->nextensions++;

		/* Look for another extension */
		p = find_token(p, ',');
		if (*p == ',') {
			*p = '\0';
			p++;
		}
	}

	return p;
}

int uade_load_playerstore(struct eagleplayerstore *ps, const char *conf)
{
	int fd = open(conf, O_RDONLY);
	if (fd < 0) return -1;

	/* Clean store */
	memset(ps, 0, sizeof(struct eagleplayerstore));

	int size = lseek(fd, 0, SEEK_END);
	lseek(fd, 0, SEEK_SET);

	ps->data = (char *)xmalloc(size);
	read(fd, ps->data, size);
	close(fd);

	char *p;
	int filepos = 0;
	while ( (p = memfgets(ps->data, size, &filepos)) != NULL ) {
		struct eagleplayer *pl = &ps->players[ps->nplayers];

		/* First token MUST be player name */
		pl->playername = p; ps->nplayers++;
		p = find_token(p, '\t'); *p = '\0';

		while (*p != '\n') {
			p = skip_spaces(p + 1);

			if (strncasecmp(p, "prefixes=", 9) == 0) {
				p = parse_prefixes(ps, pl, p + 9);
			}
			else if (strncasecmp(p, "comment:", 8) == 0) {
				p = find_token(p+8, '\t');
			}
			else if (strncasecmp(p, "epopt=", 6) == 0) {
				char *ep_opt = p + 6, last_char;
				p = find_token(ep_opt, '\t');
				last_char = *p;
				*p = '\0';

				uade_add_ep_option(&pl->ep_options, ep_opt);
				if (last_char == '\n') break;
			}
			else if (strncasecmp(p, "content_detection", 17) == 0) {
				pl->attributes |= EP_CONTENT_DETECTION; p += 17;
			}
			else if (strncasecmp(p, "detect_format_by_content", 24) == 0) {
				pl->attributes |= EP_CONTENT_DETECTION; p += 24;
			}
			else if (strncasecmp(p, "a500", 4) == 0) {
				pl->attributes |= EP_A500; p += 4;
			} else if (strncasecmp(p, "a1200", 5) == 0) {
				pl->attributes |= EP_A1200; p += 5;
			} else if (strncasecmp(p, "always_ends", 11) == 0) {
				pl->attributes |= EP_ALWAYS_ENDS; p += 11;
			} else if (strncasecmp(p, "speed_hack", 10) == 0) {
				pl->attributes |= EP_SPEED_HACK; p += 10;
			} else if (strncasecmp(p, "ignore_player_check", 19) == 0) {
				pl->attributes |= ES_IGNORE_PLAYER_CHECK; p += 19;
			} else if (strncasecmp(p, "broken_song_end", 15) == 0) {
				pl->attributes |= ES_BROKEN_SONG_END; p += 15;
			} else if (strncasecmp(p, "detect_format_by_name", 21) == 0) {
				pl->attributes |= ES_NAME_DETECTION; p += 21;
			}

			if (*p == ' ') *p = '\0';
		}

		if (*p == '\n') {
			*p = '\0';
		}
	}

	fprintf(stderr, "player store found %d players, %d extensions\n", ps->nplayers, ps->nextensions);

	/* Make the extension map bsearch() ready */
	qsort(ps->map, ps->nextensions, sizeof(ps->map[0]), ufcompare);

	return 1;
}

void uade_free_playerstore(struct eagleplayerstore *ps)
{
	if(ps && ps->data) free(ps->data);
}

struct eagleplayer *uade_get_eagleplayer(const char *extension,
					   struct eagleplayerstore *ps)
{
	struct eagleplayermap *uf = ps->map;
	struct eagleplayermap *f;
	struct eagleplayermap key = {.extension = (char *)extension };

	f = bsearch(&key, uf, ps->nextensions, sizeof(uf[0]), ufcompare);
	if (f == NULL)
		return NULL;

	return f->player;
}

struct eagleplayer *uade_analyze_format(const char *name, struct eagleplayerstore *ps)
{
	const char *sext = strrchr(name, '.');
	char prefix[strlen(name)+1];

	char ext[128];
	size_t bufsize, bytesread;
	unsigned char buf[4096];

	/* get some magic */
	int fd;
	if ((fd = open(name, O_RDONLY|O_BINARY)) < 0) {
		return NULL;
	}

	/* get file size */
	size_t size = lseek(fd, 0, SEEK_END);
	lseek(fd, 0, SEEK_SET);

	bufsize = sizeof buf;
	bytesread = read(fd, buf, bufsize);
	close(fd);

	if (bytesread == 0)
		return NULL;

	if (bytesread < bufsize)
		memset(&buf[bytesread], 0, bufsize - bytesread);

	uade_filemagic(buf, bytesread, ext, size, name, 1);

	if (strcmp(ext, "reject") == 0)
		return NULL;

	if (ext[0] != 0)
		fprintf(stderr, "content recognized: %s (%s)\n", ext, name);

	if (strcmp(ext, "packed") == 0)
		return NULL;

	/* try prefix and extension first */
	if( !sext )
    {
		sext = "";
        prefix[0] = '\0';
    }
	else
    {
		sext++;
        const char* name2 = strrchr(name,'/');
        name2 = name2 ? name2+1 : name;
        strcpy(prefix,name2);
        *strchr(prefix,'.') = '\0';
    }

	/* first do filename detection (we'll later do content detection) */
	struct eagleplayer *player = uade_get_eagleplayer(prefix, ps);
	if( player == NULL )
		player = uade_get_eagleplayer(sext, ps);

	/* if name detection skip content detection */
	if( player && (player->attributes & ES_NAME_DETECTION) ) return player;

	/* if filemagic found a match, we'll use player plugins associated with
	   that extension */
	if (ext[0]) {
		player = uade_get_eagleplayer(ext, ps);
	}

	return player;
}


