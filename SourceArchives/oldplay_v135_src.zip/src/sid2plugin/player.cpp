/*
 * This file is part of sidplayfp, a console SID player.
 *
 * Copyright 2011-2013 Leandro Nini
 * Copyright 2000-2001 Simon White
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "config.h"
#include "player.h"


#include <iostream>
#include <iomanip>
#include <fstream>
#include <new>

using std::cout;
using std::cerr;
using std::endl;

#include <stdlib.h>

#ifdef HAVE_UNISTD_H
#   include <unistd.h>
#endif

#include <sidplayfp/sidbuilder.h>
#include <sidplayfp/SidInfo.h>
#include <sidplayfp/SidTuneInfo.h>

// Previous song select timeout (3 secs)
#define SID2_PREV_SONG_TIMEOUT 4

#ifdef HAVE_SIDPLAYFP_BUILDERS_RESIDFP_H
#  include <sidplayfp/builders/residfp.h>
const char Player::RESIDFP_ID[]   = "ReSIDfp";
#endif

#ifdef HAVE_SIDPLAYFP_BUILDERS_RESID_H
#  include <sidplayfp/builders/resid.h>
const char Player::RESID_ID[]   = "ReSID";
#endif

#ifdef HAVE_SIDPLAYFP_BUILDERS_HARDSID_H
#   include <sidplayfp/builders/hardsid.h>
const char Player::HARDSID_ID[] = "HardSID";
#endif

static char oldplay_home[128] = "./";

Player::Player (const char * const name) :
 m_name(name),
 m_tune(0),
 m_sid(EMU_NONE),
 m_quietLevel(0),
 m_verboseLevel(0),
 m_cpudebug(false)
{   // Other defaults
    m_filename       = "";
    m_length         = 0;
    m_filter.enabled = true;
    m_track.first    = 0;
    m_track.selected = 0;
    m_track.loop     = false;
    m_track.single   = false;

    {
        m_engCfg.forceC64Model   = false;
        m_engCfg.defaultC64Model = SidConfig::PAL;;
        m_engCfg.defaultSidModel = SidConfig::MOS6581;
        m_engCfg.forceSidModel   = false;
        m_engCfg.frequency    = 44100;
        m_engCfg.playback     = SidConfig::MONO;
        m_precision           = 16;
        m_filter.enabled      = true;
        m_filter.bias         = 0.0;
        m_filter.filterCurve6581 = 0.0;
        m_filter.filterCurve8580 = 0.0;

        m_engCfg.samplingMethod = SidConfig::INTERPOLATE;
        m_engCfg.fastSampling = true;
        m_sid = EMU_RESID;
    }

    /* createSidEmu (EMU_NONE); */

#ifndef _WIN32
    char *home = getenv("HOME");
    if (home == NULL) {
        fprintf(stderr, "main: unable to set \
            oldplay home directory.\nThe $HOME variable is not defined");
        exit(-1);
    }
    sprintf(oldplay_home, "%s/.oldplay", home);
#endif


    uint8_t *kernalRom = loadRom("kernal", 8192);
    uint8_t *basicRom = loadRom("basic", 8192);
    uint8_t *chargenRom = loadRom("chargen", 4096);
    m_engine.setRoms(kernalRom, basicRom, chargenRom);
    delete [] kernalRom;
    delete [] basicRom;
    delete [] chargenRom;

    const char *database = "Songlengths.txt";
#ifndef _WIN32
    char buffer[PATH_MAX];
    snprintf(buffer, PATH_MAX, "%sSonglengths.txt", oldplay_home);

    if (::access(buffer, R_OK) == 0)
        database = buffer;
#endif

    if (database && (*database != '\0'))
    {   // Try loading the database specificed by the user
        if (!m_database.open (database))
        {
            displayError (m_database.error ());
        }
    }

    // Configure engine with settings
    if (m_engine.config (m_engCfg) < 0)
    {   // Config failed
        displayError (m_engine.error ());
    }
}

uint8_t* Player::loadRom(const char defaultRom[], const int size)
{
    std::string dataPath;
    dataPath = oldplay_home;
    dataPath.append("/").append(defaultRom);

    std::ifstream is(dataPath.c_str(), std::ios::binary);

    if (is.fail())
        goto error;
    {
        try
        {
            uint8_t *buffer = new uint8_t[size];

            is.read((char*)buffer, size);
            if (is.fail())
                goto error;

            is.close();
            return buffer;
        }
        catch (std::bad_alloc& ba)
        {
            goto error;
        }
    }

error:
    is.close();
    return 0;
}


// Create the sid emulation
bool Player::createSidEmu (SIDEMUS emu)
{
    // Remove old driver and emulation
    if (m_engCfg.sidEmulation)
    {
        sidbuilder *builder   = m_engCfg.sidEmulation;
        m_engCfg.sidEmulation = NULL;
        m_engine.config (m_engCfg);
        delete builder;
    }

    // Now setup the sid emulation
    switch (emu)
    {
#ifdef HAVE_SIDPLAYFP_BUILDERS_RESIDFP_H
    case EMU_RESIDFP:
    {
        try
        {
            ReSIDfpBuilder *rs = new ReSIDfpBuilder( RESIDFP_ID );

            m_engCfg.sidEmulation = rs;
            if (!rs->getStatus()) goto createSidEmu_error;
            rs->create ((m_engine.info ()).maxsids());
            if (!rs->getStatus()) goto createSidEmu_error;

            if (m_filter.filterCurve6581)
                rs->filter6581Curve(m_filter.filterCurve6581);
            if (m_filter.filterCurve8580)
                rs->filter8580Curve((double)m_filter.filterCurve8580);
        }
        catch (std::bad_alloc& ba) {}
        break;
    }
#endif // HAVE_SIDPLAYFP_BUILDERS_RESIDFP_H

#ifdef HAVE_SIDPLAYFP_BUILDERS_RESID_H
    case EMU_RESID:
    {
        try
        {
            ReSIDBuilder *rs = new ReSIDBuilder( RESID_ID );

            m_engCfg.sidEmulation = rs;
            if (!rs->getStatus()) goto createSidEmu_error;
            rs->create ((m_engine.info ()).maxsids());
            if (!rs->getStatus()) goto createSidEmu_error;

            rs->bias(m_filter.bias);
        }
        catch (std::bad_alloc& ba) {}
        break;
    }
#endif // HAVE_SIDPLAYFP_BUILDERS_RESID_H

#ifdef HAVE_SIDPLAYFP_BUILDERS_HARDSID_H
    case EMU_HARDSID:
    {
        try
        {
            HardSIDBuilder *hs = new HardSIDBuilder( HARDSID_ID );

            m_engCfg.sidEmulation = hs;
            if (!hs->getStatus()) goto createSidEmu_error;
            hs->create ((m_engine.info ()).maxsids());
            if (!hs->getStatus()) goto createSidEmu_error;
        }
        catch (std::bad_alloc& ba) {}
        break;
    }
#endif // HAVE_SIDPLAYFP_BUILDERS_HARDSID_H

    default:
        // Emulation Not yet handled
        // This default case results in the default
        // emulation
        break;
    }

    if (!m_engCfg.sidEmulation)
    {
        if (emu > EMU_DEFAULT)
        {   // No sid emulation?
            displayError (ERR_NOT_ENOUGH_MEMORY);
            return false;
        }
    }

    if (m_engCfg.sidEmulation) {
        /* set up SID filter. HardSID just ignores call with def. */
        m_engCfg.sidEmulation->filter(m_filter.enabled);
    }

    return true;

createSidEmu_error:
    displayError (m_engCfg.sidEmulation->error ());
    delete m_engCfg.sidEmulation;
    m_engCfg.sidEmulation = NULL;
    return false;
}


bool Player::open (const char *file)
{
    // Load the tune
    m_filename = file;
    m_tune.load (m_filename);
    if (!m_tune.getStatus())
    {
        displayError (m_tune.statusString());
        return -1;
    }

    // Get tune details
    const SidTuneInfo *tuneInfo = m_tune.getInfo ();
    m_track.songs = tuneInfo->songs();
    if (!createSidEmu (m_sid))
        return false;

    // Configure engine with settings
    if (!m_engine.config (m_engCfg))
    {   // Config failed
        displayError (m_engine.error ());
        return false;
    }

    // Select the desired track
    m_track.first    = m_tune.selectSong (m_track.first);
    m_track.selected = m_track.first;

    return selectSong(m_track.selected);
}

bool Player::selectSong (unsigned int songNum)
{
    // Select the required song
    m_track.selected = m_tune.selectSong (songNum);
    if (m_engine.load (&m_tune) < 0)
    {
        displayError (m_engine.error ());
        return false;
    }

    // As yet we don't have a required songlength
    // so try the songlength database
    m_length = (3 * 60 + 30) * 1000;
    int_least32_t length = m_database.length (m_tune);
    if (length > 0)
        m_length = length;

    return true;
}

void Player::close ()
{
    m_engine.stop   ();

    // Shutdown drivers, etc
    createSidEmu    (EMU_NONE);
    m_engine.load   (NULL);
    m_engine.config (m_engCfg);
}


// Out play loop to be externally called
bool Player::play (short *buffer, uint_least32_t length)
{
    // Fill buffer
    uint_least32_t ret;
    ret = m_engine.play (buffer, length);
    if (ret < length)
        return false;

    return true;
}


void Player::stop ()
{
    m_engine.stop ();
}

void Player::displayError (const char *error)
{
    cerr << m_name << ": " << error << endl;
}
