/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
    */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#include "player.h"
#include "../plugin.h"
#include "../util.h"

static Player *player = 0;
static struct sound_plugin plugin;
static string fieldname[5];
static string fielddata[5];

static int playing = 0;

void displayError (const char *arg0, unsigned int num)
{
    cerr << arg0 << ": ";

    switch (num)
    {
    case ERR_SYNTAX:
        cerr << "command line syntax error" << endl
             << "Try `" << arg0 << " --help' for more information." << endl;
    break;

    case ERR_NOT_ENOUGH_MEMORY:
        cerr << "ERROR: Not enough memory." << endl;
    break;

    case ERR_SIGHANDLER:
        cerr << "ERROR: Could not install signal handler." << endl;
    break;

    case ERR_FILE_OPEN:
        cerr << "ERROR: Could not open file for binary input." << endl;
    break;

    default: break;
    }
}

static void write_fields(char *fname, const SidTuneInfo *tuneInfo)
{
    int x = 0;
    if (tuneInfo->infoString(0) && strlen(tuneInfo->infoString(0)))
    {
        fieldname[x] = "Title";
        fielddata[x] = tuneInfo->infoString(0);
    }
    else
    {
        fieldname[x] = "File";
        char *name = strrchr(fname, '/');
        fielddata[x] = name ? name+1 : fname;
    }
    x++;
    if (tuneInfo->infoString(1) && strlen(tuneInfo->infoString(1)))
    {
        fieldname[x] = "Author";
        fielddata[x] = tuneInfo->infoString(1);
        x++;
    }
    if (tuneInfo->infoString(2) && strlen(tuneInfo->infoString(2)))
    {
        fieldname[x] = "Released";
        fielddata[x] = tuneInfo->infoString(2);
        x++;
    }
    if (tuneInfo->formatString() && strlen(tuneInfo->formatString()))
    {
        fieldname[x] = "Format";
        fielddata[x] = tuneInfo->formatString();
        x++;
    }
    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields = x;
}

static int init_file(char *fname)
{
    if(!player)
    {
        player = new Player("sid2plugin");
        if(!player)
        {
            fprintf(stderr, "init_file: cannot create Player.\n");
            return -1;
        }
    }

    if (!player->open (fname))
    {
        fprintf(stderr, "init_file: player->open(%s) failed.\n", fname);
        return -1;
    }

    plugin.freq = player->config()->frequency;
    plugin.channels = player->config()->playback == SidConfig::MONO ? 1 : 2;

    plugin.length = player->songLength();
    plugin.tune = player->firstSong() - 1;
    plugin.subtunes = player->songs();

    write_fields(fname, player->tuneInfo());
    playing = 1;
    return 0;
}

static int fill_buffer(signed short *dest, int len)
{
    if(playing) {
        player->play((short *)dest, len/sizeof(short));
        return len;
    }
    return 0;
}

static int set_position(int msecs, int subtune)
{
    if (!msecs) {
        subtune = subtune < player->firstSong() ? player->firstSong() : subtune;
        player->selectSong(subtune);
        return subtune;
    }
    return 0;
}

static int close()
{
    if (player) {
        player->close();
    }

    playing = plugin.tune = plugin.subtunes = plugin.length = plugin.nfields = 0;
    return 0;
}

static void shutdown()
{
    if (player) {
        delete player;
        player = 0;
    }
}
static int can_handle(const char *name)
{
    return (is_ext(name, ".sid"));
}

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN sidplayfp_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
        memset(&plugin, 0, sizeof(plugin));

        plugin.plugname   = "sidplay-fp";
        plugin.freq       = 44100;
        plugin.channels   = 1;
    #ifdef A320
        plugin.clockfreq  = 384;
    #else
        plugin.clockfreq  = 100;
    #endif
        plugin.replaygain = 1;
        plugin.init_file    = init_file;
        plugin.close        = close;
        plugin.shutdown     = shutdown;
        plugin.fill_buffer  = fill_buffer;
        plugin.set_position = set_position;
        plugin.can_handle   = can_handle;

        return &plugin;
    }

}

