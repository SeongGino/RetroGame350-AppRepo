/*
    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#ifdef HAVE_PTHREAD_H
#include <pthread.h>
#else
#include <SDL/SDL_thread.h>
#endif

extern "C" {
    #include "yaneurao/ring_buffer.h"
}

#include "Core/psx.h"
#include "Core/iop.h"
#include "Core/r3000.h"
#include "Core/spu.h"
#include "Core/bios.h"
#include "Core/mkhebios.h"

#include "psflib/psflib.h"
#include "psflib/psf2fs.h"

#include "../plugin.h"
#include "../util.h"

static struct sound_plugin plugin;
static int playing;
static string fieldname[5];
static string fielddata[5];

static ring_buffer_t buffer;
static int first_run = 1;

static char oldplay_home[128];

#ifdef HAVE_PTHREAD_H
static pthread_t ps2_thread_id = 0;
static pthread_attr_t pattr;
static sched_param param;
#else
static SDL_Thread *thread;
#endif

//#define DBG(...) printf(...)
#define DBG(a)

template<class T>
class array_t
{
    T * ptr;
    size_t size;
public:
	array_t() :  ptr( 0 ), size( 0 ) { }
	~array_t() { if ( ptr ) ::free( ptr ); }

	size_t get_size() { return size; }
	void set_size( size_t n ) {
		if ( size == n ) return;

	    size = n;
        ptr = (T *) realloc( ptr, n * sizeof(T) );
    }
	T * get_ptr() { return ptr; }
	void free() {
		if ( ptr ) ::free( ptr ); ptr = 0;
		size = 0;
	}
};

typedef struct {
	uint32_t pc0;
	uint32_t gp0;
	uint32_t t_addr;
	uint32_t t_size;
	uint32_t d_addr;
	uint32_t d_size;
	uint32_t b_addr;
	uint32_t b_size;
	uint32_t s_ptr;
	uint32_t s_size;
	uint32_t sp,fp,gp,ret,base;
} exec_header_t;

typedef struct {
	char key[8];
	uint32_t text;
	uint32_t data;
	exec_header_t exec;
	char title[60];
} psxexe_hdr_t;

class psf_init_and_load_bios
{
	unsigned ref_count;

	bool is_hebios;
	void * bios;

public:
	psf_init_and_load_bios()
	{
		ref_count = 0;
		bios = NULL;
	}

	~psf_init_and_load_bios()
	{
		if ( bios )
		{
			if ( is_hebios ) free( bios );
			else mkhebios_delete( bios );
		}
	}

	bool init( char *bios_path )
	{
		if ( ref_count == 0 )
		{
			char *bios_name = bios_path;
			if ( bios_name == 0 )
			{
				bios_name = "hebios.bin";
			}
			int bios_file;
			try
			{
				bios_file = open( bios_name, O_RDONLY);
				size_t bios_size = lseek( bios_file, 0, SEEK_END );
				if ( bios_size != 0x400000 && bios_size != 0x80000 ) return false;
				lseek( bios_file, 0, SEEK_SET );

				int final_size;

				if ( bios_size == 0x400000 )
				{
					array_t<uint8_t> buffer;
					buffer.set_size( 0x400000 );
					read( bios_file, buffer.get_ptr(), 0x400000 );

					final_size = 0x400000;
					bios = mkhebios_create( buffer.get_ptr(), &final_size );
					if ( !bios ) return false;

					is_hebios = false;
				}
				else
				{
					bios = malloc( 0x80000 );
					read( bios_file, bios, 0x80000 );
					final_size = 0x80000;

					is_hebios = true;
				}

                close( bios_file );
				bios_set_image( (unsigned char *) bios, final_size );

				if ( psx_init() ) return false;
			}
			catch (...)
			{
				return false;
			}
		}
		++ref_count;
		return true;
	}

	void quit()
	{
		if ( --ref_count == 0 )
		{
			if ( is_hebios ) free( bios );
			else mkhebios_delete( bios );
			bios = NULL;
		}
	}

} g_init;

#define BORK_TIME 0xC0CAC01A

static unsigned long parse_time_crap(const char *input)
{
	if (!input) return BORK_TIME;
	int len = strlen(input);
	if (!len) return BORK_TIME;
	int value = 0;
	{
		int i;
		for (i = len - 1; i >= 0; i--)
		{
			if ((input[i] < '0' || input[i] > '9') && input[i] != ':' && input[i] != ',' && input[i] != '.')
			{
				return BORK_TIME;
			}
		}
	}
	char *bar = (char *)input;
	char *strs = bar + len - 1;
	while (strs > bar && (*strs >= '0' && *strs <= '9'))
	{
		strs--;
	}
	if (*strs == '.' || *strs == ',')
	{
		// fraction of a second
		strs++;
		if (strlen(strs) > 3) strs[3] = 0;
		value = atoi(strs);
		switch (strlen(strs))
		{
		case 1:
			value *= 100;
			break;
		case 2:
			value *= 10;
			break;
		}
		strs--;
		*strs = 0;
		strs--;
	}
	while (strs > bar && (*strs >= '0' && *strs <= '9'))
	{
		strs--;
	}
	// seconds
	if (*strs < '0' || *strs > '9') strs++;
	value += atoi(strs) * 1000;
	if (strs > bar)
	{
		strs--;
		*strs = 0;
		strs--;
		while (strs > bar && (*strs >= '0' && *strs <= '9'))
		{
			strs--;
		}
		if (*strs < '0' || *strs > '9') strs++;
		value += atoi(strs) * 60000;
		if (strs > bar)
		{
			strs--;
			*strs = 0;
			strs--;
			while (strs > bar && (*strs >= '0' && *strs <= '9'))
			{
				strs--;
			}
			value += atoi(strs) * 3600000;
		}
	}
	return value;
}

struct psf_info_meta_state
{
    unsigned int volume;
    unsigned int replaygain;

    char title[256];
    char artist[256];
    char game[256];
    char year[256];
    char genre[256];
    char psfby[256];
    char comment[256];
    char copyright[256];

	int tag_song_ms;
	int tag_fade_ms;

	psf_info_meta_state()
		: tag_song_ms( 0 ), tag_fade_ms( 0 )
	{
	    replaygain = 0;
	    volume = 0;

	    title[0] = '\0';
        artist[0] = '\0';
        game[0] = '\0';
        year[0] = '\0';
        genre[0] = '\0';
        psfby[0] = '\0';
        comment[0] = '\0';
        copyright[0] = '\0';
	}
};

static int psf_info_meta(void * context, const char * name, const char * value)
{
	psf_info_meta_state * state = ( psf_info_meta_state * ) context;

    const char *tag = name;

    if (!strncmp(tag, "title", 5))
	{
		strcpy(state->title, value);
	}
    else if (!strncmp(tag, "artist", 6))
	{
		strcpy(state->artist, value);
	}
	else if (!strncmp(tag, "game", 4))
	{
		strcpy(state->game, value);
	}
	else if (!strncmp(tag, "year", 4))
	{
		strcpy(state->year, value);
	}
	else if (!strncmp(tag, "length", 6))
	{
		DBG("reading length");
		int temp = parse_time_crap(value);
		if (temp != BORK_TIME)
		{
			state->tag_song_ms = temp;
		}
	}
	else if (!strncmp(tag, "fade", 4))
	{
		DBG("reading fade");
		int temp = parse_time_crap(value);
		if (temp != BORK_TIME)
		{
			state->tag_fade_ms = temp;
        }
	}
	else if (!strncmp(tag, "utf8", 4))
	{
		DBG("found utf8");
	}
	else if (!strncmp(tag, "_lib", 4))
	{
		DBG("found _lib");
	}
	else if (!strncmp(tag, "_refresh", 8))
	{
		DBG("found _refresh");
	}
	else if (tag[0] == '_')
	{
		DBG("found unknown required tag, failing");
		return -1;
	}

	return 0;
}

struct psf1_load_state
{
	void * emu;
	bool first;
	unsigned refresh;
};

static int psf1_info(void * context, const char * name, const char * value)
{
    psf1_load_state * state = ( psf1_load_state * ) context;

	if ( !state->refresh && !stricmp( name, "_refresh" ) )
	{
		state->refresh = atoi( value );
	}

	return 0;
}

int psf1_load(void * context, const uint8_t * exe, size_t exe_size,
                                  const uint8_t * reserved, size_t reserved_size)
{
    psf1_load_state * state = ( psf1_load_state * ) context;

    psxexe_hdr_t *psx = (psxexe_hdr_t *) exe;

    if ( exe_size < 0x800 ) return -1;

	uint32_t addr = psx->exec.t_addr;
    uint32_t size = exe_size - 0x800;

    addr &= 0x1fffff;
    if ( ( addr < 0x10000 ) || ( size > 0x1f0000 ) || ( addr + size > 0x200000 ) ) return -1;

    void * pIOP = psx_get_iop_state( state->emu );
    iop_upload_to_ram( pIOP, addr, exe + 0x800, size );

    if ( !state->refresh )
    {
        if (!_strnicmp((const char *) exe + 113, "Japan", 5)) state->refresh = 60;
        else if (!_strnicmp((const char *) exe + 113, "Europe", 6)) state->refresh = 50;
        else if (!_strnicmp((const char *) exe + 113, "North America", 13)) state->refresh = 60;
    }

    if ( state->first )
    {
        void * pR3000 = iop_get_r3000_state( pIOP );
		r3000_setreg(pR3000, R3000_REG_PC, psx->exec.pc0);
		r3000_setreg(pR3000, R3000_REG_GEN+29, psx->exec.s_ptr);
        state->first = false;
    }

    return 0;
}

static int EMU_CALL virtual_readfile(void *context, const char *path, int offset, char *buffer, int length)
{
	return psf2fs_virtual_readfile(context, path, offset, buffer, length);
}

static void EMU_CALL virtual_console_out(void * context, char c)
{
    fputc(c, stderr);
}

struct psf_file_state
{
	FILE *f;
};

static void * psf_file_fopen( const char * uri )
{
    psf_file_state * state = new psf_file_state;
	state->f = fopen( uri, "rb" );
	if ( state->f != NULL)
        return state;

	fprintf(stderr, "psf_file_open: failed to load ´%s'.\n", uri);
	return NULL;
}

static size_t psf_file_fread( void * buffer, size_t size, size_t count, void * handle )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    size_t bytes_read = fread( buffer, size, count, state->f );
    return bytes_read / size;
}

static int psf_file_fseek( void * handle, int64_t offset, int whence )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    return fseek( state->f, offset, whence );
}

static int psf_file_fclose( void * handle )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    fclose( state->f );
    delete state;
    return 0;
}

static long psf_file_ftell( void * handle )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    return ftell( state->f );
}

const psf_file_callbacks psf_file_system =
{
	"\\/|:",
	psf_file_fopen,
	psf_file_fread,
	psf_file_fseek,
	psf_file_fclose,
	psf_file_ftell
};

array_t<uint8_t> psx_state;
array_t<int16_t> sample_buffer;
psf_info_meta_state m_info;

void * psf2fs = NULL;

int psf_version;

int cfg_reverb = 1;
int cfg_compat = IOP_COMPAT_FRIENDLY;

/* ps2 (psx) spu emulation thread */
#ifdef HAVE_PTHREAD_H
static void *ps2_thread(void *data)
{
	sample_buffer.set_size( 1024 * 2 );
    uint32_t samples_to_render = 1024;
    while ( buffer.sexy_thread_exit_flag != 1 ) {
        int err = psx_execute( psx_state.get_ptr(), 0x7FFFFFFF, sample_buffer.get_ptr(), & samples_to_render, 0 );
		if ( err < 0 ) fprintf( stderr, "ps2_thread: execution halted with an error.\n" );
		if ( !samples_to_render ) {
            fprintf(stderr, "ps2_thread: io error\n");
            break;
		}

		ring_write(&buffer, (unsigned char *)sample_buffer.get_ptr(), samples_to_render * 4 );
    }

    ring_stop(&buffer);
    pthread_exit ( 0 );
}
#else
int ps2_thread(void *unused)
{
	sample_buffer.set_size( 1024 * 2 );
    uint32_t samples_to_render = 1024;
    while ( buffer.sexy_thread_exit_flag != 1 ) {
        int err = psx_execute( psx_state.get_ptr(), 0x7FFFFFFF, sample_buffer.get_ptr(), & samples_to_render, 0 );
		if ( err < 0 ) fprintf( stderr, "ps2_thread: execution halted with an error.\n" );
		if ( !samples_to_render ) {
            fprintf(stderr, "ps2_thread: io error\n");
            break;
		}

		ring_write(&buffer, (unsigned char *)sample_buffer.get_ptr(), samples_to_render * 4 );
    }

    ring_stop(&buffer);
    return 0;
}
#endif

static int init_file(char *fname)
{
    playing = 0;
    psf_version = psf_load(fname, &psf_file_system, 0, 0, 0, 0, 0);

	if ( psf_version <= 0 ) {
        fprintf( stderr, "init_file: not a PSF file\n" );
        return -1;
    }

    if ( psf_version == 1 ) ; // psf
	else if ( psf_version == 2 ) ; // psf2
	else {
	    fprintf( stderr, "init_file: not a PSF or PSF2 file\n" );
        return -1;
    }

    if ( psf_load(fname, &psf_file_system, psf_version, 0, 0, psf_info_meta, &m_info) <= 0 ) {
        fprintf( stderr, "init_file: failed to load tags\n" );
        return -1;
    }

    if ( first_run )
	{
		char bios_path[128];
#ifdef _WIN32
		sprintf(bios_path, "scph10000.bin");
#else
		sprintf(bios_path, "%s/scph10000.bin", oldplay_home);
#endif
		if ( !g_init.init( bios_path ) )
		{
			fprintf( stderr, "init_file: BIOS load failure" );
		}

        ring_init(&buffer, BLOCK_SIZE / 4, BLOCK_COUNT * 2);
		first_run = 0;
	}
	else ring_reset(&buffer);

    psx_state.set_size(psx_get_state_size(psf_version));

	void * pEmu = psx_state.get_ptr();

	psx_clear_state(pEmu, psf_version);

	if ( psf_version == 1 )
	{
		psf1_load_state state;

		state.emu = pEmu;
		state.first = true;
		state.refresh = 0;

		if ( psf_load(fname, &psf_file_system, 1, psf1_load, &state, psf1_info, &state) < 0 ) {
			fprintf( stderr, "init_file: invalid PSF1 file\n" );
            return -1;
		}

		if ( state.refresh )
			psx_set_refresh(pEmu, state.refresh);
	}
	else if ( psf_version == 2 )
	{
		if ( psf2fs ) psf2fs_delete(psf2fs);

		psf2fs = psf2fs_create();
		if ( !psf2fs ) {
            fprintf(stderr, "init_file: bad alloc\n");
		}

		psf1_load_state state;

		state.refresh = 0;

		if ( psf_load(fname, &psf_file_system, 2, psf2fs_load_callback, psf2fs, psf1_info, &state) < 0 ) {
			fprintf( stderr, "init_file: invalid PSF2 file" );
			return -1;
		}

		if ( state.refresh )
			psx_set_refresh(pEmu, state.refresh);

		psx_set_readfile(pEmu, virtual_readfile, psf2fs);
	}

	{
        void * pIOP = psx_get_iop_state(pEmu);
        iop_set_compat(pIOP, cfg_compat);
        spu_enable_reverb(iop_get_spu_state(pIOP), cfg_reverb);
	}

    int x = 0;
    if (m_info.title[0])
    {
        fieldname[x] = "Title";
        fielddata[x++] = m_info.title;
    }
    if (m_info.game[0])
    {
        fieldname[x] = "Game";
        fielddata[x++] = m_info.game;
    }
    if (m_info.artist[0])
    {
        fieldname[x] = "Artist";
        fielddata[x++] = m_info.artist;
    }
    if (m_info.copyright[0])
    {
        fieldname[x] = "Copyright";
        fielddata[x++] = m_info.copyright;
    }

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields = x;

    plugin.length = m_info.tag_song_ms > 0 ? m_info.tag_song_ms : 3 * 60 * 1000;

	/* create emulation thread */
#ifdef HAVE_PTHREAD_H
	pthread_attr_init(&pattr);
	pthread_attr_getschedparam (&pattr, &param);

	/* set the priority; others are unchanged */
	param.sched_priority = 0;/* -20 high to 19 low. 0 == default */

   	/* setting the new scheduling param */
	pthread_attr_setschedparam (&pattr, &param);
    pthread_create( &ps2_thread_id, &pattr, ps2_thread, NULL);
#else
    thread = SDL_CreateThread(ps2_thread, NULL);
    if ( thread == NULL ) {
        fprintf(stderr, "init_file: unable to create thread: %s\n", SDL_GetError());
        return -1;
    }
#endif

    playing = 1;
    return 0;
}

static int close()
{
    if (playing) {
#ifdef HAVE_PTHREAD_H
        if( ps2_thread_id ) {
            ring_stop(&buffer);
            pthread_join(ps2_thread_id, NULL);
            ps2_thread_id = 0;
        }
#else
        if( thread ) {
            ring_stop(&buffer);
            SDL_WaitThread(thread, NULL);
            thread = NULL;
        }
#endif
		if ( psf2fs ) {
			psf2fs_delete(psf2fs);
			psf2fs = NULL;
		}

		if ( psx_state.get_size() )
			psx_state.free();

		sample_buffer.free();
		memset(&m_info, 0, sizeof(psf_info_meta_state));
    }

    for(int i = 0; i < 5; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }

    playing = plugin.length = plugin.nfields = 0;
    return 0;
}

static void shutdown()
{
	g_init.quit();
    ring_close(&buffer);
    first_run = 1;
}

static int fill_buffer(signed short *dest, int len)
{
    if(playing) {
        return ring_read(&buffer, (unsigned char *)dest, len);
    }

    return 0;
}

static int can_handle(const char *name)
{
    return (is_ext(name, ".psf2") || is_ext(name, ".minipsf2") ||
			is_ext(name, ".psf")  || is_ext(name, ".minipsf"));
}

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN psf2_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
	#ifndef _WIN32
        char *home = getenv("HOME");
        if (home == NULL) {
            fprintf(stderr, "INIT_SOUND_PLUGIN: unable to set \
                oldplay home directory.\nThe $HOME variable is not defined");
            exit(-1);
        }
        sprintf(oldplay_home, "%s/.oldplay", home);
    #endif

        memset(&plugin, 0, sizeof(plugin));
        plugin.plugname         = "highly_experimental";
        plugin.init_file        = init_file;
        plugin.fill_buffer      = fill_buffer;
        plugin.can_handle       = can_handle;
        plugin.close            = close;
        plugin.shutdown         = shutdown;

        plugin.channels   = 2;
        plugin.freq       = 44100;
        plugin.replaygain = 1;
        plugin.tune       = 0;
        plugin.subtunes   = 1;
        plugin.clockfreq  = 275;
        return &plugin;
    }

}
