/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "sc68/sc68.h"

#include "../plugin.h"
#include "../util.h"

static struct sound_plugin plugin;
sc68_t *sc68 = 0;
static int is_seeking;
static int first_run = 1;

static char oldplay_home[128];

static int playing;
static string fieldname[5];
static string fielddata[5];
static string filename;
static int set_position(int msecs, int subtune);

static int init_file(char *fname)
{
    int x = 0;

    playing = 0;
    plugin.tune = 0;
    plugin.subtunes = 1;

    if (first_run) {
        if (sc68_init(0)) goto error;
        if (sc68 = sc68_create(0), !sc68) {
            fprintf(stderr, "init_file: sc68_create error\n");
            goto error;
        }

        /* sc68_set_user(sc68, oldplay_home); */
        sc68_set_user(sc68, "./");
        first_run = 0;
    }

    int err;
    if ((err = sc68_load_url(sc68, fname))) {
        fprintf(stderr, "init_file: sc68_load_url failed (%d)\n", err);
        goto error;
    }

    if ((err = sc68_play(sc68, 1, 1))) {
        fprintf(stderr, "init_file: sc68_play failed (%d)\n", err);
        goto error;
    }

	plugin.freq = sc68_sampling_rate(sc68, plugin.freq);

    sc68_music_info_t info;
	if( !sc68_music_info(sc68, &info, 0, 0) ) {
    	if( info.title ) {
            fieldname[x] = "Song";
            fielddata[x++] = info.title;
        }

    	if( info.album ) {
            fieldname[x] = "Album";
            fielddata[x++] = info.album;
        }

        if( info.artist ) {
            fieldname[x] = "Artist";
            fielddata[x++] = info.artist;
        }

		plugin.subtunes = info.tracks;
		plugin.length = info.trk.time_ms ? info.trk.time_ms : 200000;
	}
	else {
        char *tmp = strrchr(fname, '/');
        fieldname[x] = "Song";
        fielddata[x++] = tmp ? tmp+1 : fname;

		plugin.subtunes = 1;
		plugin.length = 120000;
	}

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields  = x;

    playing = 1;
    is_seeking = 0;
    return 0;

error:
	sc68_destroy(sc68);
	return -1;
}

static int close()
{
    sc68_close(sc68);

    for(int i = 0; i < plugin.nfields; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }

    playing = plugin.tune = plugin.subtunes = plugin.length = plugin.nfields = 0;
    return 0;
}

static void shutdown()
{
    sc68_destroy(sc68);
    sc68_shutdown();
    first_run = 1;
}

static int fill_buffer(signed short *dest, int len)
{
	if(playing) {
	    int n = len >> 2;
        if (!(sc68_process(sc68, dest, &n) & SC68_END))
            return len;
    }

    return 0;
}

static int set_position(int msecs, int subtune)
{
    if (!playing)
        return 0;

    if( !msecs ) {
       	sc68_stop(sc68);
    	sc68_play(sc68, subtune, 1);

    	sc68_music_info_t info;
    	if( !sc68_music_info(sc68, &info, subtune, 0) ) {
            int x = 0;
        	if( info.title ) {
                fieldname[x] = "Song";
                fielddata[x++] = info.title;
            }

        	if( info.album ) {
                fieldname[x] = "Album";
                fielddata[x++] = info.album;
            }

            if( info.artist ) {
                fieldname[x] = "Artist";
                fielddata[x++] = info.artist;
            }

            plugin.fieldname = fieldname;
            plugin.fielddata = fielddata;
            plugin.nfields  = x;

    		plugin.subtunes = info.tracks;
    		plugin.length = info.trk.time_ms ? info.trk.time_ms : 200000;
    	}
    	else {
    		plugin.subtunes = 1;
    		plugin.length = 120000;
    	}
    }
    else {
   		sc68_seek(sc68, SC68_SEEK_TRACK, msecs, &is_seeking);

        /* flush audio output */
        #define CHUNK_SIZE (1024*2)
        signed short samples[CHUNK_SIZE];
        int length = CHUNK_SIZE >> 1;
        while( is_seeking ) {
            sc68_seek(sc68, SC68_SEEK_TRACK, -1, &is_seeking);
            int err = sc68_process(sc68, samples, &length) & SC68_END;
            if (err) {
                fprintf(stderr, "set_position: seek error\n");
                is_seeking = 0;
                break;
            }
        }

   		return msecs;
    }

    return 0;
}


static int can_handle(const char *name)
{
    return (is_ext(name, ".sc68") || is_ext(name, ".sndh"));
}

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN sc68_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
    #ifndef _WIN32
        char *home = getenv("HOME");
        if (home == NULL) {
            fprintf(stderr, "INIT_SOUND_PLUGIN: unable to set \
                oldplay home directory.\nThe $HOME variable is not defined");
            exit(-1);
        }
        sprintf(oldplay_home, "%s/.oldplay", home);
    #endif

        memset(&plugin, 0, sizeof(plugin));
        plugin.plugname         = "sc68";
        plugin.init_file        = init_file;
        plugin.set_position     = set_position;
        plugin.fill_buffer      = fill_buffer;
        plugin.can_handle       = can_handle;
        plugin.close            = close;
        plugin.shutdown         = shutdown;

        plugin.channels         = 2;
        plugin.freq             = 44100;
        plugin.replaygain       = 1;

    #ifdef A320
        plugin.clockfreq = 336;
    #else
        plugin.clockfreq = 200;
    #endif

        return &plugin;
    }

}

