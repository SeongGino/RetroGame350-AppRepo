/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "../plugin.h"

static struct sound_plugin plugin;

static int playing;
static string fieldname[1];
static string fielddata[1];
static string filename;
static int set_position(int msecs, int subtune);

int main(int argc, char *argv[])
{
}

static int init_file(char *fname)
{
    return -1;
}

static int can_handle(const char *name)
{
    return 0;
}

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN dummy_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
        memset(&plugin, 0, sizeof(plugin));
        plugin.plugname         = "dummy";
        plugin.init_file        = init_file;
        plugin.can_handle       = can_handle;
        plugin.channels   = 2;
        plugin.freq       = 44100;
        plugin.replaygain = 1;

        return &plugin;
    }

}

