/*
    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#ifdef HAVE_PTHREAD_H
#include <pthread.h>
#else
#include <SDL/SDL_thread.h>
#endif

#include "vbam/gba/GBA.h"
#include "vbam/gba/Sound.h"
#include "psflib/psflib.h"

extern "C" {
    #include "yaneurao/ring_buffer.h"
}

#include "../plugin.h"
#include "../util.h"

static struct sound_plugin plugin;
static int playing;
static string fieldname[5];
static string fielddata[5];

#ifdef HAVE_PTHREAD_H
static pthread_t vbam_thread_id = 0;
static pthread_attr_t pattr;
static sched_param param;
#else
static SDL_Thread *thread;
#endif

static ring_buffer_t buffer;
static int first_run = 1;

int cfg_declicking = 1;
int cfg_interpolation = 1;

#define DBG(a)
#define BORK_TIME 0xC0CAC01A

static unsigned long parse_time_crap(const char *input)
{
	if (!input) return BORK_TIME;
	int len = strlen(input);
	if (!len) return BORK_TIME;
	int value = 0;
	{
		int i;
		for (i = len - 1; i >= 0; i--)
		{
			if ((input[i] < '0' || input[i] > '9') && input[i] != ':' && input[i] != ',' && input[i] != '.')
			{
				return BORK_TIME;
			}
		}
	}
	char *bar = (char *)input;
	char *strs = bar + len - 1;
	while (strs > bar && (*strs >= '0' && *strs <= '9'))
	{
		strs--;
	}
	if (*strs == '.' || *strs == ',')
	{
		// fraction of a second
		strs++;
		if (strlen(strs) > 3) strs[3] = 0;
		value = atoi(strs);
		switch (strlen(strs))
		{
		case 1:
			value *= 100;
			break;
		case 2:
			value *= 10;
			break;
		}
		strs--;
		*strs = 0;
		strs--;
	}
	while (strs > bar && (*strs >= '0' && *strs <= '9'))
	{
		strs--;
	}
	// seconds
	if (*strs < '0' || *strs > '9') strs++;
	value += atoi(strs) * 1000;
	if (strs > bar)
	{
		strs--;
		*strs = 0;
		strs--;
		while (strs > bar && (*strs >= '0' && *strs <= '9'))
		{
			strs--;
		}
		if (*strs < '0' || *strs > '9') strs++;
		value += atoi(strs) * 60000;
		if (strs > bar)
		{
			strs--;
			*strs = 0;
			strs--;
			while (strs > bar && (*strs >= '0' && *strs <= '9'))
			{
				strs--;
			}
			value += atoi(strs) * 3600000;
		}
	}
	return value;
}

struct psf_info_meta_state
{
    unsigned int volume;
    unsigned int replaygain;

    char title[256];
    char artist[256];
    char game[256];
    char year[256];
    char genre[256];
    char psfby[256];
    char comment[256];
    char copyright[256];

	bool utf8;

	int tag_song_ms;
	int tag_fade_ms;

	psf_info_meta_state()
		: utf8( false ), tag_song_ms( 0 ), tag_fade_ms( 0 )
	{
	    replaygain = 0;
	    volume = 0;

	    title[0] = '\0';
        artist[0] = '\0';
        game[0] = '\0';
        year[0] = '\0';
        genre[0] = '\0';
        psfby[0] = '\0';
        comment[0] = '\0';
        copyright[0] = '\0';
	}
};

static int psf_info_meta(void * context, const char * name, const char * value)
{
	psf_info_meta_state * state = ( psf_info_meta_state * ) context;

    const char *tag = name;

    if (!strncmp(tag, "title", 5))
	{
		strcpy(state->title, value);
	}
    else if (!strncmp(tag, "artist", 6))
	{
		strcpy(state->artist, value);
	}
	else if (!strncmp(tag, "game", 4))
	{
		strcpy(state->game, value);
	}
	else if (!strncmp(tag, "copyright", 9))
	{
        strcpy(state->copyright, value);
	}
	else if (!strncmp(tag, "genre", 5))
	{
		strcpy(state->genre, value);
	}
	else if (!strncmp(tag, "year", 4))
	{
		strcpy(state->year, value);
	}
	else if (!strncmp(tag, "length", 6))
	{
		DBG("reading length");
		unsigned long temp = parse_time_crap(value);
		if (temp != BORK_TIME)
		{
			state->tag_song_ms = temp;
		}
	}
	else if (!strncmp(tag, "fade", 4))
	{
		DBG("reading fade");
		unsigned long temp = parse_time_crap(value);
		if (temp != BORK_TIME)
		{
			state->tag_fade_ms = temp;
        }
	}
	else if (!strncmp(tag, "utf8", 4))
	{
		state->utf8 = true;
	}
	else if (!strncmp(tag, "_lib", 4))
	{
		DBG("found _lib");
	}
	else if (!strncmp(tag, "_refresh", 8))
	{
		DBG("found _refresh");
	}
	else if (tag[0] == '_')
	{
		DBG("found unknown required tag, failing");
		return -1;
	}

	return 0;
}

struct gsf_loader_state
{
    int entry_set;
    uint32_t entry;
    uint8_t * data;
    size_t data_size;
	gsf_loader_state() : entry_set( 0 ), data( 0 ), data_size( 0 ) { }
	~gsf_loader_state() { if ( data ) free( data ); }
};

inline unsigned get_le32( void const* p )
{
    return  (unsigned) ((unsigned char const*) p) [3] << 24 |
            (unsigned) ((unsigned char const*) p) [2] << 16 |
            (unsigned) ((unsigned char const*) p) [1] <<  8 |
            (unsigned) ((unsigned char const*) p) [0];
}

int gsf_loader(void * context, const uint8_t * exe, size_t exe_size,
                                  const uint8_t * reserved, size_t reserved_size)
{
    if ( exe_size < 12 ) return -1;

    struct gsf_loader_state * state = ( struct gsf_loader_state * ) context;

    unsigned char *iptr;
    unsigned isize;
    unsigned char *xptr;
    unsigned xentry = get_le32(exe + 0);
    unsigned xsize = get_le32(exe + 8);
    unsigned xofs = get_le32(exe + 4) & 0x1ffffff;
    if ( xsize < exe_size - 12 ) return -1;
    if (!state->entry_set)
    {
        state->entry = xentry;
        state->entry_set = 1;
    }
    {
        iptr = state->data;
        isize = state->data_size;
        state->data = 0;
        state->data_size = 0;
    }
    if (!iptr)
    {
        unsigned rsize = xofs + xsize;
        {
            rsize -= 1;
            rsize |= rsize >> 1;
            rsize |= rsize >> 2;
            rsize |= rsize >> 4;
            rsize |= rsize >> 8;
            rsize |= rsize >> 16;
            rsize += 1;
        }
        iptr = (unsigned char *) malloc(rsize + 10);
        if (!iptr)
            return -1;
        memset(iptr, 0, rsize + 10);
        isize = rsize;
    }
    else if (isize < xofs + xsize)
    {
        unsigned rsize = xofs + xsize;
        {
            rsize -= 1;
            rsize |= rsize >> 1;
            rsize |= rsize >> 2;
            rsize |= rsize >> 4;
            rsize |= rsize >> 8;
            rsize |= rsize >> 16;
            rsize += 1;
        }
        xptr = (unsigned char *) realloc(iptr, xofs + rsize + 10);
        if (!xptr)
        {
            free(iptr);
            return -1;
        }
        iptr = xptr;
        isize = rsize;
    }
    memcpy(iptr + xofs, exe + 12, xsize);
    {
        state->data = iptr;
        state->data_size = isize;
    }
    return 0;
}

struct gsf_sound_out : public GBASoundOut
{
    virtual ~gsf_sound_out() { }
    // Receives signed 16-bit stereo audio and a byte count
    virtual void write(const void * samples, unsigned long bytes)
    {
        ring_write(&buffer, (unsigned char *) samples, bytes);
    }
};

struct psf_file_state
{
	FILE *f;
};

static void * psf_file_fopen( const char * uri )
{
    psf_file_state * state = new psf_file_state;
	state->f = fopen( uri, "rb" );
	if ( state->f != NULL)
        return state;

	fprintf(stderr, "psf_file_open: failed to load ´%s'.\n", uri);
	return NULL;
}

static size_t psf_file_fread( void * buffer, size_t size, size_t count, void * handle )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    size_t bytes_read = fread( buffer, size, count, state->f );
    return bytes_read / size;
}

static int psf_file_fseek( void * handle, int64_t offset, int whence )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    return fseek( state->f, offset, whence );
}

static int psf_file_fclose( void * handle )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    fclose( state->f );
    delete state;
    return 0;
}

static long psf_file_ftell( void * handle )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    return ftell( state->f );
}

const psf_file_callbacks psf_file_system =
{
	"\\/|:",
	psf_file_fopen,
	psf_file_fread,
	psf_file_fseek,
	psf_file_fclose,
	psf_file_ftell
};

gsf_loader_state * m_rom;
psf_info_meta_state *m_info;
gsf_sound_out m_output;
GBASystem * m_system;

/* vbam emulation thread */
#ifdef HAVE_PTHREAD_H
static void *vbam_thread(void *data)
{
    while ( buffer.sexy_thread_exit_flag != 1 ) {
        CPULoop( m_system, 250000 );
    }
    pthread_exit ( 0 );
}
#else
int vbam_thread(void *unused)
{
    while ( buffer.sexy_thread_exit_flag != 1 ) {
        CPULoop( m_system, 250000 );
    }
    return 0;
}
#endif


static int init_file(char *fname)
{
    playing = 0;

    m_system = new GBASystem;
    m_rom = new gsf_loader_state;
    m_info = new psf_info_meta_state;

    if ( psf_load( fname, &psf_file_system, 0x22, gsf_loader, m_rom, psf_info_meta, m_info ) < 0 )
    {
        fprintf( stderr, "init_file: invalid GSF" );
        return -1;
    }

    m_system->cpuIsMultiBoot = ((m_rom->entry >> 24) == 2);
    m_system->soundDeclicking = !!cfg_declicking;
    m_system->soundInterpolation = !!cfg_interpolation;

    CPULoadRom( m_system, m_rom->data, m_rom->data_size );
    delete m_rom;

    soundInit( m_system, &m_output );
    soundReset( m_system );

    CPUInit( m_system );
    CPUReset( m_system );

    int x = 0;
    if (m_info->title)
    {
        fieldname[x] = "Title";
        fielddata[x++] = m_info->title;
    }
    if (m_info->game)
    {
        fieldname[x] = "Game";
        fielddata[x++] = m_info->game;
    }
    if (m_info->artist)
    {
        fieldname[x] = "Artist";
        fielddata[x++] = m_info->artist;
    }
    if (m_info->copyright)
    {
        fieldname[x] = "Copyright";
        fielddata[x++] = m_info->copyright;
    }

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields = x;
    plugin.length = m_info->tag_song_ms > 0 ? m_info->tag_song_ms : 3 * 60 * 1000;

	if (first_run) {
        ring_init(&buffer, BLOCK_SIZE / 4, BLOCK_COUNT * 2);
        first_run = 0;
    } else ring_reset(&buffer);

    /* create emulation thread */
#ifdef HAVE_PTHREAD_H
	pthread_attr_init(&pattr);
	pthread_attr_getschedparam (&pattr, &param);

	/* set the priority; others are unchanged */
	param.sched_priority = 0;/* -20 high to 19 low. 0 == default */

   	/* setting the new scheduling param */
	pthread_attr_setschedparam (&pattr, &param);
    pthread_create( &vbam_thread_id, &pattr, vbam_thread, NULL);
#else
	thread = SDL_CreateThread(vbam_thread, NULL);
    if ( thread == NULL ) {
        fprintf(stderr, "init_file: unable to create thread: %s\n", SDL_GetError());
        return -1;
    }
#endif
    playing = 1;
    return 0;
}

static int close()
{
    if (m_system) {
#ifdef HAVE_PTHREAD_H
		if( vbam_thread_id ) {
            ring_stop(&buffer);
			m_system->cpuBreakLoop = true;
            pthread_join(vbam_thread_id, NULL);
            vbam_thread_id = 0;
        }
#else
        if( thread ) {
            ring_stop(&buffer);
            m_system->cpuBreakLoop = true;
			SDL_WaitThread(thread, NULL);
            thread = NULL;
        }
#endif
        CPUCleanUp( m_system );
		soundShutdown( m_system );

		delete m_system;
		m_system = NULL;
    }

    for(int i = 0; i < 5; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }

    playing = plugin.length = plugin.nfields = 0;
    return 0;
}

static void shutdown()
{
    ring_close(&buffer);
    first_run = 1;
}

static int fill_buffer(signed short *dest, int len)
{
    if(playing) {
        return ring_read(&buffer, (unsigned char *) dest, len);
    }
    return 0;
}

static int can_handle(const char *name)
{
    return (is_ext(name, ".gsf") || is_ext(name, ".minigsf"));
}

extern "C" {

	#ifndef INIT_SOUND_PLUGIN
		#define INIT_SOUND_PLUGIN gsf_init_sound_plugin
	#endif

	struct sound_plugin *INIT_SOUND_PLUGIN()
	{
		memset(&plugin, 0, sizeof(plugin));
		plugin.plugname = "viogsf";
		plugin.init_file        = init_file;
		plugin.fill_buffer      = fill_buffer;
		plugin.can_handle       = can_handle;
		plugin.close            = close;
		plugin.shutdown         = shutdown;

		plugin.channels   = 2;
		plugin.freq       = 44100;
		plugin.replaygain = 1;
		plugin.tune       = 0;
		plugin.subtunes   = 1;
		plugin.clockfreq  = 275;
		return &plugin;
	}

}

