/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <sys/stat.h>
#include <stdarg.h>

#include <opusfile.h>

#include "../plugin.h"
#include "../util.h"

enum {
	OF_SUCCESS = 1,
	OF_FAILURE = -1
};

static struct sound_plugin plugin;

OggOpusFile  *of = NULL;
unsigned char out[120*48*2*2];
int is_url;

ogg_int64_t nsamples;
int         prev_li;

static int playing = 0;
static int fsize;

static int readposbytes;
static size_t writeposbytes;
static bool quit_thread;

static string fieldname[5];
static string fielddata[5];

static int local_strncasecmp(const char *_a,const char *_b,int _n)
{
	int i;
	for ( i = 0; i <_n; i++ ) {
		int a;
		int b;
		int d;
		a = _a[i];
		b = _b[i];
		if ( a >= 'a' && a <= 'z' ) a -= 'a' - 'A';
		if ( b >= 'a' && b <= 'z' ) b -= 'a' - 'A';
		d = a - b;
		if ( d ) return d;
	}
	return 0;
}

int decode_block(size_t *done)
{
	static int    parse_tags = 1;
    opus_int16    pcm[120*48*2];
    int           li;
    int           si;
    /*Although we would generally prefer to use the float interface, WAV
       files with signed, 16-bit little-endian samples are far more
       universally supported, so that's what we output.*/
    int ret = op_read_stereo(of, pcm, sizeof(pcm) / sizeof(*pcm));
    if ( ret < 0 ) {
		fprintf(stderr, "decode_block: error decoding: %i\n", ret);
		if ( is_url ) fprintf(stderr,"\tpossible truncation attack?\n");
		return OF_FAILURE;
    }

    if ( parse_tags ) {
		li = op_current_link(of);
		if ( li != prev_li ) {
			const OpusTags *tags;
			int             ci;
			int				x = 1;

			tags = op_tags(of, li);

			if ( tags->vendor ) {
				fieldname[x] = "Vendor";
				fielddata[x++] = tags->vendor;
			}

			for ( ci = 0; ci < tags->comments; ci++ ) {
				const char *comment;
				comment = tags->user_comments[ci];
				if ( local_strncasecmp(comment, "METADATA_BLOCK_PICTURE=", 23) == 0 ) {
					fprintf(stderr, "decode_block: metadata block picture found\n");
				}
				else {
					fieldname[x] = "Comment";
					fielddata[x++] = comment;
					if ( x == 5 ) break;
				}
			}

			plugin.fieldname = fieldname;
			plugin.fielddata = fielddata;
			plugin.nfields   = x;
			parse_tags = 0;
		}
	}

    if ( ret <= 0) {
        return OF_SUCCESS;
    }

    /* Ensure the data is little-endian before writing it out. */
    for ( si = 0; si < 2 * ret; si++ ) {
		out[2*si+0] = (unsigned char)(pcm[si] & 0xFF);
		out[2*si+1] = (unsigned char)(pcm[si] >> 8 & 0xFF);
	}

	*done = sizeof(*out)*4*ret;
    nsamples += ret;
    prev_li = li;

    return 0;
}
static int fill_buffer(signed short *dest, int len)
{
	if(playing)
	{
        int writtenbytes = 0;
        for (;;)
        {
            int bytesleft = len - writtenbytes;
            int bufbytes  = writeposbytes - readposbytes;
            //printf("len = %04d - written = %04d = %04d, " \
                    "read = %04d - write = %04d = %04d\n",\
                len,writtenbytes,bytesleft,readposbytes,writeposbytes,bufbytes);
            if (bytesleft <= bufbytes)
            {
                memcpy((char*)dest + writtenbytes, (char*)out + readposbytes, bytesleft);
                readposbytes += bytesleft;
                writtenbytes = len;
                break;
            }
            else
            {
                memcpy((char*)dest + writtenbytes, (char*)out + readposbytes, bufbytes);
                writtenbytes += bufbytes;
                readposbytes = writeposbytes = 0;

                int ret = decode_block(&writeposbytes);
            	if (ret != 0) break;

                if (!writeposbytes)
                    break;
            }
        }
        return writtenbytes;
	}

	return 0;
}

static int close()
{
    if (of) {
		op_free(of);
		of = NULL;
	}

    for(int i = 0; i < 5; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }

    playing = plugin.tune = plugin.subtunes = plugin.length = plugin.nfields = 0;
	return 0;
}

static int init_file(char *fname)
{
	is_url = 0;
	prev_li = -1;
	nsamples = 0;
	plugin.length = -1;

	int ret;
    of = op_open_url(fname, &ret, NULL);
    if ( of == NULL ) of = op_open_file(fname, &ret);
    else is_url = strncmp(fname, "http", 4) == 0;

    if ( of == NULL ) {
		fprintf(stderr, "init_file: op_open_xxx failed '%s'\n", fname);
		return -1;
    }

	if ( (plugin.length = op_pcm_total(of, -1) / 48) < 0 )
        plugin.length = 0;

	if ( is_url ) fieldname[0] = "URL";
	else fieldname[0] = "Stream";
	fielddata[0] = base_name(fname);

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields   = 1;

    writeposbytes = 0;
    readposbytes  = 0;
	playing = 1;
	return 0;
}

static int set_position(int msecs, int subtune)
{
	if (msecs)
    {
		ogg_int64_t pcm_offset = msecs * 48, pcm_offset2;
        op_pcm_seek(of, pcm_offset);
		pcm_offset2 = op_pcm_tell(of);
        return (long) pcm_offset2 / 48;
    }
    return 0;
}

static int can_handle(const char *name)
{
	return is_ext(name, ".opus");
}

#ifndef STATIC
int main(int argc, char* argv[])
{
	return 0;
}
#endif

extern "C" {
    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN opus_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
		memset(&plugin, 0, sizeof(plugin));

        plugin.plugname     = "opus";
        plugin.init_file    = init_file;
        plugin.close        = close;
        plugin.fill_buffer  = fill_buffer;
        plugin.set_position = set_position;
        plugin.can_handle   = can_handle;
        plugin.freq 		= 48000;
		plugin.channels 	= 2;
        plugin.clockfreq    = 150;
        plugin.replaygain   = 1;
		plugin.subtunes 	= 1;
		plugin.tune 		= 0;

        return &plugin;
    }
}

