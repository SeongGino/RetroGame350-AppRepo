/*
    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#ifdef HAVE_PTHREAD_H
#include <pthread.h>
#else
#include <SDL/SDL_thread.h>
#endif

extern "C" {
    #include "upse/upse.h"
    #include "yaneurao/ring_buffer.h"
}

#include "../plugin.h"
#include "../util.h"

static struct sound_plugin plugin;
static int playing;
static string fieldname[5];
static string fielddata[5];

upse_module_t *mod;
static ring_buffer_t buffer;
static int first_run = 1;

#ifdef HAVE_PTHREAD_H
static pthread_t upse_thread_id = 0;
static pthread_attr_t pattr;
static sched_param param;
#else
static SDL_Thread *thread;
#endif

void upse123_write_audio(unsigned char* data, long bytes, void *unused)
{
	ring_write(&buffer, data, bytes);
}

/* upse emulation thread */
#ifdef HAVE_PTHREAD_H
static void *upse_thread(void *data)
{
    upse_eventloop_run(mod);
    ring_stop(&buffer);
    pthread_exit ( 0 );
}
#else
int upse_thread(void *unused)
{
    upse_eventloop_run(mod);
    ring_stop(&buffer);
    return 0;
}
#endif

/* upse io functions */
static void *upse123_open_impl(const char *path, const char *mode)
{
    FILE *f = fopen(path, mode);
    if (f == NULL) {
        fprintf(stderr, "upse123_open_impl: failed to open `%s'.", path);
    }
    return f;
}

static size_t upse123_read_impl(void *ptr, size_t sz, size_t nmemb, void *file)
{
    FILE *f = (FILE *) ptr;

    return fread(f, sz, nmemb, (FILE *) file);
}

static int upse123_seek_impl(void *ptr, long offset, int whence)
{
    FILE *f = (FILE *) ptr;

    return fseek(f, offset, whence);
}

static int upse123_close_impl(void *ptr)
{
    FILE *f = (FILE *) ptr;

    return fclose(f);
}

static long upse123_tell_impl(void *ptr)
{
    FILE *f = (FILE *) ptr;

    return ftell(f);
}

static upse_iofuncs_t upse123_iofuncs = {
    upse123_open_impl,
    upse123_read_impl,
    upse123_seek_impl,
    upse123_close_impl,
    upse123_tell_impl
};

static int init_file(char *fname)
{
    playing = 0;
    if ((mod = upse_module_open(fname, &upse123_iofuncs)) == NULL)
    {
        fprintf(stderr, "init_file: failed to load `%s'\n", fname);
        return -1;
    }

    int x = 0;
    upse_psf_t *meta = mod->metadata;
    if (meta->title)
    {
        fieldname[x] = "Title";
        fielddata[x++] = meta->title;
    }
    if (meta->game)
    {
        fieldname[x] = "Game";
        fielddata[x++] = meta->game;
    }
    if (meta->artist)
    {
        fieldname[x] = "Artist";
        fielddata[x++] = meta->artist;
    }
    if (meta->copyright)
    {
        fieldname[x] = "Copyright";
        fielddata[x++] = meta->copyright;
    }

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields = x;
    plugin.length = meta->length;

    if (first_run) {
        ring_init(&buffer, BLOCK_SIZE / 4, BLOCK_COUNT * 2);
        first_run = 0;
    } else ring_reset(&buffer);

    upse_eventloop_set_audio_callback(mod, (upse_audio_callback_func_t) upse123_write_audio, NULL);

	/* create emulation thread */
#ifdef HAVE_PTHREAD_H
	pthread_attr_init(&pattr);
	pthread_attr_getschedparam (&pattr, &param);

	/* set the priority; others are unchanged */
	param.sched_priority = 0;/* -20 high to 19 low. 0 == default */

   	/* setting the new scheduling param */
	pthread_attr_setschedparam (&pattr, &param);
    pthread_create( &upse_thread_id, &pattr, upse_thread, NULL);
#else
    thread = SDL_CreateThread(upse_thread, NULL);
    if ( thread == NULL ) {
        fprintf(stderr, "init_file: unable to create thread: %s\n", SDL_GetError());
        return -1;
    }
#endif

    playing = 1;
    return 0;
}

static int close()
{
    if (mod) {
#ifdef HAVE_PTHREAD_H
        if( upse_thread_id ) {
            ring_stop(&buffer);
            upse_eventloop_stop(mod);
            pthread_join(upse_thread_id, NULL);
            upse_thread_id = 0;
        }
#else
        if( thread ) {
            ring_stop(&buffer);
            upse_eventloop_stop(mod);
            SDL_WaitThread(thread, NULL);
            thread = NULL;
        }
#endif
        upse_module_close(mod);
        mod = 0;
    }

    for(int i = 0; i < 5; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }

    playing = plugin.length = plugin.nfields = 0;
    return 0;
}

static void shutdown()
{
    // free upse_module_init allocated data
    ring_close(&buffer);
    first_run = 1;
}

static int fill_buffer(signed short *dest, int len)
{
    if(playing) {
        return ring_read(&buffer, (unsigned char *)dest, len);
    }

    return 0;
}

static int can_handle(const char *name)
{
    return (is_ext(name, ".psf") || is_ext(name, ".minipsf"));
}

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN psf_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
        upse_module_init();

        memset(&plugin, 0, sizeof(plugin));
        plugin.plugname         = "upse";
        plugin.init_file        = init_file;
        plugin.fill_buffer      = fill_buffer;
        plugin.can_handle       = can_handle;
        plugin.close            = close;
        plugin.shutdown         = shutdown;

        plugin.channels   = 2;
        plugin.freq       = 44100;
        plugin.replaygain = 1;
        plugin.tune       = 0;
        plugin.subtunes   = 1;
        plugin.clockfreq  = 275;
        return &plugin;
    }

}

