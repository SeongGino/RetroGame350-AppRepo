#ifndef _DC_HW_H_
#define _DC_HW_H_

extern uint8 dc_ram[8*1024*1024];

void dc_hw_init(void);

#endif

