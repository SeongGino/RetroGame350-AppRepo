/*
    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#ifdef HAVE_PTHREAD_H
#include <pthread.h>
#else
#include <SDL/SDL_thread.h>
#endif

#ifdef _WIN32
#include <windows.h>
#endif

extern "C" {
    #include "ao.h"
    #include "eng_protos.h"
    #include "yaneurao/ring_buffer.h"
}

#include "../plugin.h"
#include "../util.h"

static struct sound_plugin plugin;
static int playing;
static string fieldname[5];
static string fielddata[5];

static ring_buffer_t buffer;
static int first_run = 1;

#ifdef HAVE_PTHREAD_H
static pthread_t dc_thread_id = 0;
static pthread_attr_t pattr;
static sched_param param;
#else
static SDL_Thread *thread;
#endif

int ao_get_lib(char *filename, uint8 **buffer, uint64 *length)
{
	uint8 *filebuf;
	uint32 size;
	FILE *auxfile;

	auxfile = fopen(filename, "rb");
	if (!auxfile)
	{
		printf("Unable to find auxiliary file %s\n", filename);
		return AO_FAIL;
	}

	fseek(auxfile, 0, SEEK_END);
	size = ftell(auxfile);
	fseek(auxfile, 0, SEEK_SET);

	filebuf = (uint8 *) malloc(size);

	if (!filebuf)
	{
		fclose(auxfile);
		printf("ERROR: could not allocate %d bytes of memory\n", size);
		return AO_FAIL;
	}

	fread(filebuf, size, 1, auxfile);
	fclose(auxfile);

	*buffer = filebuf;
	*length = (uint64)size;

	return AO_SUCCESS;
}

/* dreamcast emulation thread */
#ifdef HAVE_PTHREAD_H
static void *dc_thread(void *data)
{
	INT16 *sample_buffer[1024 * 2];
    int samples_to_render = 1024;
    while ( buffer.sexy_thread_exit_flag != 1 ) {
        dsf_gen( sample_buffer, samples_to_render );
		ring_write(&buffer, (unsigned char *)sample_buffer, samples_to_render * 4 );
    }

    ring_stop(&buffer);
    pthread_exit ( 0 );
}
#else
int dc_thread(void *unused)
{
	INT16 sample_buffer[1024 * 2];
    int samples_to_render = 1024;
    while ( buffer.sexy_thread_exit_flag != 1 ) {
        dsf_gen( sample_buffer, samples_to_render );
		ring_write(&buffer, (unsigned char *)sample_buffer, samples_to_render * 4 );
    }


    ring_stop(&buffer);
    return 0;
}
#endif

static int init_file(char *fname)
{
    playing = 0;

    FILE *file;
	uint8 *buffer;
	uint32 size, filesig;

	file = fopen(fname, "rb");
	if (!file)
	{
		printf("ERROR: could not open file %s\n", fname);
		return -1;
	}

	// get the length of the file by seeking to the end then reading the current position
	fseek(file, 0, SEEK_END);
	size = ftell(file);
	// reset the pointer
	fseek(file, 0, SEEK_SET);

	buffer = (uint8 *) malloc(size);
	if (!buffer)
	{
		fclose(file);
		printf("ERROR: could not allocate %d bytes of memory\n", size);
		return -1;
	}

	// read the file
	fread(buffer, size, 1, file);
	fclose(file);

	if (dsf_start(buffer, size) != AO_SUCCESS)
	{
		free(buffer);
		printf("ERROR: Engine rejected file!\n");
		return -1;
	}

    int x = 0;
    fieldname[x] = "Title";
    fielddata[x++] = base_name(fname);

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields = x;

    plugin.length = 3 * 60 * 1000;

	/* create emulation thread */
#ifdef HAVE_PTHREAD_H
	pthread_attr_init(&pattr);
	pthread_attr_getschedparam (&pattr, &param);

	/* set the priority; others are unchanged */
	param.sched_priority = 0;/* -20 high to 19 low. 0 == default */

   	/* setting the new scheduling param */
	pthread_attr_setschedparam (&pattr, &param);
    pthread_create( &dc_thread_id, &pattr, dc_thread, NULL);
#else
    thread = SDL_CreateThread(dc_thread, NULL);
    if ( thread == NULL ) {
        fprintf(stderr, "init_file: unable to create thread: %s\n", SDL_GetError());
        return -1;
    }
#endif

    playing = 1;
    return 0;
}

static int close()
{
    if (playing) {
#ifdef HAVE_PTHREAD_H
        if( dc_thread_id ) {
            ring_stop(&buffer);
            pthread_join(dc_thread_id, NULL);
            dc_thread_id = 0;
        }
#else
        if( thread ) {
            ring_stop(&buffer);
            SDL_WaitThread(thread, NULL);
            thread = NULL;
        }
#endif

    }

    for(int i = 0; i < 5; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }

    playing = plugin.length = plugin.nfields = 0;
    return 0;
}

static void shutdown()
{
    ring_close(&buffer);
    first_run = 1;
}

static int fill_buffer(signed short *dest, int len)
{
    if(playing) {
        return ring_read(&buffer, (unsigned char *)dest, len);
    }

    return 0;
}

static int can_handle(const char *name)
{
    return (is_ext(name, ".dsf") || is_ext(name, ".minidsf"));
}

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN dsf_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
	    memset(&plugin, 0, sizeof(plugin));
        plugin.plugname         = "dreamcast (ao_sdk)";
        plugin.init_file        = init_file;
        plugin.fill_buffer      = fill_buffer;
        plugin.can_handle       = can_handle;
        plugin.close            = close;
        plugin.shutdown         = shutdown;

        plugin.channels   = 2;
        plugin.freq       = 44100;
        plugin.replaygain = 1;
        plugin.tune       = 0;
        plugin.subtunes   = 1;
        plugin.clockfreq  = 275;
        return &plugin;
    }

}
