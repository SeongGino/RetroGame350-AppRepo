/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
    */
#ifndef MUSIC_PLAYER_H
#define MUSIC_PLAYER_H

#include <vector>
#include <string>

#include "plugin.h"

#define SOFTVOL     20
#define VOLSTEPS    50
#define MAXVOL      100

#if !defined(BLOCK_SIZE) || !defined(BLOCK_COUNT)
    #error "BLOCK_SIZE, BLOCK_COUNT not defined!"
#endif

class BlockFifo;

class MusicPlayer
{
    public:
        MusicPlayer(bool);

        bool Play(const char *name, char *data = NULL, int size = -1,
                      int time_ms = -1, int subtune = -1);
        bool Pause()   { return audio_paused = !audio_paused; }
        void Stop()    { songend_samples = -1; }

        bool CanHandle(const char *name);
        bool HeavySong()   { return heavy_song; }
        bool AudioOpened() { return audio_opened; }
        bool Playing() { return song_playing; }

        int GetTotalTunes() { return (current_plugin ? current_plugin->subtunes : -1); }
        int GetTune()     {
            if( current_plugin && (current_plugin->tune > current_subtune) )
                return current_plugin->tune;
            else return current_subtune;
        }
        int GetVolume()   { return current_vol; }
        int GetSeconds()  { return current_plugin ? total_samples /
                                (current_plugin->freq*current_plugin->channels) : 0; }
        int GetLength()   { return current_plugin ? current_plugin->length / 1000 : -1; }
#ifdef ENABLE_BLEND_FILTER
        int GetBlendFactor()    { return blend_factor; }
#endif
        int GetNextSamples(short *dest, int len);

        int    GetNFields() { return (current_plugin ? current_plugin->nfields : 0); }
        string GetFieldName(int i)  { return (current_plugin &&
            current_plugin->fieldname ? current_plugin->fieldname[i] : "");}
        string GetFieldData(int i)  { return (current_plugin &&
            current_plugin->fielddata ? current_plugin->fielddata[i] : "");}

        void SetTune(int n);
        void SetVolume(int v);
        void SetDefaultLength(int sec) { default_length = sec; }

#ifdef ENABLE_BLEND_FILTER
        void SetBlendFactor(int b)
        {
            if (b < 0) b = 0;
            else if (b > 128) b = 128;
            fprintf(stderr, "MusicPlayer::SetBlendFactor: changing blend factor => %d\n", b);
            blend_factor = b;
        }
#endif

    protected:
        static void audio_cb(void *userdata, Uint8 *stream, int len);
#ifdef USE_AUDIO_FIFO
        void fill_audio(BlockFifo *af, int max);
#endif
        int init_sound(int freq, int chn);
        void release_plugin();
        void load_plugins(char *path);

#ifdef USE_AUDIO_FIFO
        BlockFifo *audioFifo;
#endif
        short audiobuf[BLOCK_SIZE * BLOCK_COUNT];

        std::vector<sound_plugin*> sound_plugins;
        sound_plugin *current_plugin;
        sound_plugin *last_plugin;

        bool cpu_scaling;
        bool heavy_song;
        bool audio_opened;
        bool audio_paused;
        bool audio_locked;
        bool song_playing;

        int current_freq;
        int current_channels;
        int current_subtune;
        int current_vol;

        int blend_factor;
        int total_samples;
        int songend_samples;
        int default_length;

        char *tmp_module;
        char tmp_module_name[128];
    #ifdef USE_DEV_MIXER
        int mixer_fd = -1;
    #endif

        char temp_name[64];
};

#endif

