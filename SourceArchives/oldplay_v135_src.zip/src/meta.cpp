/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <string.h>
#include <stdio.h>
#include "meta.h"

#ifdef HAVE_ID3TAG_H
#include <id3tag.h>
#endif

#ifdef HAVE_TAGLIB_H
#include <sstream>
#include <taglib/fileref.h>
#include <taglib/tag.h>
#endif

#if defined(HAVE_TAGLIB_H) && defined(HAVE_ID3TAG_H)
#error "Please, select only one metadata library."
#endif

#ifndef _WIN32
#define stricmp strcasecmp
#define strnicmp strncasecmp
#include <unistd.h>
#else
#include <direct.h>
#endif

#ifdef HAVE_ID3TAG_H
char *get_string(struct id3_tag *id3tag, const char *what)
{
	struct id3_frame *frame = id3_tag_findframe(id3tag, what, 0);
	if(frame)
	{
		id3_field *field = &frame->fields[1];
		int nstrings = id3_field_getnstrings(field);
		for (int j=0; j<nstrings; ++j)
		{
			const id3_ucs4_t *ucs4 = id3_field_getstrings(field, j);
			id3_latin1_t *latin1 = id3_ucs4_latin1duplicate(ucs4);
			if(latin1)
				return (char*)latin1;
            //int len = strlen((char *)latin1);
		}
	}
	return NULL;
}
#endif

int parse_id3v1(char* fname, string* fieldname, string* fielddata, int max)
{
	int x = 0;
#ifdef HAVE_ID3TAG_H
	id3_file *id3file = id3_file_open(fname, ID3_FILE_MODE_READONLY);
	struct id3_tag *id3tag = id3_file_tag(id3file);

	char *s;
    if (s = get_string(id3tag, ID3_FRAME_TITLE))
    {
        fieldname[x] = "Title";
        fielddata[x] = s;
        if (s = get_string(id3tag, ID3_FRAME_TRACK))
            fielddata[x] = string(s) + ". " + fielddata[x];
        x++;
    }
    else
    {
        fieldname[x] = "File";
        fielddata[x++] = strrchr(fname,'/')+1;
    } // 1
    if (x <= max && (s = get_string(id3tag, ID3_FRAME_ALBUM)))
    {
        fieldname[x] = "Album";
        fielddata[x] = s;
        if ((s = get_string(id3tag, ID3_FRAME_YEAR)))
            fielddata[x] += " (" + string(s) + ")";
        x++;
    } // 2
	if (x <=max && (s = get_string(id3tag, ID3_FRAME_ARTIST)))
    {
        fieldname[x] = "Artist";
        fielddata[x++] = s;
    } // 3
	if (x <= max && (s = get_string(id3tag, ID3_FRAME_GENRE)))
    {
        fieldname[x] = "Genre";
        fielddata[x++] = s;
    } // 4
	if (x <= max && (s = get_string(id3tag, ID3_FRAME_COMMENT)))
    {
        fieldname[x] = "Comment";
        fielddata[x++] = s;
    }
	id3_file_close(id3file);
#endif
    return x;
}

#ifdef HAVE_TAGLIB_H
string to_string(int i)
{
    stringstream ss;
    string s;
    ss << i;
    s = ss.str();

    return s;
}
#endif

int parse_meta(char* fname, string* fieldname, string* fielddata, int max)
{
	int x = 0;
#ifdef HAVE_TAGLIB_H
	TagLib::FileRef f(fname);
	if (f.tag()->isEmpty())
		return 0;

    if (f.tag()->title().isNull() == false)
    {
        fieldname[x] = "Title";
        fielddata[x] = f.tag()->title().to8Bit();
        uint track = f.tag()->track();
        if (track)
            fielddata[x] = to_string(track) + ". " + fielddata[x];
        x++;
    }
    else
    {
        fieldname[x] = "File";
        fielddata[x++] = strrchr(fname,'/')+1;
    } // 1
    if (x <= max && (f.tag()->album().isNull() == false))
    {
        fieldname[x] = "Album";
        fielddata[x] = f.tag()->album().to8Bit();
        uint year = f.tag()->year();
        if (year)
            fielddata[x] += " (" + to_string(year) + ")";
        x++;
    } // 2
	if (x <=max && (f.tag()->artist().isNull() == false))
    {
        fieldname[x] = "Artist";
        fielddata[x++] = f.tag()->artist().to8Bit();
    } // 3
	if (x <= max && (f.tag()->genre().isNull() == false))
    {
        fieldname[x] = "Genre";
        fielddata[x++] = f.tag()->genre().to8Bit();
    } // 4
	if (x <= max && (f.tag()->comment().isNull() == false))
    {
        fieldname[x] = "Comment";
        fielddata[x++] = f.tag()->comment().to8Bit();
    }
#endif
	return x;
}
