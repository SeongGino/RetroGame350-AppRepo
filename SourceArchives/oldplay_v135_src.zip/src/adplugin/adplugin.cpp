/*
    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "adplug/adplug.h"
#include "adplug/emuopl.h"
#include "adplug/kemuopl.h"
#include "adplug/surroundopl.h"

#include "../FormatsDatabase.h"

#if !defined(GP2X) && !defined(A320)
    #define HAVE_ADPLUG_SURROUND
#endif

#include "../plugin.h"
#include "../util.h"

static int playing = 0, timer;
static struct sound_plugin plugin;
static FormatsDatabase formatsdb;

static int first_run = 1;
CAdPlugDatabase	*adplugdb;
Copl *opl;
CPlayer *player;

typedef enum { Emu_Satoh, Emu_Ken } EmuType;

static struct {
    int			freq, channels, bits, harmonic;
    EmuType		emutype;
} cfg = {
    44100,
#ifdef HAVE_ADPLUG_SURROUND
    2, 16, 1,  // Default to surround if available
#else
    1, 16, 0,  // Else default to mono (until stereo w/ single OPL is fixed)
#endif
    Emu_Satoh,
};

using namespace std;
static string fieldname[4];
static string fielddata[4];
static string filename;

static int init_file(char *fname)
{
    if( first_run ) {
        // init emulator
        switch(cfg.emutype) {
        case Emu_Satoh:
            if (cfg.harmonic) {
                Copl *a = new CEmuopl(cfg.freq, cfg.bits == 16, false);
                Copl *b = new CEmuopl(cfg.freq, cfg.bits == 16, false);
                opl = new CSurroundopl(a, b, cfg.bits == 16);
                // CSurroundopl now owns a and b and will free upon destruction
            } else {
                opl = new CEmuopl(cfg.freq, cfg.bits == 16, cfg.channels == 2);
            }
            break;
        case Emu_Ken:
            if (cfg.harmonic) {
                fprintf(stderr, "init_file: sorry, Ken's emulator only supports one instance "
                    "so does not work properly in surround mode.\n");
                // Leave the code though for future use (once Ken's emu is wrapped up
                // in a class or something.  It works, it just sounds really bad.)
                Copl *a = new CKemuopl(cfg.freq, cfg.bits == 16, false);
                Copl *b = new CKemuopl(cfg.freq, cfg.bits == 16, false);
                opl = new CSurroundopl(a, b, cfg.bits == 16);
                // CSurroundopl now owns a and b and will free upon destruction
            } else {
                opl = new CKemuopl(cfg.freq, cfg.bits == 16, cfg.channels == 2);
            }
            break;
        }

        if (!opl) {
            fprintf(stderr, "init_file: could not create opl!");
            return -1;
        }

        adplugdb = new CAdPlugDatabase;
        adplugdb->load("./adplug.db");
        CAdPlug::set_database(adplugdb);

        first_run = 1;
    }

    playing = 0;
    plugin.tune = 0;
    plugin.nfields = 0;
#ifdef A320
    plugin.clockfreq = 372;
#else
    plugin.clockfreq = 200;
#endif
    opl->init();
    player = CAdPlug::factory(fname, opl);
    if (!player) {
        fprintf(stderr, "init_file: factory error\n");
        return -1;
    }

    char *tmp = strrchr(fname, SEPARATOR);
    filename = tmp ? tmp+1 : fname;
    int x = 0;
    if (player->gettitle().length())
    {
        fieldname[x] = "Title";
        fielddata[x++] = player->gettitle();
    }
    else
    {
        fieldname[x] = "File";
        fielddata[x++] = filename;
    }

    if (player->getauthor().length())
    {
        fieldname[x] = "Artist";
        fielddata[x++] = player->getauthor();
    }
    if (player->getdesc().length())
    {
        fieldname[x] = "Description";
        fielddata[x++] = player->getdesc();
    }
    if (player->gettype().length())
    {
        fieldname[x] = "Format";
        fielddata[x++] = player->gettype();
    }

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields   = x;

    plugin.length    = player->songlength();
    plugin.subtunes  = player->getsubsongs();
    playing = 1;

    return 0;
}

static int close()
{
    if (player) {
        delete(player);
        player = NULL;
    }

    for(int i = 0; i < plugin.nfields; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }
    playing = plugin.tune = plugin.subtunes = plugin.length = plugin.nfields = 0;
    return 0;
}

static void shutdown()
{
    if (opl) {
        delete opl;
        opl = 0;
    }

    if (adplugdb) {
        delete adplugdb;
        adplugdb = 0;
    }

    first_run = 1;
}

inline unsigned char getsampsize()
{
    return cfg.channels * (cfg.bits == 8 ? 1 : 2);
}

void play_callback(unsigned char *audiobuf, int len)
{
    static long	minicnt = 0;
    long i, towrite = len / getsampsize();
    char *pos = (char *)audiobuf;

    // Prepare audiobuf with emulator output
    while(towrite > 0) {
        while(minicnt < 0) {
            minicnt += plugin.freq;
            playing = player->update();
        }
        i = min(towrite, (long)(minicnt / player->getrefresh() + 4) & ~3);
        opl->update((short *)pos, i);
        pos += i * getsampsize(); towrite -= i;
        minicnt -= (long)(player->getrefresh() * i);
    }
}

static int fill_buffer(signed short *dest, int len)
{
    if (playing) {
        play_callback((unsigned char *) dest, len);
        return len;
    }
    return 0;
}

static int set_position(int seconds, int subtune)
{
    if (!playing) return 0;

    if (!seconds)
    {
        player->rewind(subtune);
        int x = 0;
        if (player->gettitle().length())
        {
            fieldname[x] = "Title";
            fielddata[x++] = player->gettitle();
        }
        else
        {
            fieldname[x] = "File";
            fielddata[x++] = filename;
        }

        if (player->getauthor().length())
        {
            fieldname[x] = "Author";
            fielddata[x++] = player->getauthor();
        }
        if (player->getdesc().length())
        {
            fieldname[x] = "Description";
            fielddata[x++] = player->getdesc();
        }
        if (player->gettype().length())
        {
            fieldname[x] = "Format";
            fielddata[x++] = player->gettype();
        }
        plugin.tune   = subtune;
        plugin.length = player->songlength();
        return subtune;
    }
    else
    {
        // It seems to always seek to the start in some songs.. ? Looks fine here
        player->seek((int)((double)timer/plugin.freq*1000) + seconds*1000);
        timer += seconds*plugin.freq;
        return seconds*10;
    }
}

static int can_handle(const char *name)
{
	const char *sext = strrchr(name, '.');
    return formatsdb.Find(sext ? sext+1 : "");
}

#ifndef STATIC
int main(int argc, char* argv[])
{
	return 0;
}
#endif

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN adplug_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
		// Load formats database
        if( !formatsdb.Load("[ADPLUG]", "formats.db") )
            exit(-1);

        memset(&plugin, 0, sizeof(plugin));
        plugin.plugname     = "adplug";
        plugin.init_file    = init_file;
        plugin.set_position = set_position;
        plugin.fill_buffer  = fill_buffer;
        plugin.can_handle   = can_handle;
        plugin.close        = close;
        plugin.shutdown     = shutdown;

        plugin.channels = cfg.channels;
        plugin.freq = cfg.freq;
        plugin.replaygain = 1;
        return &plugin;
}

}

