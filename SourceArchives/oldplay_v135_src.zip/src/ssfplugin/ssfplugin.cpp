/*
    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#ifdef HAVE_PTHREAD_H
#include <pthread.h>
#else
#include <SDL/SDL_thread.h>
#endif

extern "C" {
    #include "yaneurao/ring_buffer.h"
}

#include "Core/sega.h"
#include "Core/dcsound.h"
#include "Core/satsound.h"
#include "Core/yam.h"

#include "psflib/psflib.h"

#include "../plugin.h"
#include "../util.h"

static struct sound_plugin plugin;
static int playing;
static string fieldname[5];
static string fielddata[5];

static ring_buffer_t buffer;
static int first_run = 1;

#ifdef HAVE_PTHREAD_H
static pthread_t sega_thread_id = 0;
static pthread_attr_t pattr;
static sched_param param;
#else
static SDL_Thread *thread;
#endif

//#define DBG(...) printf(...)
#define DBG(a)

typedef unsigned long u_long;

template<class T>
class array_t
{
    T * ptr;
    size_t size;
public:
	array_t() :  ptr( 0 ), size( 0 ) { }
	~array_t() { if ( ptr ) ::free( ptr ); }

	size_t get_size() { return size; }
	void set_size( size_t n ) {
		if ( size == n ) return;

	    size = n;
        ptr = (T *) realloc( ptr, n * sizeof(T) );
    }
	T * get_ptr() { return ptr; }
	void free() {
		if ( ptr ) ::free( ptr ); ptr = 0;
		size = 0;
	}
};

#define BORK_TIME 0xC0CAC01A

static unsigned long parse_time_crap(const char *input)
{
	if (!input) return BORK_TIME;
	int len = strlen(input);
	if (!len) return BORK_TIME;
	int value = 0;
	{
		int i;
		for (i = len - 1; i >= 0; i--)
		{
			if ((input[i] < '0' || input[i] > '9') && input[i] != ':' && input[i] != ',' && input[i] != '.')
			{
				return BORK_TIME;
			}
		}
	}
	char *bar = (char *)input;
	char *strs = bar + len - 1;
	while (strs > bar && (*strs >= '0' && *strs <= '9'))
	{
		strs--;
	}
	if (*strs == '.' || *strs == ',')
	{
		// fraction of a second
		strs++;
		if (strlen(strs) > 3) strs[3] = 0;
		value = atoi(strs);
		switch (strlen(strs))
		{
		case 1:
			value *= 100;
			break;
		case 2:
			value *= 10;
			break;
		}
		strs--;
		*strs = 0;
		strs--;
	}
	while (strs > bar && (*strs >= '0' && *strs <= '9'))
	{
		strs--;
	}
	// seconds
	if (*strs < '0' || *strs > '9') strs++;
	value += atoi(strs) * 1000;
	if (strs > bar)
	{
		strs--;
		*strs = 0;
		strs--;
		while (strs > bar && (*strs >= '0' && *strs <= '9'))
		{
			strs--;
		}
		if (*strs < '0' || *strs > '9') strs++;
		value += atoi(strs) * 60000;
		if (strs > bar)
		{
			strs--;
			*strs = 0;
			strs--;
			while (strs > bar && (*strs >= '0' && *strs <= '9'))
			{
				strs--;
			}
			value += atoi(strs) * 3600000;
		}
	}
	return value;
}

struct psf_info_meta_state
{
    unsigned int volume;
    unsigned int replaygain;

    char title[256];
    char artist[256];
    char game[256];
    char year[256];
    char genre[256];
    char psfby[256];
    char comment[256];
    char copyright[256];

	int tag_song_ms;
	int tag_fade_ms;

	psf_info_meta_state()
		: tag_song_ms( 0 ), tag_fade_ms( 0 )
	{
	    replaygain = 0;
	    volume = 0;

	    title[0] = '\0';
        artist[0] = '\0';
        game[0] = '\0';
        year[0] = '\0';
        genre[0] = '\0';
        psfby[0] = '\0';
        comment[0] = '\0';
        copyright[0] = '\0';
	}
};

static int psf_info_meta(void * context, const char * name, const char * value)
{
	psf_info_meta_state * state = ( psf_info_meta_state * ) context;

    const char *tag = name;

    if (!strncmp(tag, "title", 5))
	{
		strcpy(state->title, value);
	}
    else if (!strncmp(tag, "artist", 6))
	{
		strcpy(state->artist, value);
	}
	else if (!strncmp(tag, "game", 4))
	{
		strcpy(state->game, value);
	}
	else if (!strncmp(tag, "year", 4))
	{
		strcpy(state->year, value);
	}
	else if (!strncmp(tag, "length", 6))
	{
		DBG("reading length");
		int temp = parse_time_crap(value);
		if (temp != BORK_TIME)
		{
			state->tag_song_ms = temp;
		}
	}
	else if (!strncmp(tag, "fade", 4))
	{
		DBG("reading fade");
		int temp = parse_time_crap(value);
		if (temp != BORK_TIME)
		{
			state->tag_fade_ms = temp;
        }
	}
	else if (!strncmp(tag, "utf8", 4))
	{
		DBG("found utf8");
	}
	else if (!strncmp(tag, "_lib", 4))
	{
		DBG("found _lib");
	}
	else if (!strncmp(tag, "_refresh", 8))
	{
		DBG("found _refresh");
	}
	else if (tag[0] == '_')
	{
		DBG("found unknown required tag, failing");
		return -1;
	}

	return 0;
}

struct sdsf_load_state
{
    array_t<uint8_t> state;
};

int sdsf_load(void * context, const uint8_t * exe, size_t exe_size,
                                  const uint8_t * reserved, size_t reserved_size)
{
    if ( exe_size < 4 ) return -1;

    struct sdsf_load_state * state = ( struct sdsf_load_state * ) context;

    array_t<uint8_t> &dst = state->state;

    if ( dst.get_size() < 4 )
    {
        dst.set_size( exe_size );
		memcpy( dst.get_ptr(), exe, exe_size );
		return 0;
    }

    uint32_t dst_start = *(uint32_t*)(dst.get_ptr());
	uint32_t src_start = *(uint32_t*)(exe);
    dst_start &= 0x7FFFFF;
    src_start &= 0x7FFFFF;
	DWORD dst_len = dst.get_size() - 4;
	DWORD src_len = exe_size - 4;
	if ( dst_len > 0x800000 ) dst_len = 0x800000;
	if ( src_len > 0x800000 ) src_len = 0x800000;

	if ( src_start < dst_start )
	{
		DWORD diff = dst_start - src_start;
		dst.set_size( dst_len + 4 + diff );
		memmove( dst.get_ptr() + 4 + diff, dst.get_ptr() + 4, dst_len );
		memset( dst.get_ptr() + 4, 0, diff );
		dst_len += diff;
		dst_start = src_start;
		*(uint32_t*)(dst.get_ptr()) = dst_start;
	}
	if ( ( src_start + src_len ) > ( dst_start + dst_len ) )
	{
		DWORD diff = ( src_start + src_len ) - ( dst_start + dst_len );
		dst.set_size( dst_len + 4 + diff );
		memset( dst.get_ptr() + 4 + dst_len, 0, diff );
		dst_len += diff;
	}

	memcpy( dst.get_ptr() + 4 + ( src_start - dst_start ), exe + 4, src_len );

    return 0;
}

struct psf_file_state
{
	FILE *f;
};

static void * psf_file_fopen( const char * uri )
{
    psf_file_state * state = new psf_file_state;
	state->f = fopen( uri, "rb" );
	if ( state->f != NULL)
        return state;

	fprintf(stderr, "psf_file_open: failed to load ´%s'.\n", uri);
	return NULL;
}

static size_t psf_file_fread( void * buffer, size_t size, size_t count, void * handle )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    size_t bytes_read = fread( buffer, size, count, state->f );
    return bytes_read / size;
}

static int psf_file_fseek( void * handle, int64_t offset, int whence )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    return fseek( state->f, offset, whence );
}

static int psf_file_fclose( void * handle )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    fclose( state->f );
    delete state;
    return 0;
}

static long psf_file_ftell( void * handle )
{
    psf_file_state * state = ( psf_file_state * ) handle;
    return ftell( state->f );
}

const psf_file_callbacks psf_file_system =
{
	"\\/|:",
	psf_file_fopen,
	psf_file_fread,
	psf_file_fseek,
	psf_file_fclose,
	psf_file_ftell
};

array_t<uint8_t> sega_state;
array_t<int16_t> sample_buffer;
psf_info_meta_state m_info;

int xsf_version;

int cfg_dry = 1;
int cfg_dsp = 1;
int cfg_dsp_dynarec = 1;

/* saturn (dreamcast) emulation thread */
#ifdef HAVE_PTHREAD_H
static void *sega_thread(void *data)
{
	sample_buffer.set_size( 1024 * 8 );
    uint32_t samples_to_render = 1024 * 4;
    while ( buffer.sexy_thread_exit_flag != 1 ) {
        int err = sega_execute( sega_state.get_ptr(), 0x7FFFFFFF, sample_buffer.get_ptr(), & samples_to_render );
		if ( err < 0 ) fprintf( stderr, "sega_thread: execution halted with an error.\n" );
		if ( !samples_to_render ) {
            fprintf(stderr, "sega_thread: io error\n");
            break;
		}

		ring_write(&buffer, (unsigned char *)sample_buffer.get_ptr(), samples_to_render * 4 );
    }

    ring_stop(&buffer);
    pthread_exit ( 0 );
}
#else
int sega_thread(void *unused)
{
	sample_buffer.set_size( 1024 * 4 );
    uint32_t samples_to_render = 1024 * 2;
    while ( buffer.sexy_thread_exit_flag != 1 ) {
        int err = sega_execute( sega_state.get_ptr(), 0x7FFFFFFF, sample_buffer.get_ptr(), & samples_to_render );
		if ( err < 0 ) fprintf( stderr, "sega_thread: execution halted with an error.\n" );
		if ( !samples_to_render ) {
            fprintf(stderr, "sega_thread: io error\n");
            break;
		}

		ring_write(&buffer, (unsigned char *)sample_buffer.get_ptr(), samples_to_render * 4 );
    }

    ring_stop(&buffer);
    return 0;
}
#endif

static int init_file(char *fname)
{
    playing = 0;
    xsf_version = psf_load(fname, &psf_file_system, 0, 0, 0, 0, 0);

	if ( xsf_version <= 0 ) {
        fprintf( stderr, "init_file: not a PSF file\n" );
        return -1;
    }

    if ( xsf_version == 0x11 ) ; // ssf
	else if ( xsf_version == 0x12 ) ; // dsf
	else {
	    fprintf( stderr, "init_file: not a SSF or DSF file\n" );
        return -1;
    }

    if ( psf_load(fname, &psf_file_system, xsf_version, 0, 0, psf_info_meta, &m_info) <= 0 ) {
        fprintf( stderr, "init_file: failed to load tags\n" );
        return -1;
    }

    if ( first_run )
	{
		sega_init();
        ring_init(&buffer, BLOCK_SIZE / 4, BLOCK_COUNT * 4);
		first_run = 0;
	}
	else ring_reset(&buffer);

	sega_state.set_size(sega_get_state_size(xsf_version - 0x10));

	void * pEmu = sega_state.get_ptr();

	sega_clear_state(pEmu, xsf_version - 0x10);

	sega_enable_dry(pEmu, cfg_dry ? 1 : !cfg_dsp);
	sega_enable_dsp(pEmu, cfg_dsp);

#ifdef _WIN32
	int dynarec = cfg_dsp_dynarec;
	sega_enable_dsp_dynarec( pEmu, dynarec );

	if ( dynarec )
	{
		void * yam = 0;
		if ( xsf_version == 0x12 )
		{
			void * dcsound = sega_get_dcsound_state( pEmu );
			yam = dcsound_get_yam_state( dcsound );
		}
		else
		{
			void * satsound = sega_get_satsound_state( pEmu );
			yam = satsound_get_yam_state( satsound );
		}
		if ( yam ) yam_prepare_dynacode( yam );
	}
#endif

	struct sdsf_load_state state;

	if ( psf_load( fname, &psf_file_system, xsf_version, sdsf_load, &state, 0, 0 ) < 0 ) {
		fprintf( stderr, "init_file: invalid SSF/DSF file" );
		return -1;
	}

	uint32_t start = *(uint32_t*)(state.state.get_ptr());
	DWORD length = state.state.get_size();
	DWORD max_length = (xsf_version == 0x12) ? 0x800000 : 0x80000;
	if ((start + (length-4)) > max_length)
	{
		length = max_length - start + 4;
	}
	sega_upload_program(pEmu, state.state.get_ptr(), length);

    int x = 0;
    if (m_info.title[0])
    {
        fieldname[x] = "Title";
        fielddata[x++] = m_info.title;
    }
    if (m_info.game[0])
    {
        fieldname[x] = "Game";
        fielddata[x++] = m_info.game;
    }
    if (m_info.artist[0])
    {
        fieldname[x] = "Artist";
        fielddata[x++] = m_info.artist;
    }
    if (m_info.copyright[0])
    {
        fieldname[x] = "Copyright";
        fielddata[x++] = m_info.copyright;
    }

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields = x;

    plugin.length = m_info.tag_song_ms > 0 ? m_info.tag_song_ms : 3 * 60 * 1000;

	/* create emulation thread */
#ifdef HAVE_PTHREAD_H
	pthread_attr_init(&pattr);
	pthread_attr_getschedparam (&pattr, &param);

	/* set the priority; others are unchanged */
	param.sched_priority = -10;/* -20 high to 19 low. 0 == default */

   	/* setting the new scheduling param */
	pthread_attr_setschedparam (&pattr, &param);
    pthread_create( &sega_thread_id, &pattr, sega_thread, NULL);
#else
    thread = SDL_CreateThread(sega_thread, NULL);
    if ( thread == NULL ) {
        fprintf(stderr, "init_file: unable to create thread: %s\n", SDL_GetError());
        return -1;
    }
#endif

    playing = 1;
    return 0;
}

static int close()
{
    if (playing) {
#ifdef HAVE_PTHREAD_H
        if( sega_thread_id ) {
            ring_stop(&buffer);
            pthread_join(sega_thread_id, NULL);
            sega_thread_id = 0;
        }
#else
        if( thread ) {
            ring_stop(&buffer);
            SDL_WaitThread(thread, NULL);
            thread = NULL;
        }
#endif
		if ( sega_state.get_size() )
		{
			void * yam = 0;
			if ( xsf_version == 0x12 )
			{
				void * dcsound = sega_get_dcsound_state(sega_state.get_ptr());
				yam = dcsound_get_yam_state(dcsound);
			}
			else
			{
				void * satsound = sega_get_satsound_state( sega_state.get_ptr());
				yam = satsound_get_yam_state(satsound);
			}
			if ( yam ) yam_unprepare_dynacode(yam);
			sega_state.free();
		}

		sample_buffer.free();
		memset(&m_info, 0, sizeof(psf_info_meta_state));
    }

    for(int i = 0; i < 5; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }

    playing = plugin.length = plugin.nfields = 0;
    return 0;
}

static void shutdown()
{
    ring_close(&buffer);
    first_run = 1;
}

static int fill_buffer(signed short *dest, int len)
{
    if(playing) {
        return ring_read(&buffer, (unsigned char *)dest, len);
    }

    return 0;
}

static int can_handle(const char *name)
{
    return (is_ext(name, ".ssf") || is_ext(name, ".minissf") ||
			is_ext(name, ".dsf") || is_ext(name, ".minidsf"));
}

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN ssf_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
	    memset(&plugin, 0, sizeof(plugin));
        plugin.plugname         = "highly_theorethical";
        plugin.init_file        = init_file;
        plugin.fill_buffer      = fill_buffer;
        plugin.can_handle       = can_handle;
        plugin.close            = close;
        plugin.shutdown         = shutdown;

        plugin.channels   = 2;
        plugin.freq       = 44100;
        plugin.replaygain = 1;
        plugin.tune       = 0;
        plugin.subtunes   = 1;
        plugin.clockfreq  = 275;
        return &plugin;
    }

}
