/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

extern "C" {
    #include "libwsr/types.h"
    #include "libwsr/wsr_player.h"
}

#include "../plugin.h"
#include "../util.h"

static struct sound_plugin plugin;

#define AUDIO_BUFFER_SIZE 4608 / 2
int16 sample_buffer[AUDIO_BUFFER_SIZE / 2];
static int get_subsongs(const char *filename);

int readposbytes = 0;
size_t writeposbytes = 0;

static int playing;
static string fieldname[1];
static string fielddata[1];
static string filename;

static int init_file(char *fname)
{
    playing = 0;
    plugin.tune = 0;
    plugin.subtunes = 255;
    plugin.length = 60 * 3 * 1000;

    if ( !Load_WSR((char *)fname) ) {
        fprintf(stderr, "init_file: cannot load '%s'\n", fname);
        return -1;
    }

	writeposbytes = readposbytes = 0;

	fieldname[0] = "Song";
    fielddata[0] = base_name(fname);

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields  = 1;

    playing = 1;
    return 0;
}

static int close()
{
	if ( playing )
		Close_WSR();

    for(int i = 0; i < plugin.nfields; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }

    playing = plugin.tune = plugin.subtunes = plugin.length = plugin.nfields = 0;
    return 0;
}

static int fill_buffer(signed short *dest, int len)
{
    if (playing)
    {
        int writtenbytes = 0;
		for (;;)
		{
			int bytesleft = len - writtenbytes;
			int bufbytes  = writeposbytes - readposbytes;
			if (bytesleft <= bufbytes)
			{
				memcpy((char*)dest + writtenbytes, (char*)sample_buffer + readposbytes, bytesleft);
				readposbytes += bytesleft;
				writtenbytes = len;
				break;
			}
			else
			{
				memcpy((char*)dest + writtenbytes, (char*)sample_buffer + readposbytes, bufbytes);
				writtenbytes += bufbytes;
				readposbytes = writeposbytes = 0;

				Update_WSR(40157, AUDIO_BUFFER_SIZE / 4);
				writeposbytes = AUDIO_BUFFER_SIZE;
			}
		}

        return writtenbytes;
    }

    return 0;
}

static int can_handle(const char *name)
{
    return is_ext(name, ".wsr");
}

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN wsr_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
        memset(&plugin, 0, sizeof(plugin));
        plugin.plugname         = "wonder_swan";
        plugin.init_file        = init_file;
        plugin.fill_buffer      = fill_buffer;
        plugin.can_handle       = can_handle;
        plugin.close            = close;

        plugin.channels   = 2;
        plugin.freq       = 44100;
        plugin.replaygain = 1;
        plugin.clockfreq  = 150;

        return &plugin;
    }

}

