/* More license crap here */
#include <vector>
#include <string>

using namespace std;

class M3uPlayList
{
    public:
        M3uPlayList(const char* p);
        ~M3uPlayList();
        void        Next();
        int         Size()     { return paths.size(); }
        const char* GetPath()  { return paths.front().c_str(); }
        const char* GetName()  { return names.front().c_str(); }
        int         GetIndex() { return index.front(); }
        int         GetTime()  { return times.front(); }
        int         GetTrack() { return tracks.front(); }

    private:
        std::vector<std::string> paths;
        std::vector<std::string> names;
        std::vector<int>         index; // Only used in opl
        std::vector<int>         times;
        std::vector<int>         tracks; // Only used in opl
};

