/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <SDL/SDL.h>
#include <vector>
#include <sys/stat.h>

#ifdef USE_DEV_MIXER
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/soundcard.h>
#endif

#include "MusicPlayer.h"
#include "FileList.h"
#include "Fifo.h"
#include "util.h"

#ifdef _WIN32
#include <io.h>
#include <windows.h>
#define strcasecmp stricmp
#define strncasecmp strnicmp
#define RTLD_LAZY 0
int cprintf(char *fmt, ...);
void *dlopen(const char *filename, int flag)
{ return (void *)LoadLibraryA(filename); }
void *dlsym(void *handle, const char *symbol)
{ HINSTANCE h = (HINSTANCE)handle; return (void *)GetProcAddress(h, symbol); }
const char *dlerror() { return "bad handle"; }
#else
#include <dlfcn.h>
#endif

extern "C" { void busy(int); }
void hw_set_cpu(int speed);

extern int current_clockfreq;
extern char oldplay_home[128];

void MusicPlayer::release_plugin()
{
	if (current_plugin && current_plugin->close)
		current_plugin->close();

	current_plugin = NULL;
}

#ifdef USE_AUDIO_FIFO
void MusicPlayer::fill_audio(BlockFifo *af, int maxbytes)
{
	if(current_plugin && current_plugin->fill_buffer)
	{
		int blockofbytes = af->LeftToWrite();
		if(blockofbytes)
		{
			if(maxbytes && blockofbytes > maxbytes) blockofbytes = maxbytes;
			int rc = current_plugin->fill_buffer(audiobuf, BLOCK_SIZE * blockofbytes);

            if(!rc)
			{
			    fprintf(stderr, "fill_audio: plugin stopped, closing song\n");
				song_playing = false;
				release_plugin();
				return;
			}
			else
            {
#ifdef ENABLE_BLEND_FILTER
                int b = blend_factor;
                if (b)
                    for (int i = 0; i < rc/2; i+=2)
                    {
                        short chn1 = (short)((((int)audiobuf[i])*(256-b) + ((int)audiobuf[i+1])*b)/256);
                        short chn2 = (short)((((int)audiobuf[i+1])*(256-b) + ((int)audiobuf[i])*b)/256);
                        audiobuf[i] = chn1;
                        audiobuf[i+1] = chn2;
                    }
#endif

                if (current_vol <= SOFTVOL)
                {
                    int volS = current_vol ? current_vol : 1;
                    for (int i = 0; i < rc/2; i++)
                        audiobuf[i] = (audiobuf[i]*volS)/(SOFTVOL+1);
                }

				af->Write(audiobuf, rc  / BLOCK_SIZE);
            }
		}
	}
}
#endif

int MusicPlayer::GetNextSamples(short *dest, int len)
{
#ifdef USE_AUDIO_FIFO
	int blocks = (len+BLOCK_SIZE-1)/BLOCK_SIZE;

	if(blocks > audioFifo->LeftToRead())
		blocks = audioFifo->LeftToRead();

	if(current_plugin && current_plugin->freq < 30000)
		audioFifo->Read(dest, blocks, 1);
	else
		audioFifo->Read(dest, blocks+1, 2);
	return blocks * BLOCK_SIZE;
#else
    if(len > (BLOCK_SIZE * BLOCK_COUNT))
        len = BLOCK_SIZE * BLOCK_COUNT;
    memcpy(dest, audiobuf, len);
    return len;
#endif
}

void MusicPlayer::audio_cb(void *userdata, Uint8 *stream, int len)
{
	MusicPlayer *mp = (MusicPlayer *)userdata;
    sound_plugin *plugin = mp->current_plugin;
#ifdef USE_AUDIO_FIFO
    BlockFifo *fifo = mp->audioFifo;
#endif

    if((mp->song_playing == false) || mp->audio_paused)
    {
        /* memset(stream, 0, len); */
        return;
    }

#ifdef USE_AUDIO_FIFO
	if(fifo->LeftToRead())
	{
#ifdef USE_DEV_MIXER
		fifo->Read(stream, 1);
#else
		fifo->Read16(stream, 1, mp->current_vol * 0x10000 / 10);
#endif
		mp->total_samples += len>>1;
        /* if (plugin->length > 0)
            mp->songend_samples = plugin->length * plugin->channels
                                    / 1000 * plugin->freq; */
		if(mp->songend_samples < 0 || (mp->total_samples > mp->songend_samples))
		{
            if(plugin->subtunes > (1+plugin->tune))
            {
                fprintf(stderr, "audio_cb: going to next subtune %d to %d!\n", \
                                plugin->tune,plugin->tune+1);
                mp->SetTune(plugin->tune+1);
            }
            else
            {
                fprintf(stderr, "audio_cb: reached song end, closing song\n");
				mp->song_playing = false;
				mp->release_plugin();
				return;
            }
		}
	}
	else
		memset(stream, 0, len);

	if(mp->audio_locked)
		return;

	mp->fill_audio(fifo, 2);
#else
    int rc = plugin->fill_buffer((short *) stream, len);
    if(rc <= 0)
	{
	    fprintf(stderr, "audio_cb: plugin stopped, closing song\n");
		mp->song_playing = false;
		mp->release_plugin();
		return;
	}

	mp->total_samples += rc>>1;
    /* if (plugin->length > 0)
        mp->songend_samples = plugin->length * plugin->channels
                                / 1000 * plugin->freq; */
	if(mp->songend_samples < 0 || (mp->total_samples > mp->songend_samples))
	{
        if(plugin->subtunes > (1+plugin->tune))
        {
            fprintf(stderr, "audio_cb: going to next subtune %d to %d!\n", \
                plugin->tune,plugin->tune+1);
			mp->SetTune(plugin->tune+1);
		}
		else
		{
			fprintf(stderr, "audio_cb: reached song end, closing song\n");
			mp->song_playing = false;
			mp->release_plugin();
			return;
		}
	}

    {
    #ifdef ENABLE_BLEND_FILTER
        int b = blend_factor;
        if(b) {
            short *tmp = (short *) stream;
            for (int i = 0; i < rc/2; i+=2)
            {
                short chn1 = (short)((((int)tmp[i])*(256-b) + ((int)tmp[i+1])*b)/256);
                short chn2 = (short)((((int)tmp[i+1])*(256-b) + ((int)tmp[i])*b)/256);
                tmp[i] = chn1;
                tmp[i+1] = chn2;
            }
        }
    #endif
        if(mp->current_vol <= SOFTVOL)
        {
            short *tmp = (short *) stream;
            int volS = mp->current_vol ? mp->current_vol : 1;
            for (int i = 0; i < rc/2; i++)
                tmp[i] = (tmp[i]*volS)/(SOFTVOL+1);
        }

        memcpy(mp->audiobuf, stream, rc);
#endif
    }
}

int MusicPlayer::init_sound(int freq, int chn)
{
	SDL_AudioSpec desired, obtained;
	memset(&desired, 0, sizeof(desired));
	desired.format   = SDL_BYTEORDER == SDL_BIG_ENDIAN ? AUDIO_S16MSB : AUDIO_S16LSB;
	desired.freq     = freq;
	desired.channels = chn;
	desired.samples  = BLOCK_SIZE/(2*chn);
	desired.callback = audio_cb;
	desired.userdata = this;

	fprintf(stderr, "MusicPlayer::InitSound: open Audio\n");
	if(audio_opened)
    {
        fprintf(stderr, "MusicPlayer::InitSound: closing old first\n");
		SDL_CloseAudio();
        fprintf(stderr, "MusicPlayer::InitSound: audio closed\n");
    }

	int tries = 5;
	while(SDL_OpenAudio(&desired, &obtained) < 0)
	{
      	fprintf(stderr, "MusicPlayer::InitSound: couldn't open SDL audio: %s\n", \
                        SDL_GetError());
		SDL_Delay(500);

		if(tries == 0)
			exit(-1);
		tries--;
	}

    fprintf(stderr, "MusicPlayer::InitSound: audio Opened\n");
    audio_opened = true;

	current_channels = obtained.channels;
    current_freq     = obtained.freq;

#ifdef USE_DEV_MIXER
	if(mixer_fd < 0)
		mixer_fd = open("/dev/mixer", O_RDWR);
    int tmpvol = 1;//5*0x50/10;
	int mvol=(tmpvol<<8)|tmpvol;
	ioctl(mixer_fd, SOUND_MIXER_WRITE_VOLUME, &mvol);
    SetVolume(current_vol);
#endif
	return (current_channels == chn && current_freq == freq);
}

#ifdef STATIC
extern "C" {
// Lossy
sound_plugin *mpg123_init_sound_plugin();
sound_plugin *vorbis_init_sound_plugin();
/* sound_plugin *mpc_init_sound_plugin(); */
sound_plugin *faad_init_sound_plugin();

// Lossless
sound_plugin *flac_init_sound_plugin();
sound_plugin *opus_init_sound_plugin();
/* sound_plugin *tta_init_sound_plugin(); */
/* sound_plugin *mac_init_sound_plugin(); */
/* sound_plugin *wavpack_init_sound_plugin(); */

// Modules
sound_plugin *sidplay_init_sound_plugin();
sound_plugin *sidplayfp_init_sound_plugin();
sound_plugin *modplay_init_sound_plugin();
sound_plugin *adplug_init_sound_plugin();
sound_plugin *timidity_init_sound_plugin();

sound_plugin *stsound_init_sound_plugin();
sound_plugin *hively_init_sound_plugin();
sound_plugin *sc68_init_sound_plugin();
sound_plugin *uade_init_sound_plugin();

// Chiptune
sound_plugin *gme_init_sound_plugin();
sound_plugin *psf_init_sound_plugin();
sound_plugin *gsf_init_sound_plugin();
/* sound_plugin *pokecubed_init_sound_plugin(); */
sound_plugin *vgmstream_init_sound_plugin();
sound_plugin *ds2sf_init_sound_plugin();
sound_plugin *psf2_init_sound_plugin();
sound_plugin *ssf_init_sound_plugin();
sound_plugin *wsr_init_sound_plugin();
/* sound_plugin *dsf_init_sound_plugin(); */
}
#endif

bool MusicPlayer::CanHandle(const char *name)
{
	for(unsigned int i=0; i<sound_plugins.size(); i++)
		if(sound_plugins[i]->can_handle(name))
			return true;
	return false;
}

#ifndef STATIC
void MusicPlayer::load_plugins(char *path)
{
	FileList *flist = new FileList(path);
	fprintf(stdout, "load_plugins: looking for plugins in '%s' "
        "%p %d\n", path, flist, flist ? flist->Size() : -1);
	for(int i=0; i<flist->Size(); i++)
	{
		const char *fn = flist->GetPath(i);
		void *ptr = dlopen(fn, RTLD_LAZY);

		fprintf(stderr, "found plugin '%s', loading ... ", fn);
		if(ptr)
		{
			struct sound_plugin *(*init)() = (struct sound_plugin *(*)())dlsym(ptr,
                                                "init_sound_plugin");
			if(init)
			{
				struct sound_plugin *plugin = init();
				sound_plugins.push_back(plugin);
				fprintf(stderr, "ok\n");
				continue;
			}
		}

		fprintf(stderr, "failed, %s\n", dlerror());
	}
}
#endif

MusicPlayer::MusicPlayer(bool use_cpu_scaling)
{
#ifdef STATIC
	struct sound_plugin *plugin;
    //if((plugin = mpg123_init_sound_plugin()))    sound_plugins.push_back(plugin);
	if((plugin = gme_init_sound_plugin()))       sound_plugins.push_back(plugin);
	#ifdef BUILD_SIDPLAYFP_PLUGIN
		//if((plugin = sidplayfp_init_sound_plugin())) sound_plugins.push_back(plugin);
	#else
		//if((plugin = sidplay_init_sound_plugin()))   sound_plugins.push_back(plugin);
	#endif
    /* Obsolete, replaced by mpg123plugin */
	/* if(plugin = mad_init_sound_plugin())       sound_plugins.push_back(plugin); */
	//if((plugin = vorbis_init_sound_plugin()))  sound_plugins.push_back(plugin);
	//if((plugin = flac_init_sound_plugin()))    sound_plugins.push_back(plugin);
	/* Removed, does anyone uses these codecs? */
	/* if(plugin = wavpack_init_sound_plugin())   sound_plugins.push_back(plugin);
	if(plugin = tta_init_sound_plugin())       sound_plugins.push_back(plugin);
	if(plugin = mac_init_sound_plugin())       sound_plugins.push_back(plugin);
	if(plugin = mpc_init_sound_plugin())       sound_plugins.push_back(plugin); */
	//if((plugin = faad_init_sound_plugin()))      sound_plugins.push_back(plugin);

	/* v1.35 opus plugin */
	//if((plugin = opus_init_sound_plugin()))    	 sound_plugins.push_back(plugin);
	//if((plugin = timidity_init_sound_plugin()))  sound_plugins.push_back(plugin);

	/* v1.35, ds (2sf), psf2, ws, sega saturn and sega dreamcast music plugins ;) */
	//if((plugin = ds2sf_init_sound_plugin()))     sound_plugins.push_back(plugin);
	//if((plugin = psf2_init_sound_plugin()))      sound_plugins.push_back(plugin);
	/* if((plugin = dsf_init_sound_plugin()))       sound_plugins.push_back(plugin); */
	//if((plugin = ssf_init_sound_plugin()))       sound_plugins.push_back(plugin);
	//if((plugin = wsr_init_sound_plugin()))       sound_plugins.push_back(plugin);

	/* v1.34, psx and gba music plugins ;) */
	if((plugin = gsf_init_sound_plugin()))       sound_plugins.push_back(plugin);
	if((plugin = psf_init_sound_plugin()))       sound_plugins.push_back(plugin);

    /* v1.33, ST-Sound, SC68 and HivelyTracker plugins :) */
	//if((plugin = stsound_init_sound_plugin()))   sound_plugins.push_back(plugin);

	#ifdef BUILD_HIVELY_PLUGIN
		/* Will handle ahx files with hiverly player */
		if((plugin = hively_init_sound_plugin())) sound_plugins.push_back(plugin);
    #endif
	if((plugin = sc68_init_sound_plugin()))      sound_plugins.push_back(plugin);

    /* Overlaps with modplug (best first) */
    if((plugin = adplug_init_sound_plugin()))    sound_plugins.push_back(plugin);
	/* Doesn't handle error well (best last) */
	//if((plugin = modplay_init_sound_plugin()))   sound_plugins.push_back(plugin);
    /* Obsolete, replaced by vgmstream */
    /* if((plugin = pokecubed_init_sound_plugin())) sound_plugins.push_back(plugin); */

    //if((plugin = vgmstream_init_sound_plugin())) sound_plugins.push_back(plugin);
	if((plugin = uade_init_sound_plugin()))      sound_plugins.push_back(plugin);
#else
	char tmppath[128];
    sprintf(tmppath, "%s/plugins", oldplay_home);

	// Will load plugins found oldplay home dir first, then default ones.
	load_plugins(tmppath);
	load_plugins("plugins");
#endif

#ifdef USE_AUDIO_FIFO
    audioFifo = new BlockFifo(BLOCK_SIZE, BLOCK_COUNT);
#endif
	memset(audiobuf, 0, BLOCK_SIZE * BLOCK_COUNT * sizeof(short));

    current_plugin = NULL;
    last_plugin = NULL;
	current_vol = 10;
	current_subtune = 0;
	current_freq = 0;
	current_channels = 0;

	total_samples = 0;
    songend_samples = 0;

	song_playing = false;
	audio_paused = false;
    audio_locked = false;
    heavy_song = false;
    blend_factor = 0;
    cpu_scaling = use_cpu_scaling;

    tmp_module = NULL;
    tmp_module_name[0] = '\0';

#ifndef _WIN32
    sprintf(tmppath, "%s/.tmpsongs", oldplay_home);
    mkdir(tmppath, 0x1FF);

    sprintf(tmppath, "%s/plugins", oldplay_home);
    mkdir(tmppath, 0x1FF);
#else
    mkdir(".tmpsongs");
#endif
}

bool MusicPlayer::Play(const char *name, char *data, int size, int time, int track)
{
    for (unsigned int i=0; i<sound_plugins.size(); i++)
	{
		if (sound_plugins[i]->can_handle(name))
		{
            fprintf(stderr, "MusicPlayer::Play: plugin %d, %s\n",i,sound_plugins[i]->plugname);

			int rc = -1;
			song_playing = false;

            // TODO: Is it necessary to pause audio?
			SDL_PauseAudio(1);

			SDL_LockAudio();
			audio_locked = true;

			busy(1);

			release_plugin();
            if(last_plugin && (last_plugin != sound_plugins[i]) && last_plugin->shutdown)
                last_plugin->shutdown();
			current_plugin = last_plugin = sound_plugins[i];

			if(tmp_module)
				free(tmp_module);
			tmp_module = NULL;

			if(strlen(tmp_module_name))
				remove(tmp_module_name);
			*tmp_module_name = 0;

			if(data && current_plugin->init_data)
			{
				tmp_module = (char *)malloc(size);
				memcpy(tmp_module, data, size);
				rc = current_plugin->init_data((char *)name, tmp_module, size);
			}
			else if(!data && current_plugin->init_file)
			{
				rc = current_plugin->init_file((char *)name);
			}
			else if(!data && current_plugin->init_data)
			{
				struct stat ss;
				memset(&ss, 0, sizeof(struct stat));
				if(stat(name, &ss) == 0)
				{
					char *tmp = (char *)malloc(ss.st_size);
					FILE *fp = fopen(name, "rb");
					if(fp)
					{
						fread(tmp, 1, ss.st_size, fp);
						fclose(fp);
						rc = current_plugin->init_data((char *)name, tmp, ss.st_size);
						free(tmp);
					}
				}
			}
			else if(data && current_plugin->init_file)
			{
#ifndef _WIN32
				sprintf(tmp_module_name, "%s/.tmpsongs/tmp_%s", oldplay_home, base_name(name));
#else
				sprintf(tmp_module_name, ".oldplay_song_%s", base_name(name));
#endif
                for (unsigned int i = 14; i < strlen(tmp_module_name); i++) // Due to FAT
                    tmp_module_name[i] = (char)tolower(tmp_module_name[i]);
				FILE *fp = fopen(tmp_module_name, "wb");
				if(fp)
				{
					fwrite(data, 1, size, fp);
					fclose(fp);
					rc = current_plugin->init_file(tmp_module_name);
				}
                else
                    fprintf(stderr, "MusicPlayer::Play: couldn't save data to %s. %p\n",tmp_module_name,fp);
			}

			fprintf(stderr, "MusicPlayer::Play: rc = %d, %d msec, %d chn, %d Hz @ %d MHz\n", \
                    rc, current_plugin->length, current_plugin->channels, current_plugin->freq, \
                    current_plugin->clockfreq);

			if(rc >= 0)
			{
                fprintf(stderr, "MusicPlayer::Play: %d:%d\n", track, current_plugin->subtunes);
                if (track >= 0 && track < current_plugin->subtunes && current_plugin->set_position)
                {
                    fprintf(stderr, "MusicPlayer::Play: enforcing subtune %d\n",track);
                    current_plugin->set_position(0, track);
                    current_subtune = 0;
                    current_plugin->tune = 0;
                    current_plugin->subtunes = 1;
                }
                if (time > 0)
                {
                    fprintf(stderr, "MusicPlayer::Play: enforcing length %d ms\n",time);
                    current_plugin->length = time;
                }
				total_samples = 0;
				if(current_plugin->length > 0)
					songend_samples = (current_plugin->length * current_plugin->channels )
                                        / 1000 * current_plugin->freq;
				else if(current_plugin->length == -1) // -1 == Plugin doesn't want to decide
                {
                    current_plugin->length = default_length*1000;
					songend_samples = default_length * current_plugin->channels *
                                        current_plugin->freq;
                }
				else // 0 (or < -2) == Infinite ... should change this.
					songend_samples = 0x7FFFFFFE; // Approximately infinite
				current_subtune = current_plugin->tune;

#if defined(GP2X) || defined(__OPENDINGUX__)
                if(current_plugin->freq != current_freq || \
                   current_plugin->channels != current_channels || \
                   current_plugin->clockfreq != current_clockfreq)
                {
                    fprintf(stderr, "MusicPlayer::Play: changing, unlocking audio\n");
                    SDL_UnlockAudio();

                    if(current_plugin->clockfreq && cpu_scaling
                        && (current_plugin->clockfreq != current_clockfreq))
                    {
                        current_clockfreq = current_plugin->clockfreq;
                        fprintf(stderr, "MusicPlayer::Play: clockfreq to %d\n",current_clockfreq);
                        hw_set_cpu(current_clockfreq);
                    }
                    if (current_plugin->freq != current_freq || current_plugin->channels != current_channels)
                    {
                        int wanted = init_sound(current_plugin->freq, current_plugin->channels);
                        fprintf(stderr, "MusicPlayer::Play: plugin wanted %d Hz %d chn, gets %d Hz %d chn\n", \
                                current_plugin->freq, current_plugin->channels, current_freq, current_channels);
                        if (!wanted)
                        {
                            current_plugin->freq     = current_freq;
                            current_plugin->channels = current_channels;
                        }
                    }
                    SDL_LockAudio();
                }
#else
				if(current_plugin->freq != current_freq || current_plugin->channels != current_channels)
				{
                    SDL_UnlockAudio();
					int wanted = init_sound(current_plugin->freq, current_plugin->channels);
                    fprintf(stderr, "MusicPlayer::Play: plugin wanted %d Hz %d chn, gets %d Hz %d chn\n", \
                            current_plugin->freq, current_plugin->channels, current_freq, current_channels);
                    if (!wanted)
                    {
                        current_plugin->freq     = current_freq;
                        current_plugin->channels = current_channels;
                    }
                    SDL_LockAudio();
				}
#endif
                SetVolume(current_vol);
                memset(audiobuf, 0, BLOCK_SIZE * BLOCK_COUNT * sizeof(short));
#ifdef USE_AUDIO_FIFO
				audioFifo->Reset();
				fill_audio(audioFifo, 0);
#endif
				if(!current_plugin)
					rc = -1;
				else
				{
#ifdef A320
					heavy_song = current_clockfreq > 384;
#else
					heavy_song = current_clockfreq > 200;// ? 0 : (strcmp(current_plugin->plugname, "uade") == 0);
#endif
					song_playing = true;
				}
			}
            else
                songend_samples = -1;

            if (rc >= 0)
            	fprintf(stderr, "MusicPlayer::Play: ready to play, unlocking audio\n");
            else
                fprintf(stderr, "MusicPlayer::Play: unlocking audio\n");
            SDL_UnlockAudio();
            audio_locked = false;

            SDL_PauseAudio(0);

            busy(0);
			if (rc >= 0)
                return true;
		}
	}
	return false;
}

int lastvol = -1;
void MusicPlayer::SetVolume(int v)
{
	if(v < 0)
		v = 0;
	else if(v > VOLSTEPS)
		v = VOLSTEPS;
	current_vol = v;
#ifdef USE_DEV_MIXER
    int volH;
    if (vol == 0) volH = 0;
    else if (vol <= SOFTVOL) volH = 1;
    else volH = vol - SOFTVOL;
    int tmpvol = vol == 0 ? 0 : 1+(MAXVOL-1)*(volH-1)/(VOLSTEPS-1-SOFTVOL);
    if (tmpvol > MAXVOL) tmpvol = MAXVOL; // Shouldn't happen, but just in case.
    //if (lastvol == tmpvol) return;
    lastvol = tmpvol;

    int mvol=(tmpvol<<8)|tmpvol;
    printf("MusicPlayer::SetVolume() - Hardware volume %d => %d\n",vol,tmpvol);
    // TODO - why was micket calling SOUND_MIXER_WRITE_PCM?
    //ioctl(mixer_fd, SOUND_MIXER_WRITE_PCM, &mvol);
    ioctl(mixer_fd, SOUND_MIXER_WRITE_VOLUME, &mvol);
#endif
}

void MusicPlayer::SetTune(int n)
{
	if(!current_plugin || !current_plugin->set_position)
		return;

    if (current_plugin->subtunes <= 1)
    {
        // Seek n*msecs [ms] (n = +1,-1)
        SDL_LockAudio();
        int x = current_plugin->length/(1000*60);
        double msecs = 363.4*x+8181.82; // 5 min -> 10 s, 1 h -> 30 s,
        if (msecs < 10000)
            msecs = 10000;
        int actual_msecs = current_plugin->set_position((int)(n*msecs), 0);
        SDL_UnlockAudio();
        int samp = total_samples + (int)((double)actual_msecs / 1000 *
                    current_plugin->freq * current_plugin->channels);
        total_samples = samp > 0 ? samp : 0;
    }
    else
    {
        fprintf(stderr, "MusicPlayer::SetTune: changing subtune %d\n",n);
        if(n < 0)
            n = 0;
        if(n >= current_plugin->subtunes)
            n = current_plugin->subtunes-1;

        if(current_subtune != n)
        {
            total_samples = 0;
            current_subtune = n;
            SDL_LockAudio();
            audio_locked = true;
            current_plugin->set_position(0, n);
            if(current_plugin->length > 0)
                songend_samples = (int)((double)current_plugin->length *
                    current_plugin->channels / 1000 * current_plugin->freq);
            else if(current_plugin->length == -1)
            {
                songend_samples = default_length *
                    current_plugin->channels * current_plugin->freq;
                current_plugin->length = default_length*1000;
            }
            else
                songend_samples = 0x7FFFFFFE;

#ifdef USE_AUDIO_FIFO
            audioFifo->Reset();
            fill_audio(audioFifo, 0);
#endif
            SDL_UnlockAudio();
            audio_locked = false;
        }
    }
}
