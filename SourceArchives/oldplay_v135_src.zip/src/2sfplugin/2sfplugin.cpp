/*
    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#ifdef HAVE_PTHREAD_H
#include <pthread.h>
#else
#include <SDL/SDL_thread.h>
#endif

extern "C" {
    #include "yaneurao/ring_buffer.h"
}

#include "xsfc/drvimpl.h"
#include "xsfc/tagget.h"

#include "../plugin.h"
#include "../util.h"

static struct sound_plugin plugin;
static int playing;
static string fieldname[5];
static string fielddata[5];

static ring_buffer_t buffer;
static int first_run = 1;

#ifdef HAVE_PTHREAD_H
static pthread_t desmume_thread_id = 0;
static pthread_attr_t pattr;
static sched_param param;
#else
static SDL_Thread *thread;
#endif

unsigned long dwChannelMute = 0L;
long dwInterpolation = 0;

static char lib_path[MAX_PATH];
size_t read_bytes(int fd, void *pbuffer, unsigned bytes)
{
    size_t n, bytes_read = 0;
    char *buf = (char *)pbuffer;
    while( (n = read(fd, buf, bytes)) > 0 ) {
        bytes_read += n;
        bytes -= n;
        buf += n;
    }

    return bytes_read;
}

int xsf_get_lib(char *pfilename, void **ppbuffer, unsigned *plength)
{
#ifdef DEBUG
    fprintf(stderr, "xsf_get_lib: external library: '%s'\n", pfilename);
#endif

    char path[MAX_PATH];
    snprintf(path, MAX_PATH, "%s%c%s", lib_path, SEPARATOR, pfilename);
    int fd = open( path, O_RDONLY );
	if( fd < 0 ) {
        fprintf(stderr, "xsf_get_lib: cannot load '%s' file\n", path);
        return XSF_FALSE;
    }

    *plength = lseek(fd, 0, SEEK_END);
    *ppbuffer = (char *)malloc(*plength);
    if( *ppbuffer == NULL ) {
        fprintf(stderr, "xsf_get_lib: cannot allocate %d bytes\n", *plength);
        close(fd);
        return XSF_FALSE;
    }

    lseek(fd, 0, SEEK_SET);
    *plength = read_bytes(fd, *ppbuffer, *plength);
    close(fd);

#ifdef DEBUG
    fprintf(stderr, "xsf_get_lib: read %d bytes from '%s'\n", *plength, path);
#endif

    return XSF_TRUE;
}

/* desmume emulation thread */
#ifdef HAVE_PTHREAD_H
static void *desmume_thread(void *data)
{
	short sample_buffer[1024 * 2];
    int samples_to_render = 1024;
	while ( buffer.sexy_thread_exit_flag != 1 ) {
		int samples_rendered = xsf_gen(sample_buffer, samples_to_render);
        if ( samples_rendered <= 0 ) {
            fprintf(stderr, "desmume_thread: no more sampes to render, finished\n");
            break;
        }

		ring_write(&buffer, (unsigned char *)sample_buffer, samples_rendered);
	}

    ring_stop(&buffer);
    pthread_exit ( 0 );
}
#else
int desmume_thread(void *unused)
{
	short sample_buffer[1024 * 2];
    int samples_to_render = 1024;
	while ( buffer.sexy_thread_exit_flag != 1 ) {
		int samples_rendered = xsf_gen(sample_buffer, samples_to_render);
        if ( samples_rendered <= 0 ) {
            fprintf(stderr, "desmume_thread: no more sampes to render, finished\n");
            break;
        }

		ring_write(&buffer, (unsigned char *)sample_buffer, samples_rendered);
	}

    ring_stop(&buffer);
    return 0;
}
#endif

static int init_file(char *fname)
{
    playing = 0;
    int fd = open(fname, O_RDONLY);
	if( fd < 0 ) {
        fprintf(stderr, "init_file: cannot load '%s' file\n", fname);
        return -1;
    }

    size_t bytes = lseek(fd, 0, SEEK_END);
    char *pfile = (char *) malloc(bytes);
    if ( pfile == NULL ) {
		close(fd);
        fprintf(stderr, "init_file: cannot allocate %d bytes\n", bytes);
        return -1;
    }

    lseek(fd, 0, SEEK_SET);
    bytes = read_bytes(fd, pfile, bytes);
    close(fd);

#ifdef DEBUG
    fprintf(stderr, "read %d bytes from %s\n", bytes, fname);
#endif

    strncpy(lib_path, fname, MAX_PATH);
    char *tmp = strrchr(lib_path, SEPARATOR);
    if( tmp ) {
        *tmp = '\0';
    }

	if( xsf_start(pfile, bytes) != XSF_TRUE ) {
        fprintf(stderr, "init_file: xsf_start failed\n");
        close(fd); free(pfile);
        return -1;
    }

    free(pfile);

    int x = 0;
    tmp = xsf_tagget("title", pfile, bytes);
    if (tmp)
    {
        fieldname[x] = "Title";
        fielddata[x++] = tmp;
    }
    tmp = xsf_tagget("game", pfile, bytes);
    if (tmp)
    {
        fieldname[x] = "Game";
        fielddata[x++] = tmp;
    }
    tmp = xsf_tagget("artist", pfile, bytes);
    if (tmp)
    {
        fieldname[x] = "Artist";
        fielddata[x++] = tmp;
    }
    tmp = xsf_tagget("copyright", pfile, bytes);
    if (tmp)
    {
        fieldname[x] = "Copyright";
        fielddata[x++] = tmp;
    }

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    plugin.nfields = x;

    tmp = xsf_tagget("length", pfile, bytes);
    plugin.length = tmp ? tag2ms(tmp) : 300 * 1000;;

    if (first_run) {
        ring_init(&buffer, BLOCK_SIZE / 4, BLOCK_COUNT * 2);
        first_run = 0;
    } else ring_reset(&buffer);

	/* create emulation thread */
#ifdef HAVE_PTHREAD_H
	pthread_attr_init(&pattr);
	pthread_attr_getschedparam (&pattr, &param);

	/* set the priority; others are unchanged */
	param.sched_priority = 0;/* -20 high to 19 low. 0 == default */

   	/* setting the new scheduling param */
	pthread_attr_setschedparam (&pattr, &param);
    pthread_create( &desmume_thread_id, &pattr, desmume_thread, NULL);
#else
    thread = SDL_CreateThread(desmume_thread, NULL);
    if ( thread == NULL ) {
        fprintf(stderr, "init_file: unable to create thread: %s\n", SDL_GetError());
        return -1;
    }
#endif

    playing = 1;
    return 0;
}

static int close()
{
    if (playing) {
#ifdef HAVE_PTHREAD_H
        if( desmume_thread_id ) {
            ring_stop(&buffer);
            pthread_join(desmume_thread_id, NULL);
            desmume_thread_id = 0;
        }
#else
        if( thread ) {
            ring_stop(&buffer);
            SDL_WaitThread(thread, NULL);
            thread = NULL;
        }
#endif
		xsf_term();
    }

    for(int i = 0; i < 5; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }

    playing = plugin.length = plugin.nfields = 0;
    return 0;
}

static void shutdown()
{
    ring_close(&buffer);
    first_run = 1;
}

static int fill_buffer(signed short *dest, int len)
{
    if(playing) {
        return ring_read(&buffer, (unsigned char *)dest, len);
    }

    return 0;
}

static int can_handle(const char *name)
{
    return (is_ext(name, ".2sf") || is_ext(name, ".mini2sf"));
}

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN ds2sf_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
        memset(&plugin, 0, sizeof(plugin));
        plugin.plugname         = "vio2sf";
        plugin.init_file        = init_file;
        plugin.fill_buffer      = fill_buffer;
        plugin.can_handle       = can_handle;
        plugin.close            = close;
        plugin.shutdown         = shutdown;

        plugin.channels   = 2;
        plugin.freq       = 44100;
        plugin.replaygain = 1;
        plugin.tune       = 0;
        plugin.subtunes   = 1;
        plugin.clockfreq  = 275;
        return &plugin;
    }

}

