/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
    */
#include <SDL/SDL.h>
#include <vector>
#include "FileList.h"
#include "PlayList.h"
#include "M3uPlayList.h"
#include "ZipFileList.h"
#include "SDLScreen.h"
#include "PlayerApp.h"
#include "Input.h"
#include "State.h"
#include "Config.h"
#include "util.h"

#ifndef _WIN32
#define stricmp strcasecmp
#define strnicmp strncasecmp
#endif

extern PlayerApp * g_app;

BrowserState::BrowserState()
{
    zip_list = NULL;
    parent_file_list = NULL;
    parent_selected = 0;
    add_index = -1;
    flagged_index = -1;
}

void BrowserState::Enter()
{
    if(zip_list)
        g_app->pane->SetList(zip_list);
    else
        g_app->pane->SetList(g_app->file_list);
    g_app->UpdateTitle(zip_list);

    g_app->pane->GetList()->SetFlagged(-1);
    flagged_index = -1;
}

bool BrowserState::HandleKey(int key)
{
    ListPane *pane = g_app->pane;
    int selected = -1;
    IFileList *current_list = pane->GetList();

    if(key)
    {

        switch(key)
        {
            int m,t;
            const char *curname;
            case Input::PGUP:
                pane->DoCommand(ListPane::PGUP);
                break;
            case Input::PGDOWN:
                pane->DoCommand(ListPane::PGDN);
                break;
            case Input::UP:
                pane->DoCommand(ListPane::UP);
                break;
            case Input::DOWN:
                pane->DoCommand(ListPane::DOWN);
                break;
            case Input::ENTER:
                selected = current_list->Marked();
                break;
            case Input::BACK:
                selected = -2;
                break;
            case Input::INC_SUBTUNE:
                m = current_list->Marked();
                curname = current_list->GetName(m);
                if (m < 0 ||
                    is_ext(curname,".m3u") || is_ext(curname,".pls") ||
                    is_ext(curname,".opl") || is_fex(curname))
                    break;
                current_list->SetTrack(current_list->GetTrack(m)+1);
                pane->DoCommand(ListPane::JUMPTO,m);
                break;
            case Input::DEC_SUBTUNE:
                m = current_list->Marked();
                curname = current_list->GetName(m);
                if (m < 0 ||
                    is_ext(curname,".m3u") || is_ext(curname,".pls") ||
                    is_ext(curname,".opl") || is_fex(curname))
                    break;
                t = current_list->GetTrack(m);
                if (t >= 0)
                {
                    current_list->SetTrack(t-1);
                    pane->DoCommand(ListPane::JUMPTO,m);
                }
                break;
            case Input::LENGTHUP:
                m = current_list->Marked();
                curname = current_list->GetName(m);
                if (m < 0 ||
                    is_ext(curname,".m3u") || is_ext(curname,".pls") ||
                    is_ext(curname,".opl") || is_fex(curname))
                    break;
                t = current_list->GetTime(m);
                if (t > 0)
                    current_list->SetTime(t+5000);
                else
                    current_list->SetTime(5000);
                pane->DoCommand(ListPane::JUMPTO,m);
                break;
            case Input::LENGTHDOWN:
                m = current_list->Marked();
                curname = current_list->GetName(m);
                if (m < 0 ||
                    is_ext(curname,".m3u") || is_ext(curname,".pls") ||
                    is_ext(curname,".opl") || is_fex(curname))
                    break;
                t = current_list->GetTime(m)/5000;
                if (t <= 1)
                    current_list->SetTime(-1);
                else
                    current_list->SetTime(t*5000 - 5000);
                pane->DoCommand(ListPane::JUMPTO,m);
                break;
            case Input::PLISTADD:
                //if(add_index != current_list->Marked()) // Don't want this anymore.
                {
                    add_index = current_list->Marked();
                    const char *name = current_list->GetName(add_index);
                    const char *path = current_list->GetPath(add_index);
                    if(g_app->music_player->CanHandle(name))
                        g_app->play_list->AddFile(name, current_list->GetSize(add_index),
                                                path, current_list->GetIndex(add_index),
                                                current_list->GetTime(add_index),
                                                current_list->GetTrack(add_index));
                    else if (is_ext(name,".m3u") || is_ext(name,".pls") ||
                             is_ext(name,".opl"))
                    {
                        fprintf(stderr, "BrowserState::HandleKey: appending %s\n",
                                        name);
                        this->AppendPlayList(path);
                        selected = -1;
                    }
                    pane->DoCommand(ListPane::DOWN);
                }
                break;
        }
    }

    if(selected == -1)
        return true;

    add_index = -1;

    if(selected < 0)
    {
        int rc = current_list->Enter(-1);
        if(rc < 0)
        {
            delete current_list;
            current_list = parent_file_list;
            rc = parent_selected;
            parent_selected = 0;
            parent_file_list = NULL;
            zip_list = NULL;
        }
        pane->SetList(current_list);
        g_app->UpdateTitle(zip_list);

        if(rc >= 0)
            current_list->SetMarked(rc);
        pane->DoCommand(ListPane::NOTHING);

        g_app->pane->GetList()->SetFlagged(-1);
        flagged_index = -1;
    }
    else
    {
        int fsize = current_list->GetSize(selected);
        const char *name = current_list->GetName(selected);

        if(fsize == -1)
        {
            current_list->Enter(selected);
            pane->SetList(current_list);
            g_app->UpdateTitle(zip_list);
            current_list->SetMarked(0);
            current_list->SetStart(0);
            pane->DoCommand(ListPane::NOTHING);

            current_list->SetFlagged(-1);
            flagged_index = -1;
            selected = -1;
        }
        else if(is_fex(name))
        {
            parent_file_list = current_list;
            parent_selected = selected;
            zip_list = new ZipFileList(current_list->GetPath(selected),
                                        &(plugin_filter_zip_cb) ,g_app);
            current_list = zip_list;
            pane->SetList(current_list);
            g_app->UpdateTitle(zip_list);

            current_list->SetFlagged(-1);
            flagged_index = -1;
            selected = -1;
        }
        else if(is_playlist(name))
        {
            fprintf(stderr, "BrowserState::HandleKey: clearing playlist and"
                            " creating new\n");
            g_app->play_list->Clear();
            this->AppendPlayList(current_list->GetPath(selected));
            pane->DoCommand(ListPane::DOWN);
            selected = -1;
        }
        else
        {
            g_app->PlaySong(current_list, selected);

            current_list->SetFlagged(selected);
            flagged_index = selected;
            /* pane->DoCommand(ListPane::DOWN); */
            pane->Refresh();
        }
    }
    return true;
}

void BrowserState::QueryNextSong()
{
    if(g_app->music_player->Playing() || (flagged_index < 0))
        return;

    IFileList *current_list = g_app->pane->GetList();
    int selected = flagged_index+1;
    if(selected >= current_list->Size())
    {
        flagged_index = -1;
        return;
    }

    g_app->PlaySong(current_list, selected);
    current_list->SetFlagged(selected);
    flagged_index = selected;
    g_app->pane->Refresh();
}

void BrowserState::AppendPlayList(const char* fname)
{
    M3uPlayList *m3u_list = new M3uPlayList(fname);
    for (; m3u_list->Size(); m3u_list->Next())
    {
        #ifdef APPENDPLAYLISTDEBUG
        fprintf(stderr, "BrowserState::AppendPlayList: checking entry\n");
        #endif
        const char* m3u_path = m3u_list->GetPath();
        const char* m3u_name = m3u_list->GetName();
        int m3u_index        = m3u_list->GetIndex();
        int m3u_time         = m3u_list->GetTime();
        int m3u_track        = m3u_list->GetTrack();

        long fsize = 0;
        if (is_fex(m3u_path))
        {
            fex_t *fex;
            char fname[128];
            error( fex_open( &fex, m3u_path ) );

            int i = 0;
            while( !fex_done( fex ) ) {
                if( i == m3u_index ) {
                    fex_stat( fex );
                    fsize = fex_size( fex );
                    strncpy(fname, fex_name( fex ), 128);
                    fex_close( fex );

                    break;
                }
                error( fex_next( fex ) );
                i++;
            }

            if( fsize == 0 ) continue;
            if (!g_app->music_player->CanHandle(fname))
                continue;

        }
        else
        {
            if (!g_app->music_player->CanHandle(m3u_path))
                continue;
            FILE* fp = fopen(m3u_path,"rb");
            if (!fp)
                continue;
            fseek(fp,0,SEEK_END);
            fsize = ftell(fp);
            fclose(fp);
        }
#ifdef APPENDPLAYLISTDEBUG
        fprintf(stderr, "BrowserState::AppendPlayList: entry looks alright, adding\n");
#endif
        g_app->play_list->AddFile(m3u_name, fsize, m3u_path, m3u_index,
                                m3u_time, m3u_track);
    }
#ifdef APPENDPLAYLISTDEBUG
        fprintf(stderr, "BrowserState::AppendPlayList: done\n");
#endif
    delete m3u_list;
}
