/*  Copyright 2006 Jonas Minnberg

    This file is part of OldPlay - a portable, multiformat musicplayer.

    OldPlay is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    OldPlay is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with OldPlay; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "gme/gme.h"

#include "../plugin.h"
#include "../util.h"

static struct sound_plugin plugin;
gme_t* emu = NULL;
gme_info_t* info = NULL;
gme_err_t rc;

static int playing;
static string fieldname[5];
static string fielddata[5];
static string filename;

static void write_fields(int subtune)
{
    if (!(rc = gme_track_info( emu, &info, subtune ))) {
        plugin.length = info->play_length;

        int x = 0;
        if (strlen(info->game))
        {
            fieldname[x] = "Game";
            fielddata[x] = info->game;
        }
        else
        {
            fieldname[x] = "File";
            fielddata[x] = filename;
        }
        x++;
        if (strlen(info->song))
        {
            fieldname[x] = "Song";
            fielddata[x] = info->song;
            x++;
        }
        if (strlen(info->author))
        {
            fieldname[x] = "Author";
            fielddata[x] = info->author;
            x++;
        }
        if (strlen(info->copyright))
        {
            fieldname[x] = "Copyright";
            fielddata[x] = info->copyright;
            x++;
        }
        if (strlen(info->system))
        {
            fieldname[x] = "Format";
            fielddata[x] = info->system;
            x++;
        }
        plugin.nfields  = x;
        gme_free_info(info);
    }
}

static int init_file(char *fname)
{
    playing = 0;
    plugin.tune = 0;
    plugin.subtunes = 1;
#ifdef A320
    plugin.clockfreq = 360;
    if (is_ext(fname, ".spc"))
	    plugin.clockfreq = 396;
    else if (is_ext(fname, ".gym"))
    	plugin.clockfreq = 408;
    else if (is_ext(fname, ".vgz") || is_ext(fname, ".vgm"))
        plugin.clockfreq = 420;
#else
    plugin.clockfreq = 150;
    if (is_ext(fname, ".gym"))
        plugin.clockfreq = 200;
    else if (is_ext(fname, ".vgz") || is_ext(fname, ".vgm"))
        plugin.clockfreq = 225;
#endif

    if ((rc = gme_open_file(fname, &emu, plugin.freq)))
    {
        fprintf(stderr, "init_file: %s\n",rc);
        return -1;
    }

    /* gme_set_stereo_depth( emu, 0.8 ); */

    ////// M3u //////
    char* fnamem3u = (char*)malloc(sizeof(char)*(strlen(fname)+1));
    strcpy(fnamem3u,fname);
    char* end = strrchr(fnamem3u,'.');
    strcpy(end,".m3u");
    rc = gme_load_m3u( emu, (const char*)fnamem3u );
    free(fnamem3u);
    ////// M3u /////

    plugin.fieldname = fieldname;
    plugin.fielddata = fielddata;
    filename = strrchr(fname, SEPARATOR)+1;

    gme_start_track(emu, plugin.tune);
    write_fields(plugin.tune);
    plugin.subtunes = gme_track_count( emu );
    if( plugin.subtunes <= 0 ) plugin.subtunes = 1;

    /* no fade out for tracks shorter than 10 seconds */
    int fade_length = plugin.length > 10000 ? 4000 : 0;
    gme_set_fade(emu, plugin.length - fade_length, fade_length);

    playing = 1;
    return 0;
}

static int close()
{
    gme_delete(emu);
    for(int i = 0; i < 5; i++)
    {
        fieldname[i].clear();
        fielddata[i].clear();
    }
    playing = plugin.tune = plugin.subtunes = plugin.length = plugin.nfields = 0;
    return 0;
}

static int fill_buffer(signed short *dest, int len)
{
    if(playing)
    {
        rc = gme_play(emu, len>>1, dest);
        if(rc || gme_track_ended(emu))
            return 0;

        return len;
    }
    return 0;
}

static int set_position(int msecs, int subtune)
{
    if (!playing)
        return 0;
    if (msecs == 0)
    {
        gme_start_track(emu, subtune);
        write_fields(subtune);
        int fade_length = plugin.length > 10000 ? 4000 : 0;
        gme_set_fade(emu, plugin.length - fade_length, fade_length);
        return subtune;
    }
    else
    {
        if ((rc = gme_seek(emu, msecs)))
            fprintf(stderr, "set_position: %s\n", rc);
        return msecs;
    }
}

static int can_handle(const char *name)
{
    return (is_ext(name, ".nsf") || is_ext(name, ".nsfe") ||
            is_ext(name, ".spc") || is_ext(name, ".gym") ||
            is_ext(name, ".vgm") || is_ext(name, ".vgz") ||
            is_ext(name, ".sap") || is_ext(name, ".hes") ||
            is_ext(name, ".kss") || is_ext(name, ".gbs") ||
            is_ext(name, ".ay"));
}

extern "C" {

    #ifndef INIT_SOUND_PLUGIN
        #define INIT_SOUND_PLUGIN gme_init_sound_plugin
    #endif

    struct sound_plugin *INIT_SOUND_PLUGIN()
    {
        memset(&plugin, 0, sizeof(plugin));
        plugin.plugname         = "Game_Music_Emu";
        plugin.init_file        = init_file;
        plugin.set_position     = set_position;
        plugin.fill_buffer      = fill_buffer;
        plugin.can_handle       = can_handle;
        plugin.close            = close;

        plugin.channels   = 2;
        plugin.freq       = 44100;
        plugin.replaygain = 1;
        return &plugin;
    }

}
