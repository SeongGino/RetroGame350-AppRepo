OLDPLAY
-------

OldPlay is a music player that uses libsidplay1, modplug, UADE
amd libmad to play a multitude of classic music formats.

Sids are played using libsidplay1 (resid wouldnt work on gp2x) and
so filter emulation is far from perfect.

Amiga formats uses UADE, which is based on UAE (The Amiga Emulator)
and Eagleplayer. It takes quite a lot of CPU so the equalizer is
automatically turned off when playing amiga formats. However, if
you want to avoid stuttering on TFMX and other songs that require
a bit more CPU, you can try overclocking.

Nintendo and Sega 8 & 16bit music are played using Game Music Emu.

MP3s are played with libmad. Simple ID3 tag parsing is present
(Title and artist) and length are calculated for CBR songs.

Oldplay also uses libzip to look inside zipfiles (which is almost
a requirement when playing from HVSC).

See CHANGELOG for changes from here on / Micket

MAJOR CHANGES SINCE v0.9
------------------------

HOLD and BLANK functions (Locks keys, turns off screen)
Configurable GUI (via config file)
Battery indicator
Shuffle play
CPU Scaling (diffrent CPU frequncies for different formats)
Settings-file (remembers volume, shuffle & repeat)
SID Songlengths (via Songlengths.txt from HVSC)

MAJOR CHANGES SINCE v0.8
------------------------

MP3 playback
SPC,NFS,GBS,GYM and VGM playback
Playlist

INSTALL
-------

Copy all files except the *.font, *.exe and *.dll to your flashcard.
(Start the windows version by doubleclicking the exe)

FORMATS
-------
Too many to list; In theory everything that modlug and eagleplayer
supports. Some notes however;

- Amiga formats requiring fasthack doesnt play currently.

KEYS
----

GP2X    Win      Action
......  .......  .......................... 
Vol     F1/F2    Volume
Stick   F1/F3    Stereo Mix
Start   SPACE    Pause
Joy     Cursor   Navigate & Subsongs
Sel     Tab      Switch playlist/browser
B       ENTER    Play, Enter dir or zipfile
Y       a        Add song to playlist
 (in playlist)   Move song to after current
X       BSPACE   Parent
R+X              Remove song (in playlist)
A       n        Skip to Next Song
R+A     p        Skip to previous song
R+Y     r        Repeat On/Off
R+B     s        Shuffle On/Off
R+Up    PGUP     Page Up
R+Down  PGDN     Page Down
R+Start ESC      Quit

R+Select         Screen & backlighting on/off
R+L              Hold (lock keys). Note: R _then_ L
R+Stick          Activate/cycle CPU Scaling (see below)

CPU SCALING
-----------

This feature is still a bit buggy it seems. Its turned off by
default, but you can activate it by changing that option in
the ".setting" file, or with R+Stick.

When it is active, different cpu speeds are used for different
sound formats, currently 100MHz for Sid and mod, 150MHz for MP3 and
GME, and 250MHz for Amiga music.

Pressing R+Stick-click in the player will cycle different cpu-
speeds, and also turn on cpu scaling if it is not on. It cycles
25Mhz at a time from 250->50MHz.

GUI THEME
---------

The "default.cfg" specifies all colors, the font and the graphics
used for the LED. It should be pretty self-explainatory.
If you give a filename on the commandline, that config-file will
be used instead.

BUGS
----

- Sometimes the sound fails to initialize. The player tries
to reinit several times, then exits. You can then try to
start it again.

SOURCECODE
----------

...is available through subversion

-- Sasq
