// vim: noexpandtab ts=4
#include <iostream>
#include <fstream>
#include <iomanip>
#include <iconv.h>
#include <cstring>
using namespace std;

#define VERSION "0.01"

void usage() {
	cout << "Easy Memory Card Reader ver." << VERSION << endl;
	cout << "  Usage:mcdread <MEMORYCARDFILE>"        << endl;
}

string convert_encoding(const string &str, const char *fromcode, const char *tocode)
{
	char *outstr, *instr;
	iconv_t icd;
	size_t instr_len  = strlen(str.c_str());
	size_t outstr_len = instr_len*2;

	if (instr_len <= 0) return "";

	// allocate memory
	instr  = new char[instr_len+1];
	outstr = new char[outstr_len+1];
	strcpy(instr, str.c_str());
	icd = iconv_open(tocode, fromcode);
	if (icd == (iconv_t)-1) {
		return "Failed to open iconv (" + string(fromcode) + " to " + string(tocode) + ")";
	}
	char *src_pos = instr, *dst_pos = outstr;
	if (iconv(icd, &src_pos, &instr_len, &dst_pos, &outstr_len) == -1) {
		// return error message
		string errstr;
		int err = errno;
		if (err == E2BIG) {
			errstr = "There is not sufficient room at *outbuf";
		} else if (err == EILSEQ) {
			errstr = "An invalid multibyte sequence has been encountered in the input";
		} else if (err = EINVAL) {
			errstr = "An incomplete multibyte sequence has been encountered in the input";
		}
		iconv_close(icd);
		return "Failed to convert string (" + errstr + ")";
	}
	*dst_pos = '\0';
	iconv_close(icd);

	string s(outstr);
	delete[] instr;
	delete[] outstr;

	return s;
}


int main(int argc, char* argv[]) {
	char buf[128*1024];

	if (argc != 2) {
		usage();
		return -1;
	}
	fstream file;
	file.open(argv[1], ios::binary | ios::in);

	// data read.
	file.read(buf, sizeof(buf));
	file.close();

	// header check.
	if (buf[0x00] != 'M' or buf[0x01] != 'C') {
		cerr << "Not supported." << endl;
		return -1;
	}

	int bused=0;
	std::ios::fmtflags curret_flag = std::cout.flags();
	for (int ofset = 0x80; ofset < 0x800; ofset += 0x80) {
		int of = ofset+0xa;
		cout << "No." << setw(2) << setfill('0') << ofset/0x80;
		if (buf[of] == 'B') {
			string GameCode(&buf[of], &buf[of]+20);
			string Country("JP");
			if (GameCode.substr(1,2) == "BA")
				Country = "US";
			else if (GameCode.substr(1,2) == "BU")
				Country = "EU";
			int len;
			for (len=0; len<8; len++)
				if (buf[of+12+len] == 0x00) break;
			string id(GameCode.substr(12,len) + "         ");

			int dofset = ofset/0x80*0x2000;
			int bn(buf[dofset+3]);
			if (bn > 0) {
				bused += bn;

				for (len=0; len<64; len++)
					if (buf[dofset+4+len] == 0x00) break;
				string ti(&buf[dofset+4], len);

				cout << " " << GameCode.substr(2,10) << "(" << Country << ")/" << id.substr(0,9) << "(" << bn << " BlockUsed)" << endl;
				cout << "      " << convert_encoding(ti, "CP932", "UTF-8") << endl;
				std::cout.flags(curret_flag);
			} else
				cout << endl << endl;;
		} else
			cout << endl << endl;;
	}
	cout << "Total: " << bused << " BlockUsed." << endl;
	return 0;
}

/*
mipsel-linux-gcc -o mcdread mcdread.cpp -lstdc++
*/

