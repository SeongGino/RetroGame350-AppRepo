#!/bin/sh

echo "----"
BNAME="$(basename "$3")"
WD=${PWD}
cd $(dirname "$3")

if [ $1 == "-d" ]; then
    find "${BNAME}" -type f -exec ${WD}/minizip -9 -a "$2" {} \;
else
    ${WD}/minizip -9 -a "$2" "${BNAME}"
fi


