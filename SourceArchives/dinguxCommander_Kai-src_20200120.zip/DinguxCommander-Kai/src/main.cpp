#include <cstdlib>
#include <iostream>
#include <SDL.h>
#include <SDL_ttf.h>
#include "def.h"
#include "sdlutils.h"
#include "resourceManager.h"
#include "commander.h"

// Globals
SDL_Surface *Globals::g_screen = NULL;
const SDL_Color Globals::g_colorTextNormal = {COLOR_TEXT_NORMAL};
const SDL_Color Globals::g_colorTextDisable = {COLOR_TEXT_DISABLE};
const SDL_Color Globals::g_colorTextTitle = {COLOR_TEXT_TITLE};
const SDL_Color Globals::g_colorTextDir = {COLOR_TEXT_DIR};
const SDL_Color Globals::g_colorTextSelected = {COLOR_TEXT_SELECTED};
std::vector<CWindow *> Globals::g_windows;

int main(int argc, char** argv)
{
    // Avoid crash due to the absence of mouse
    {
        char l_s[]="SDL_NOMOUSE=1";
        putenv(l_s);
    }

    // Init SDL
    SDL_Init(SDL_INIT_VIDEO);

    // Screen
    Globals::g_screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_BPP, SURFACE_FLAGS);
    if (Globals::g_screen == NULL)
    {
        std::cerr << "SDL_SetVideoMode failed: " << SDL_GetError() << std::endl;
        return 1;
    }

    // Hide cursor
    SDL_ShowCursor(SDL_DISABLE);

    // Init font
    if (TTF_Init() == -1)
    {
        std::cerr << "TTF_Init failed: " << SDL_GetError() << std::endl;
        return 1;
    }

    // Create instances
    CResourceManager::instance();
    char *home = getenv("HOME");
    std::string l_path_l = home ? home : PATH_DEFAULT;
    std::string l_path_r(l_path_l);
    if (!CResourceManager::instance().getResumePathLeft().empty())
        l_path_l = CResourceManager::instance().getResumePathLeft();
    if (!CResourceManager::instance().getResumePathRight().empty())
        l_path_r = CResourceManager::instance().getResumePathRight();
    CCommander l_commander(l_path_l, l_path_r);

    // Main loop
    l_commander.execute();

    CResourceManager::instance().OutputResumePath(
            l_commander.getLeftCurrentPath(),
            l_commander.getRightCurrentPath());

    //Quit
    SDL_utils::hastalavista();

    return 0;
}
