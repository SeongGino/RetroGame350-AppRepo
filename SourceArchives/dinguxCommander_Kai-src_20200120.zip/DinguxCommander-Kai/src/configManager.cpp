#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <algorithm>
#include <errno.h>
#include <string.h>
#include "configManager.h"

CConfigMan & CConfigMan::instance(const string &p_file)
{
    static CConfigMan l_singleton(p_file);
    return l_singleton;
}

CConfigMan::CConfigMan(const string &p_iniFile, const bool p_isCasesense):
    m_iniFileName(p_iniFile),
    m_caseSense(p_isCasesense)
{
    reloadFile(m_iniFileName);
}

CConfigMan::~CConfigMan(void){}

bool CConfigMan::reloadFile(const string &p_file)
{
    if (!p_file.empty())
        m_iniFileName = p_file;

    if (!updateCheck(m_iniFileName))
        return true;

    ifstream ifs(m_iniFileName);
    if (!ifs.fail()) {
        string line;
        string sect(DEFAULT_SECTION);
        size_t idx;
        m_inits.clear();
        while (getline(ifs, line)) {
            // skip comment
            if (line.find("#") != 0 && (idx = line.find("=")) != string::npos) {
                // split
                string l_key(line.substr(0,idx));
                string l_val(line.substr(idx+1));
                // trim & upper
                trim(l_key);
                toUpper(l_key);
                // ltrim
                ltrim(l_val);
                // push_back
                m_inits.emplace(l_key, l_val);
            }
        }
        ifs.close();
    } else {
        cerr << "CConfigMan::reloadFile() file open error.: " << m_iniFileName << endl;
        return false;
    }

    return true;
}

bool CConfigMan::updateCheck(const string &p_file)
{
    time_t l_mtime(m_stat.st_mtime);
    if (stat(p_file.c_str(), &m_stat) != 0) {
        cerr << "CConfigMan::updateCheck() stat error. : " << p_file << " (" << strerror(errno) << ")" << endl;
        if (errno == ENOENT) {
            ofstream ofs(p_file);
            ofs.close();
            cerr << "  created." << endl;
        }
    }
    if (m_stat.st_mtime == l_mtime) {
        return false;
    }

    return true;
}

bool CConfigMan::writeFile(void)
{
    if (m_iniFileName.empty())
        return false;

    string l_writeFile(m_iniFileName + ".new");

    // process & write lines
    ifstream ifs(m_iniFileName);
    ofstream ofs(l_writeFile);
    if (!ifs.fail() && !ofs.fail()) {
        string sect(DEFAULT_SECTION);
        size_t idx;
        map<string, string> l_ini(m_inits);
        string line;
        while (getline(ifs, line)) {
            // find '='
            if ((idx = line.find("=")) == string::npos)
                ofs << line << endl;
            else {
                // split
                string l_key(line.substr(0,idx));
                string l_okey(l_key);
                // trim & upper
                trim(l_key);
                toUpper(l_key);
                // search & write
                if (l_ini.count(l_key) == 1) {
                    ofs << l_okey << "=" << l_ini[l_key] << endl;
                    l_ini.erase(l_key);
                }
            }
        }
        // Add new parameters
        for (auto l_i: l_ini) {
            ofs << l_i.first << "=" << l_i.second << endl;
        }
        ofs.close();
        ifs.close();
    } else {
        cerr << "CConfigMan::writeFile() file open error.: " << m_iniFileName << " or " << l_writeFile << endl;
        return false;
    }

    rename(l_writeFile.c_str(), m_iniFileName.c_str());

    return reloadFile();
}

map<string, string> CConfigMan::getValue(void)
{
    reloadFile();
    return m_inits;
}

string CConfigMan::getValue(string p_key)
{
    reloadFile();
    // upper
    toUpper(p_key);

    if (m_inits.count(p_key) == 0)
        return "";

    return m_inits[p_key];
}

void CConfigMan::setValue(const char p_key[], string p_val)
{
    string l_key(p_key);
    // trim & upper
    trim(l_key);
    toUpper(l_key);
    // ltrim
    ltrim(p_val);

    // push_back
    m_inits.erase(l_key);
    m_inits.emplace(l_key, p_val);

    writeFile();

    return;
}

void CConfigMan::setValue(map<string, string> p_params)
{
    for (auto l_i: p_params) {
        // set values
        setValue(l_i.first.c_str(), l_i.second);
    }

    writeFile();

    return;
}

void CConfigMan::deleteValue(string p_key)
{
    // trim & upper
    trim(p_key);
    toUpper(p_key);

    // erase
    m_inits.erase(p_key);
    // setValue(p_key, DELETE_WORD);

    writeFile();

    return;
}

const vector<string> &CConfigMan::splitValie(const string &p_value, const char p_sep)
{
    vector<string> l_res;
    stringstream ss(p_value);
    string l_item;
    while (getline(ss, l_item, p_sep)) {
        if (!l_item.empty()) {
            l_res.push_back(l_item);
        }
    }

    return l_res;
}


void CConfigMan::ltrim(string &p_str)
{
    if (p_str.size() == 0)
        return;

    size_t idx;
    // ltrim
    if ((idx = p_str.find_first_not_of(TRIM_CHARS)) != string::npos)
        p_str = p_str.substr(idx);

    return;
}


void CConfigMan::trim(string &p_str)
{
    size_t idx;

    // trim & upper
    idx = p_str.find_last_not_of(TRIM_CHARS);
    p_str = p_str.substr(0,idx+1);
    ltrim(p_str);

    return;
}

void CConfigMan::toUpper(string &p_str)
{
    if (!m_caseSense)
        transform(p_str.cbegin(), p_str.cend(), p_str.begin(), ::toupper);

    return;
}

