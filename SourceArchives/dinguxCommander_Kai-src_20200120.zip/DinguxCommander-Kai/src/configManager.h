#ifndef _CONFIGMAN_H_
#define _CONFIGMAN_H_

#include <string>
#include <map>
#include <vector>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

using namespace std;

#define DEFAULT_SECTION "Global"
#define TRIM_CHARS "\t\v\r\n "

class CConfigMan
{
public:
    static CConfigMan& instance(const string &p_file="");

    CConfigMan(const string &p_iniFile, const bool p_isCasesense=false);
    virtual ~CConfigMan(void);

    // value edit
    string getValue(string p_key);
    map<string,string> getValue(void);
    void setValue(const char p_key[], string p_val);
    void setValue(map<string, string> p_params);
    void deleteValue(string p_key);

    const vector<string> &splitValie(const string &p_value, const char p_sep=",");

private:
    struct stat m_stat;
    string m_iniFileName;
    map<string, string> m_inits;
    bool m_caseSense;

    bool reloadFile(const string &p_file="");
    bool writeFile(void);
    bool updateCheck(const string &p_file);
    void ltrim(string &p_str);
    void trim(string &p_str);
    void toUpper(string &p_str);
};

#endif
