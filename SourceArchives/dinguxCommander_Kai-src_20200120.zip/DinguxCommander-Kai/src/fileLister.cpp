#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <algorithm>
#include <string.h>
#include <unistd.h>
#include "fileLister.h"

bool compareNoCase(const T_FILE& p_s1, const T_FILE& p_s2)
{
    return strcasecmp(p_s1.m_name.c_str(), p_s2.m_name.c_str()) <= 0;
}

CFileLister::CFileLister(void)
{
}

CFileLister::~CFileLister(void)
{
}

const bool CFileLister::list(const std::string &p_path)
{
    // Open dir
    DIR *l_dir = opendir(p_path.c_str());
    if (l_dir == NULL)
    {
        std::cerr << "CFileLister::list: Error opening dir " << p_path << std::endl;
        return false;
    }
    // Clean up
    m_listFiles.clear();
    m_listDirs.clear();
    // Read dir
    std::string l_file1("");
    std::string l_file2("");
    std::string l_fileFull1("");
    std::string l_fileFull2("");
    struct stat l_stat1;    // for symlink
    struct stat l_stat2({0,0,0,0,0,0,0,0,0,0});
    struct dirent *l_dirent = readdir(l_dir);
    while (l_dirent != NULL)
    {
        l_file1 = l_dirent->d_name;
        // Filter the '.' and '..' dirs
        if (l_file1 != "." && l_file1 != "..")
        {
            // Stat the file
            l_fileFull1 = p_path + "/" + l_file1;
            if (lstat(l_fileFull1.c_str(), &l_stat1) == -1)
            {
                std::cerr << "CFileLister::list: Error lstat " << l_fileFull1 << std::endl;
            }
            else
            {
                // Check symbolic link
                if (S_ISLNK(l_stat1.st_mode))
                {
                    char buf[l_stat1.st_size+1];
                    ssize_t r = readlink(l_fileFull1.c_str(), buf, l_stat1.st_size+1);
                    if (r == -1)
                        std::cerr << "CFileLister::list: Error readlink " << l_fileFull1 << std::endl;
                    else {
                        buf[r] = '\0';
                        l_file2 = std::string(buf);
                        if (l_file2[0] == '/')
                            l_fileFull2 = l_file2;
                        else
                            l_fileFull2 = p_path + "/" + l_file2;
                        if (stat(l_fileFull2.c_str(), &l_stat2) == -1)
                        {
                            std::cerr << "CFileLister::list: Error stat " << l_fileFull2 << std::endl;
                        }
                    }
                }
                // Check type
                if (S_ISDIR(l_stat1.st_mode) || (S_ISLNK(l_stat1.st_mode) && S_ISDIR(l_stat2.st_mode))) {
                    // It's a directory
                    //m_listDirs.push_back(T_FILE(l_file, l_stat.st_size));
                    m_listDirs.push_back(T_FILE(l_file1, l_stat1, l_file2, l_stat2));
                    // std::cerr << "CFileLister::list: listDir.push_back : " << l_file1 << "##" << l_file2 << std::endl;
                } else {
                    // It's a file
                    //m_listFiles.push_back(T_FILE(l_file, l_stat.st_size));
                    m_listFiles.push_back(T_FILE(l_file1, l_stat1, l_file2, l_stat2));
                    // std::cerr << "CFileLister::list: listFile.push_back: " << l_file1 << "##" << l_file2 << std::endl;
                }
            }
        }
        // Next
        l_dirent = readdir(l_dir);
    }
    // Close dir
    closedir(l_dir);
    // Sort lists
    sort(m_listFiles.begin(), m_listFiles.end(), compareNoCase);
    sort(m_listDirs.begin(), m_listDirs.end(), compareNoCase);
    // Add "..", always at the first place
    l_fileFull1 = p_path + "/..";
    if (stat(l_fileFull1.c_str(), &l_stat1) == -1)
    {
        std::cerr << "CFileLister::list: Error lstat " << l_fileFull1 << std::endl;
    }
    m_listDirs.insert(m_listDirs.begin(), T_FILE("..", l_stat1));
    return true;
}

const T_FILE &CFileLister::operator[](const unsigned int p_i) const
{
    if (p_i < m_listDirs.size())
        return m_listDirs[p_i];
    else
        return m_listFiles[p_i - m_listDirs.size()];
}

const unsigned int CFileLister::getNbDirs(void) const
{
    return m_listDirs.size();
}

const unsigned int CFileLister::getNbFiles(void) const
{
    return m_listFiles.size();
}

const unsigned int CFileLister::getNbTotal(void) const
{
    return m_listDirs.size() + m_listFiles.size();
}

const bool CFileLister::isDirectory(const unsigned int p_i) const
{
    return p_i < m_listDirs.size();
}

const bool CFileLister::isLink(const unsigned int p_i) const
{
    if (p_i < m_listDirs.size())
        return S_ISLNK(m_listDirs[p_i].m_stat.st_mode);

    return S_ISLNK(m_listFiles[p_i - m_listDirs.size()].m_stat.st_mode);
}

const unsigned int CFileLister::searchDir(const std::string &p_name) const
{
    unsigned int l_ret = 0;
    bool l_found = false;
    // Search name in dirs
    for (std::vector<T_FILE>::const_iterator l_it = m_listDirs.begin(); (!l_found) && (l_it != m_listDirs.end()); ++l_it)
    {
        if ((*l_it).m_name == p_name)
            l_found = true;
        else
            ++l_ret;
    }
    return l_found ? l_ret : 0;
}
