#!/bin/sh

OPK_NAME=dinguxcmd_kai-$(date +%Y%m%d).opk

echo ${OPK_NAME}

# create default.gcw0.desktop
cat > default.gcw0.desktop <<EOF
[Desktop Entry]
Name=DinguxCmdrKai
Comment=Two-pane file manager $(date +%Y%m%d)
Exec=DinguxCommanderKai
Terminal=false
Type=Application
StartupNotify=true
Icon=cmdr_kai
Categories=applications;
X-OD-NeedsDownscaling=false
EOF

# create opk
FLIST="default.gcw0.desktop"
FLIST="${FLIST} output/opendingux-gcw0/DinguxCommanderKai"
FLIST="${FLIST} res/mcdread"
FLIST="${FLIST} res/opkimginfo.sh"
FLIST="${FLIST} res/minizip"
FLIST="${FLIST} res/minizr.sh"
FLIST="${FLIST} res/Fiery_Turk.ttf"
FLIST="${FLIST} res/background.png"
FLIST="${FLIST} res/background_l.png"
FLIST="${FLIST} res/background.org.png"
FLIST="${FLIST} res/file.png"
FLIST="${FLIST} res/file_l.png"
FLIST="${FLIST} res/folder.png"
FLIST="${FLIST} res/folder_l.png"
FLIST="${FLIST} res/font.ttf"
FLIST="${FLIST} res/icon.png"
FLIST="${FLIST} res/cmdr_kai.png"
FLIST="${FLIST} res/JF-Dot-MPlus10.ttf"
FLIST="${FLIST} res/up.png"


rm -f ${OPK_NAME}
mksquashfs ${FLIST} ${OPK_NAME} -all-root -no-xattrs -noappend -no-exports

cat default.gcw0.desktop
rm -f default.gcw0.desktop

RHOST=10.1.1.2
ping -c1 ${RHOST}
if [ $? -eq 0 ];then
  scp ${OPK_NAME} root@${RHOST}:/media/sdcard/apps/
fi

