#!/usr/bin/env python2
# -*- coding: utf_8 -*- 
import sys
import struct
import binascii

if len(sys.argv) < 2 or sys.argv[1] == '':
    exit(1)

try:
    with open(sys.argv[1], "rb") as f:
        buf = f.read(128*1024)
except Exception as e:
    print(e)
    exit(1)

if buf[:2] != b"MC" or len(buf) != 128*1024:
    print "Not supported."
    exit(1)

for ofset in range(0x80, 0x800, 0x80):
    of = ofset+0xa
    print "No.{:02d}".format(ofset/0x80, ofset),
    if buf[of] == b"B":
        cc, pc, id = struct.unpack('2s10s8s', buf[of:of+20])
        country = "JP"
        if cc == "BA":
            country = "US"
        elif cc == "BE":
            country = "EU"

        # Read Data Block
        dofset = ofset/0x80*0x2000
        cc, ic, bn, ti = struct.unpack('2sbb64s', buf[dofset:dofset+68])

        if bn > 0:
            print "{}({})/{:8s} ({} BlockUsed)".format(pc, country, id.rstrip('\0'), bn)
            ti.rstrip('　\0')
            ti_utf8 = ti.decode("cp932", errors="ignore")
            print "     ",
            print ti_utf8
        else:
            print ""
            print ""
    else:
        print ""
        print ""

