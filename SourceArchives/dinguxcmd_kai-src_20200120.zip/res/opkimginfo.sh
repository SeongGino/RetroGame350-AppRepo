#!/bin/sh

usage(){
cat <<- _EOL_
Usage: ${0} <OPKFILE> <TEMPDIR> <LOGFILE>

_EOL_
}

#~.opk
FILENM=$1
#/tmp/cmd$$
TMPDIR=$2
#/tmp/cmd$$.log
LOGFIL=$3

if [ $# -lt 1 ];then
  usage
  exit 1
fi

[ "${TMPDIR}z" = "z" ] && TMPDIR=/tmp/cmd$$
MOUNTP=${TMPDIR}/mp
/bin/mkdir -p ${MOUNTP}
[ "${LOGFIL}z" = "z" ] && LOGFIL=${TMPDIR}/cmd.log

opkinfo "${FILENM}"                          > ${LOGFIL}
echo "opk_id: "$(md5sum "${FILENM}" | awk '{print substr($1,27)}') >> ${LOGFIL}
echo ""
mount -t squashfs -o loop "${FILENM}" ${MOUNTP}
cd ${MOUNTP}
cp $(cat *.gcw0.desktop *.all.desktop | grep -E "^Icon\s*=" | head -n 1 | sed -e 's/Icon\s*=//').png ${TMPDIR}
ls -lR                                               >> ${LOGFIL}
cd - >/dev/null
umount ${MOUNTP}

