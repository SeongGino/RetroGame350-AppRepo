#ifndef _RESOURCEMANAGER_H_
#define _RESOURCEMANAGER_H_

#include <SDL.h>
#include <SDL_ttf.h>
#include <map>
#include <vector>

#define NB_SURFACES 11

#define CONF_RESUME_LEFT    "RESUME_LEFT"
#define CONF_RESUME_RIGHT   "RESUME_RIGHT"
#define CONF_FONT_FILE_NAME "FONT_FILE_NAME"
#define CONF_BOOKMARK       "BOOKMARK_"
#define CONF_BOOKMARK1      "BOOKMARK_1"
#define CONF_BOOKMARK2      "BOOKMARK_2"
#define CONF_BOOKMARK3      "BOOKMARK_3"
#define CONF_BOOKMARK4      "BOOKMARK_4"
#define CONF_BOOKMARK5      "BOOKMARK_5"
#define CONF_BOOKMARK6      "BOOKMARK_6"
#define CONF_BOOKMARK7      "BOOKMARK_7"
#define CONF_BOOKMARK8      "BOOKMARK_8"
#define CONF_BOOKMARK9      "BOOKMARK_9"
#define CONF_SCRIPT         "SCRIPT_"
#define CONF_SCRIPT1        "SCRIPT_1"
#define CONF_SCRIPT2        "SCRIPT_2"
#define CONF_SCRIPT3        "SCRIPT_3"
#define CONF_SCRIPT4        "SCRIPT_4"
#define CONF_SCRIPT5        "SCRIPT_5"
#define CONF_SCRIPT6        "SCRIPT_6"
#define CONF_SCRIPT7        "SCRIPT_7"
#define CONF_SCRIPT8        "SCRIPT_8"
#define CONF_SCRIPT9        "SCRIPT_9"


// using T_INI_ITEM = std::map<std::string, std::string>;
struct T_BOOKMARK
{
    std::string m_name;
    std::string m_url;
};


class CResourceManager
{
    public:

    typedef enum
    {
        T_SURFACE_BG = 0,
        T_SURFACE_FILE,
        T_SURFACE_FILE_LINK,
        T_SURFACE_FOLDER,
        T_SURFACE_FOLDER_LINK,
        T_SURFACE_UP,
        T_SURFACE_CURSOR1,
        T_SURFACE_CURSOR2,
        T_SURFACE_CURSORWL1,
        T_SURFACE_CURSORWL2,
        T_SURFACE_CURSORWR
    }
    T_SURFACE;

    // Method to get the instance
    static CResourceManager& instance(void);

    // Cleanup all resources
    void sdlCleanup(void);

    // Get a loaded surface
    SDL_Surface *getSurface(const T_SURFACE p_surface) const;

    // Get the loaded font
    TTF_Font *getFont(void) const;

    // resume path
    std::string getResumePathLeft(void) const;
    std::string getResumePathRight(void) const;
    void OutputResumePath(std::string p_resPathLeft, std::string p_resPathRight) const;

    // bookmark
    const std::vector<T_BOOKMARK> &getBookmark(void) const;
    // ini file
    // void loadInit(std::string p_iniFile="");
    // void saveInit(std::vector<T_INI_ITEM> &p_items, std::string p_iniFile="");
    // void saveInitItem(T_INI_ITEM p_item, std::string p_iniFile="");

    // short script
    const std::vector<std::string> &getScript(void) const;

    private:

    // Forbidden
    CResourceManager(void);
    CResourceManager(const CResourceManager &p_source);
    const CResourceManager &operator =(const CResourceManager &p_source);

    // Images
    SDL_Surface *m_surfaces[NB_SURFACES];

    // Font
    TTF_Font *m_font;

    // Bookmark
    std::vector<T_BOOKMARK> m_bookmark;

    // Script
    std::vector<std::string> m_script;

    // CONFIG Path
    std::string m_configPath;
    std::string m_configFile;

    std::string m_resumePathLeft;
    std::string m_resumePathRight;
};

#endif
