#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <limits.h>

#include <iostream>
#include <fstream>
#include "resourceManager.h"
#include "configManager.h"
#include "def.h"
#include "sdlutils.h"
#include "def.h"

CResourceManager& CResourceManager::instance(void)
{
    static CResourceManager l_singleton;
    return l_singleton;
}

#define MKDIR(A) mkdir(A, 0777)
#define DEFAULT_CONFIG_PATH "/media/home/.config/dinguxcmdrkai"

static char *home = NULL;
static char homedir[PATH_MAX] = "./.config/dinguxcmdrkai";

CResourceManager::CResourceManager(void) :
    m_font(NULL),
    m_configPath(DEFAULT_CONFIG_PATH),
    m_resumePathLeft(""),
    m_resumePathRight("")
{
    home = getenv("HOME");
    if (home) {
        sprintf(homedir, "%s/.config/dinguxcmdrkai", home);
        m_configPath = homedir;
    }
    MKDIR(homedir);
    std::cerr << "CResourceManager::m_configPath: " << m_configPath << std::endl;

    // m_resumeFile = m_configPath + "/resume.txt";
    m_configFile = m_configPath + "/config.ini";
    CConfigMan::instance(m_configFile);

    // Load resume path
    m_resumePathLeft  = CConfigMan::instance().getValue(CONF_RESUME_LEFT);
    m_resumePathRight = CConfigMan::instance().getValue(CONF_RESUME_RIGHT);
    cerr << "CResourceManager::resumePathLeft : " << m_resumePathLeft  << std::endl;
    cerr << "CResourceManager::resumePathRight: " << m_resumePathRight << std::endl;

    // Load bookmark
    for (int i=1; i<10; i++) {
        std::string l_key(CONF_BOOKMARK + std::to_string(i));
        std::string l_value(CConfigMan::instance().getValue(l_key));
        size_t idx(l_value.find(","));
        if (!l_value.empty() && idx != std::string::npos) {
            std::string l_name(l_value.substr(0,idx));
            std::string l_url(l_value.substr(idx+1));
            if (l_url.rfind("/") == l_url.length()-1)
                l_url = l_url.substr(0, l_url.length()-1);
            m_bookmark.push_back({l_name, l_url});
        }
    }
    if (m_bookmark.size() == 0) {
        m_bookmark.push_back({"HOME", "/media/home"});
        m_bookmark.push_back({"apps", "/media/data/apps"});
        m_bookmark.push_back({"SD apps", "/media/sdcard/apps"});
        m_bookmark.push_back({"SD root", "/media/sdcard"});
    }

    // Load script
    for (int i=1; i<10; i++) {
        std::string l_key(CONF_SCRIPT + std::to_string(i));
        std::string l_value(CConfigMan::instance().getValue(l_key));
        if (!l_value.empty())
            m_script.push_back(l_value);
    }

    // Load images
    m_surfaces[T_SURFACE_BG] = SDL_utils::loadImage(RESDIR "/background.png");
    m_surfaces[T_SURFACE_FILE] = SDL_utils::loadImage(RESDIR "/file.png");
    m_surfaces[T_SURFACE_FILE_LINK] = SDL_utils::loadImage(RESDIR "/file_l.png");
    m_surfaces[T_SURFACE_FOLDER] = SDL_utils::loadImage(RESDIR "/folder.png");
    m_surfaces[T_SURFACE_FOLDER_LINK] = SDL_utils::loadImage(RESDIR "/folder_l.png");
    m_surfaces[T_SURFACE_UP] = SDL_utils::loadImage(RESDIR "/up.png");
    m_surfaces[T_SURFACE_CURSOR1]   = SDL_utils::createImage(SCREEN_WIDTH/2-1, LINE_HEIGHT, SDL_MapRGB(Globals::g_screen->format, COLOR_CURSOR_1));
    m_surfaces[T_SURFACE_CURSOR2]   = SDL_utils::createImage(SCREEN_WIDTH/2-1, LINE_HEIGHT, SDL_MapRGB(Globals::g_screen->format, COLOR_CURSOR_2));
    m_surfaces[T_SURFACE_CURSORWL1] = SDL_utils::createImage(PANEL_SIZE_WL, LINE_HEIGHT, SDL_MapRGB(Globals::g_screen->format, COLOR_CURSOR_1));
    m_surfaces[T_SURFACE_CURSORWL2] = SDL_utils::createImage(PANEL_SIZE_WL, LINE_HEIGHT, SDL_MapRGB(Globals::g_screen->format, COLOR_CURSOR_2));
    m_surfaces[T_SURFACE_CURSORWR]  = SDL_utils::createImage(PANEL_SIZE_WR, LINE_HEIGHT, SDL_MapRGB(Globals::g_screen->format, COLOR_CURSOR_2));
    // Load font
    string l_fontName(CConfigMan::instance().getValue(CONF_FONT_FILE_NAME));
    if (l_fontName.empty()) {
        l_fontName = "font.ttf";
        CConfigMan::instance().setValue(CONF_FONT_FILE_NAME, l_fontName);
    }
    m_font = SDL_utils::loadFont(m_configPath + "/" + l_fontName, 10);
    if (m_font == NULL)
        m_font = SDL_utils::loadFont(RESDIR "/font.ttf", 10);
    if (m_font == NULL)
        m_font = SDL_utils::loadFont(RESDIR "/Fiery_Turk.ttf", 8);
}

void CResourceManager::sdlCleanup(void)
{
    INHIBIT(std::cout << "CResourceManager::sdlCleanup" << std::endl;)
    int l_i(0);
    // Free surfaces
    for (l_i = 0; l_i < NB_SURFACES; ++l_i)
    {
        if (m_surfaces[l_i] != NULL)
        {
            SDL_FreeSurface(m_surfaces[l_i]);
            m_surfaces[l_i] = NULL;
        }
    }
    // Free font
    if (m_font != NULL)
    {
        TTF_CloseFont(m_font);
        m_font = NULL;
    }
}

SDL_Surface *CResourceManager::getSurface(const T_SURFACE p_surface) const
{
    return m_surfaces[p_surface];
}

TTF_Font *CResourceManager::getFont(void) const
{
    return m_font;
}

const std::vector<T_BOOKMARK> &CResourceManager::getBookmark(void) const
{
    return m_bookmark;
}

const std::vector<std::string> &CResourceManager::getScript(void) const
{
    return m_script;
}

std::string CResourceManager::getResumePathLeft(void) const
{
    return m_resumePathLeft;
}

std::string CResourceManager::getResumePathRight(void) const
{
    return m_resumePathRight;
}

void CResourceManager::OutputResumePath(std::string p_resPathLeft, std::string p_resPathRight) const
{
    CConfigMan::instance().setValue("RESUME_LEFT",  p_resPathLeft);
    CConfigMan::instance().setValue("RESUME_RIGHT", p_resPathRight);

    std::cerr << "CResourceManager::out::resumePathLeft : " << p_resPathLeft  << std::endl;
    std::cerr << "CResourceManager::out::resumePathRight: " << p_resPathRight << std::endl;

    return;
}


// void CResourceManager::loadInit(std::string p_iniFile)
// {
// }

// void CResourceManager::saveInit(std::vector<T_INI_ITEM> &p_items, std::string p_iniFile)
// {
// }

// void CResourceManager::saveInitItem(T_INI_ITEM p_item, std::string p_iniFile)
// {
// }


