#include <iostream>
#include <fstream>
#include "viewer.h"
#include "resourceManager.h"
#include "def.h"
#include "sdlutils.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

CViewer::CViewer(const std::string &p_fileName):
    CWindow(),
    m_fileName(p_fileName),
    m_workDir(""),
    m_firstLine(0),
    m_image(NULL),
    m_font(CResourceManager::instance().getFont())
{
    // Init clip rect
    m_clip.x = 0;
    m_clip.y = 0;
    m_clip.w = SCREEN_WIDTH - 2 * VIEWER_MARGIN;
    // Create background image
    m_image = SDL_utils::createImage(SCREEN_WIDTH, SCREEN_HEIGHT, SDL_MapRGB(Globals::g_screen->format, COLOR_BG_1));
    {
        SDL_Rect l_rect;
        l_rect.x = 0;
        l_rect.y = 0;
        l_rect.w = SCREEN_WIDTH;
        l_rect.h = Y_LIST;
        SDL_FillRect(m_image, &l_rect, SDL_MapRGB(m_image->format, COLOR_BORDER));
    }
    // Print title
    SDL_Surface *l_surfaceTmp = SDL_utils::renderText(m_font, m_fileName, Globals::g_colorTextTitle);
    if (l_surfaceTmp->w > m_image->w - 2 * VIEWER_MARGIN)
    {
        SDL_Rect l_rect;
        l_rect.x = l_surfaceTmp->w - (m_image->w - 2 * VIEWER_MARGIN);
        l_rect.y = 0;
        l_rect.w = m_image->w - 2 * VIEWER_MARGIN;
        l_rect.h = l_surfaceTmp->h;
        SDL_utils::applySurface(VIEWER_MARGIN, Y_HEADER, l_surfaceTmp, m_image, &l_rect);
    }
    else
    {
        SDL_utils::applySurface(VIEWER_MARGIN, Y_HEADER, l_surfaceTmp, m_image);
    }
    m_clip.h = l_surfaceTmp->h;
    m_icnclip.x = m_icnclip.y = 0;
    m_icnclip.w = m_icnclip.h = 32;
    SDL_FreeSurface(l_surfaceTmp);
    // Read file
    // std::ifstream l_file(m_fileName.c_str());
    std::ifstream l_file;
    std::string l_tmpFile = extDist(m_fileName, l_file);
    if (l_file.is_open())
    {
        std::string l_line("");
        while (!l_file.eof())
        {
            std::getline(l_file, l_line);
            m_lines.push_back(l_line);
        }
        l_file.close();
        if (l_tmpFile.size() > 0)
            std::remove(l_tmpFile.c_str());
    }
    else
        std::cerr << "Error: unable to open file " << m_fileName << std::endl;
    INHIBIT(std::cout << "CViewer: " << m_lines.size() << " lines read" << std::endl;)
}

CViewer::~CViewer(void)
{
    // delete work dir
    struct stat l_stat;
    std::string l_rmcmd("\\rm -rf ");
    if (stat(m_workDir.c_str(), &l_stat) == 0)
        std::system((l_rmcmd + m_workDir).c_str());

    // Free surfaces
    if (m_image != NULL)
    {
        SDL_FreeSurface(m_image);
        m_image = NULL;
    }
}

void CViewer::render(const bool p_focus) const
{
    INHIBIT(std::cout << "CViewer::render  fullscreen: " << isFullScreen() << "  focus: " << p_focus << std::endl;)
    // Draw background
    SDL_utils::applySurface(0, 0, m_image, Globals::g_screen);
    // Draw lines
    SDL_Surface *l_surfaceTmp(NULL);
    // SDL_Surface *l_surfaceTmpIcon(NULL);
    unsigned int l_i(0);
    std::vector<std::string>::const_iterator l_it = m_lines.begin() + m_firstLine;
    while (l_it != m_lines.end() && l_i < VIEWER_NB_LINES)
    {
        if (!l_it->empty())
        {
            l_surfaceTmp = SDL_utils::renderText(m_font, *l_it, Globals::g_colorTextNormal);
            SDL_utils::applySurface(VIEWER_MARGIN, VIEWER_Y_LIST + l_i * VIEWER_LINE_HEIGHT, l_surfaceTmp, Globals::g_screen, &m_clip);
            SDL_FreeSurface(l_surfaceTmp);

            if (l_it->substr(0,5) == "Icon:")
            {
                struct stat l_stat;
                std::string l_iconFile(m_workDir + "/" + l_it->substr(6) + ".png");
                if (stat(l_iconFile.c_str(), &l_stat) == 0)
                {
                    l_surfaceTmp = SDL_utils::loadImage(l_iconFile.c_str());
                    SDL_utils::applySurface(SCREEN_WIDTH - VIEWER_MARGIN - 32 - m_clip.x, VIEWER_Y_LIST + l_i * VIEWER_LINE_HEIGHT - 16, l_surfaceTmp, Globals::g_screen, &m_icnclip);
                    SDL_FreeSurface(l_surfaceTmp);
                } else
                    std::cerr << "CViewer::render Icon: " << l_iconFile << " not found.(stat error)" << std::endl;
            }
        }
        // Next line
        ++l_it;
        ++l_i;
    }
}

std::string CViewer::extDist(std::string &p_fileName, std::ifstream &p_stream)
{
    size_t expos = p_fileName.rfind('.');
    std::string l_tmpFile("");
    std::string l_tmpex("");
    std::string l_exec("");
    m_workDir = "";

    if (expos != std::string::npos && expos > 0)
    {
        // temp filename.(with pid)
        pid_t pid = getpid();
        char *spid = NULL;
        if (asprintf(&spid, "%jd", (intmax_t) pid) != -1) {
            l_tmpFile  = "/tmp/cmd";
            l_tmpFile += spid;
            m_workDir  = "/tmp/wkd";
            m_workDir += spid;
            free(spid); // cleanup when done.
        }

        // get extension
        l_tmpex = p_fileName.substr(expos + 1, p_fileName.size() - expos);

        if (l_tmpex == "zip")
            l_exec = "\\unzip -l \"" + p_fileName + "\" >" + l_tmpFile;
        else if (l_tmpex == "opk")
            l_exec  = "./opkimginfo.sh  \"" + p_fileName + "\" " + m_workDir + " " + l_tmpFile;
        else if (l_tmpex == "7z")
            l_exec = "\\7zr l    \"" + p_fileName + "\" >" + l_tmpFile;
        else if (l_tmpex == "rar")
            l_exec = "\\unrar l  \"" + p_fileName + "\" >" + l_tmpFile;
        else if (l_tmpex == "mcd" || l_tmpex == "mcr")
            l_exec = "./mcdread  \"" + p_fileName + "\" >" + l_tmpFile;
    }

    INHIBIT(std::cout "CViewer::extDist: " << l_exec << std::endl);

    // exec & open stream
    if (l_exec.size() > 0)
    {
        std::system(l_exec.c_str());
        p_stream.open(l_tmpFile.c_str());
        return l_tmpFile;
    } else
        p_stream.open(p_fileName.c_str());

    return "";
}

const bool CViewer::keyPress(const SDL_Event &p_event)
{
    CWindow::keyPress(p_event);
    bool l_ret(false);
    switch (p_event.key.keysym.sym)
    {
        case MYKEY_PARENT:
            m_retVal = -1;
            l_ret = true;
            break;
        case MYKEY_UP:
            l_ret = moveUp(1);
            break;
        case MYKEY_DOWN:
            l_ret = moveDown(1);
            break;
        case MYKEY_PAGEUP:
            l_ret = moveUp(VIEWER_NB_LINES - 1);
            break;
        case MYKEY_PAGEDOWN:
            l_ret = moveDown(VIEWER_NB_LINES - 1);
            break;
        case MYKEY_LEFT:
            l_ret = moveLeft();
            break;
        case MYKEY_RIGHT:
            moveRight();
            l_ret = true;
            break;
        default:
            break;
    }
    return l_ret;
}

const bool CViewer::keyHold(void)
{
    bool l_ret(false);
    switch(m_lastPressed)
    {
        case MYKEY_UP:
            if (tick(SDL_GetKeyState(NULL)[MYKEY_UP]))
                l_ret = moveUp(1);
            break;
        case MYKEY_DOWN:
            if (tick(SDL_GetKeyState(NULL)[MYKEY_DOWN]))
                l_ret = moveDown(1);
            break;
        case MYKEY_PAGEUP:
            if (tick(SDL_GetKeyState(NULL)[MYKEY_PAGEUP]))
                l_ret = moveUp(VIEWER_NB_LINES - 1);
            break;
        case MYKEY_PAGEDOWN:
            if (tick(SDL_GetKeyState(NULL)[MYKEY_PAGEDOWN]))
                l_ret = moveDown(VIEWER_NB_LINES - 1);
            break;
        case MYKEY_LEFT:
            if (tick(SDL_GetKeyState(NULL)[MYKEY_LEFT]))
                l_ret = moveLeft();
            break;
        case MYKEY_RIGHT:
            if (tick(SDL_GetKeyState(NULL)[MYKEY_RIGHT]))
            {
                moveRight();
                l_ret = true;
            }
            break;
        default:
            break;
    }
    return l_ret;
}

const bool CViewer::isFullScreen(void) const
{
    return true;
}

const bool CViewer::moveUp(const unsigned int p_step)
{
    bool l_ret(false);
    if (m_firstLine)
    {
        if (m_firstLine > p_step)
            m_firstLine -= p_step;
        else
            m_firstLine = 0;
        l_ret = true;
    }
    return l_ret;
}

const bool CViewer::moveDown(const unsigned int p_step)
{
    bool l_ret(false);
    if (m_firstLine + VIEWER_NB_LINES + 1 < m_lines.size())
    {
        if (m_firstLine + VIEWER_NB_LINES + 1 + p_step > m_lines.size())
            m_firstLine = m_lines.size() - VIEWER_NB_LINES - 1;
        else
            m_firstLine += p_step;
        l_ret = true;
    }
    return l_ret;
}

const bool CViewer::moveLeft(void)
{
    bool l_ret(false);
    if (m_clip.x > 0)
    {
        if (m_clip.x > VIEWER_X_STEP)
            m_clip.x -= VIEWER_X_STEP;
        else
            m_clip.x = 0;
        l_ret = true;
    }
    // if (m_icnclip.x > 0)
    // {
    //     if (m_icnclip.x > VIEWER_X_STEP)
    //         m_icnclip.x -= VIEWER_X_STEP;
    //     else
    //         m_icnclip.x = 0;
    //     l_ret = true;
    // }
    return l_ret;
}

void CViewer::moveRight(void)
{
    m_clip.x += VIEWER_X_STEP;
    // m_icnclip.x += VIEWER_X_STEP;
}
