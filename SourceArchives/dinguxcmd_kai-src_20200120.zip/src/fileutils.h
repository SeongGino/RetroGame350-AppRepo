#ifndef _FILEUTILS_H_
#define _FILEUTILS_H_

#include <string>
#include <vector>

namespace File_utils
{
    // File operations

    void copyFile(const std::vector<std::string> &p_src, const std::string &p_dest);

    void moveFile(const std::vector<std::string> &p_src, const std::string &p_dest);

    void removeFile(const std::vector<std::string> &p_files);

    void executeFile(const std::string &p_file);

    void executeScript(const std::string &p_file, std::string p_script="");

    void makeDirectory(const std::string &p_file);

    void renameFile(const std::string &p_file1, const std::string &p_file2);

    // p_file: extract file name(full path)
    // p_dest: extract to.
    void extractFile(const std::vector<std::string> &p_list, const std::string &p_dest, const int p_mode=1);

    void compressFile(const std::vector<std::string> &p_list, const std::string &p_dest, const int p_mode=1);

    // File utilities

    bool tryMkdir(const std::string &p_path, std::string &p_name);

    const bool fileExists(const std::string &p_path);

    const unsigned long int getFileSize(const std::string &p_file);

    void formatSize(std::string &p_size);

    bool canExtract(const std::string &p_file);

    const std::string getFileName(const std::string &p_path);

    const std::string getPath(const std::string &p_path);

    const std::string getFileType(const std::string &p_path);

    const std::string getSelfExecutionPath(void);

    const std::string getSelfExecutionName(void);

    void stringReplace(std::string &p_string, const std::string &p_search, const std::string &p_replace);

    const std::string specialChars(const std::string &p_string);

    const std::string formatMode(const struct stat &p_stat);

    // Dialogs

    void diskInfo(void);

    void diskUsed(const std::vector<std::string> &p_files);
}

#endif
